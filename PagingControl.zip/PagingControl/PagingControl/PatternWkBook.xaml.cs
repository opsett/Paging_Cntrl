﻿using SharedResource;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Printing;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace PagingControl
{
    /// <summary>
    /// Interaction logic for PatternWkBook.xaml
    /// </summary>
    public partial class PatternWkBook : Window, IDisposable
    {
        public PatternWkBook()
        {


            InitializeComponent();

            //this.TabManager = _tabPageHost;
            TabCtrMgr = _tabControlMgr;

            this.Cv = new ContentViewModel();
            DataContext = Cv;
            Cv._collection = new ColorsRepository();/// this.TryFindResource("ColorsRepositoryDataSource");
            this.Closing += PatternWkBook_Closing;
            //this.Closing += PatternWkBook_Closing;


            var prevs = new System.Diagnostics.StackTrace().GetFrames();


        }

        //public Control AncestorWindow { get; set; }

        //public DataGrid GetPrintsGrid { get { return TabCtrMgr.GetPrintsGrid.DgViews; } }

        public void Instantiate(ColorInfo colorInf)
        {
            Cv.SelectedColor = colorInf;
        }

        public ContentViewModel Cv { get; private set; }
        //private string[] PattnList { get; set; }
        //public int RowsPerPage { get => PaginInfo.RowsPerPage; }

        //[ThreadStatic()]
        protected internal static ProcessPrint PagingInfo;

        public ProcessPrint ProcessPage(string[] pttnList, PageMediaSize media)
        {
            /* /// * /
            ///DnD: Use single row data to create a dagagrid row
            var pattnStrArr = PrintFormat.GetSamplePattern(pttnList, out PrintFormat[] pttnArr);

            ViewsDataGrid dgm = new ViewsDataGrid();
            var dg = dgm.DgViews;
            dg.ItemsSource = pattnStrArr;
            var tabControlMgr = this.TabCtrMgr;

            ///DnD: ChrOrdered
            ///DnD tabControlMgr is temporally used to optimized  datagrid by using its
            ///[UpdateLayout()] function while hosting datagrid as content. Thereafter
            ///the must be datagrid is detached by asigning null as content. Same procese
            ///is repeated below before finally reusing the [tabcontrolMgr] as to host
            ///tabpages. Such reuses instead of using new instances helps conserve overhead
            var contHold = tabControlMgr.Content;
            tabControlMgr.Content = dgm;
            tabControlMgr.UpdateLayout();
            tabControlMgr.Content = null;
            tabControlMgr.Content = contHold;

            this.PattnList = pttnList;
            /// */
            return PagingInfo = new ProcessPrint().ProcessPage(pttnList, media, this);// ProcessPrint(dg, media);

        }

        public Size PageSize { get => PagingInfo.PageSize; }//{ get => new Size(PaginInfo.PageSize.Width.Value, PaginInfo.PageSize.Height.Value); }

        //public string[][] SplitListToPages() { return SplitListToPages(this.PattnList, PaginInfo.RowsPerPage); }
        //public string[][] SplitListToPages(string[] pttnList, int rowsPerPage)
        //{
        //    return Stat.ReSizeToArr(pttnList, rowsPerPage)
        //         .Select(i => (string[])(i.Select(ii => (string)ii).ToArray())).ToArray();
        //}

        //public ProcessPrint ProcessPageXXX(DataGrid dg, PageMediaSize media)
        //{
        //    //var dg = new DataGrid();

        //    return PaginInfo = new ProcessPrint(dg, media);

        //}

        public DataGrid[] SplitDgToPages(DataGrid dg, PageMediaSize mediaSize)
        {

            //Cv.Hybrid = Cv.Items.Count() > 0 && !Cv.IsSizedToPage;

            Cv.MediaSize = mediaSize;
            return GetWorkSheets(dg, mediaSize).Result;

        }


        public FixedDocument GetFixDoc(DataGrid[] dgs, Size sz, Thickness printMargin)
        {
            return PagingInfo.GetFixDoc(dgs, sz, printMargin);
        }

        [MTAThread]
        public void CallbackMethod(IAsyncResult ar)
        {
            // Retrieve the delegate.
            AsyncResult result = (AsyncResult)ar;
            PagingDgt caller = (PagingDgt)result.AsyncDelegate;

            while (!result.IsCompleted)
                Thread.Sleep(1);

            // Retrieve the format string that was passed as state
            // information.
            //string formatString = (string)ar.AsyncState;

            // Define a variable to receive the value of the out parameter.
            // If the parameter were ref rather than out then it would have to
            // be a class-level field so it could also be passed to BeginInvoke.
            CheckStatus status = 0;

            while (!result.IsCompleted)
                Thread.Sleep(1);

            // Call EndInvoke to retrieve the results.
            //this.Dispatcher.Invoke()

            Application.Current.Dispatcher.BeginInvoke(
                 DispatcherPriority.Background, new Action(() => { caller.EndInvoke(ar); }));

            //CheckStatus returnValue = caller.EndInvoke(  ar);

            // Use the format string to format the output message.
            //Console.WriteLine(formatString, threadId, returnValue);
        }




        public ColorInfo NewColorInfo
        {
            get
            {
                var i = TabCtrMgr.TabControl.Items.Count;
                var colInfArr = Cv._collection;

                if (colInfArr.Count <= i)
                    i %= colInfArr.Count;

                var colorInf = Cv._collection[i];
                var testIt = colorInf.InitSelected = i < 1;

                //if (this.PrintMode)
                //    colorInf.DataGridPaging = GetPrintsGrid;
                return colorInf;
            }
        }

        public bool PrintMode { get; set; }

        private TabControlMgr TabCtrMgr0;
        public TabControlMgr TabCtrMgr
        {
            get { return TabCtrMgr0; }

            set
            {
                TabCtrMgr0 = value;
                //TabCtrHold.Children.Add(TabControlMgr0);
                //TabControlMgr0.VerticalAlignment = VerticalAlignment.Stretch;
                //TabControlMgr0.HorizontalAlignment = HorizontalAlignment.Stretch;
            }
        }

        //public ProcessPrint ProcePrint { get; set; }

        public ColorInfo[] PageSizeGrids(DataGrid dg, PageMediaSize mediaSize, PatternWkBook workBook)
        {
            ColorInfo[] dgPages = null;
            ProcessPrint printProce = new ProcessPrint(dg);

            printProce.PreviewMod = PrintPreview.AllPages;


            //printProce.ReapedItemSource();

            ////dgToPrint.ItemsSource = task.Result;
            ////task.Wait();

            //PrintDialog pDlg = new PrintDialog();
            ////if (!pDlg.ShowDialog().Value)
            ////    return null;

            ////ProcessPrint printProce;
            ////PageMediaSize mediaSize = mediaSize;// pDlg.PrintTicket.PageMediaSize;
            ////goto ReProcess;// null;

            var paperSize = new Size(mediaSize.Width.Value, mediaSize.Height.Value);
            var printHeight = paperSize.Height - (40 + GuiStat.PrintMargin.Top + GuiStat.PrintMargin.Bottom);
            Double printableHeight = printHeight;// printSize.Height;

            //var colInfoArr = printProce.GetDgPages(printableHeight, workBook);//.GetDataGridPages(printableHeight);
            //return colInfoArr;
            return null;
        }
        public DataGrid PageSizeDgrid(ProcessPrint procePrint, PageMediaSize mediaSize)
        {
            //Cv.Hybrid = Cv.Items.Count() > 0 && !Cv.IsSizedToPage;

            Cv.MediaSize = mediaSize;

            var paperSize = new Size(mediaSize.Width.Value, mediaSize.Height.Value);
            var printHeight = paperSize.Height - (40 + GuiStat.PrintMargin.Top + GuiStat.PrintMargin.Bottom);
            Double printableHeight = printHeight;// printSize.Height;
            procePrint.PreviewMod = PrintPreview.None;

            var dg = procePrint.GetPageSizeList(printableHeight);
            return dg;
            //return GetWorkSheets(procePrint.SourceDataGrid, mediaSize).Result;
        }

        public int PageSizeDgrid(double rowHeight, PageMediaSize mediaSize)
        {
            //Cv.Hybrid = Cv.Items.Count() > 0 && !Cv.IsSizedToPage;
            Cv.MediaSize = mediaSize;

            var paperSize = new Size(mediaSize.Width.Value, mediaSize.Height.Value);
            var printHeight = paperSize.Height - (40 + GuiStat.PrintMargin.Top + GuiStat.PrintMargin.Bottom);
            Double printableHeight = printHeight;// printSize.Height;
            double mod = printableHeight % rowHeight;

            int listSz = (int)((printableHeight - mod) / rowHeight);


            return listSz;

        }

        public async Task<DataGrid[]> GetWorkSheets(DataGrid dg, PageMediaSize mediaSize)
        {

            //FixedDocument fixedDoc = null;
            FixedDocument fxDoc = null;

            //ReProcess:
            DataGrid[] dgPages = null;
            //reTest:
            try
            {


                ProcessPrint printProce = new ProcessPrint(dg);

                printProce.PreviewMod = PrintPreview.AllPages;


                //await printProce.ReapedItemSource();

                ////dgToPrint.ItemsSource = task.Result;
                ////task.Wait();

                //PrintDialog pDlg = new PrintDialog();
                ////if (!pDlg.ShowDialog().Value)
                ////    return null;

                ////ProcessPrint printProce;
                ////PageMediaSize mediaSize = mediaSize;// pDlg.PrintTicket.PageMediaSize;
                ////goto ReProcess;// null;

                var paperSize = new Size(mediaSize.Width.Value, mediaSize.Height.Value);
                var printHeight = paperSize.Height - (40 + GuiStat.PrintMargin.Top + GuiStat.PrintMargin.Bottom);
                Double printableHeight = printHeight;// printSize.Height;

                dgPages = printProce.GetDgPages(printableHeight);//.GetDataGridPages(printableHeight);


                //fxDoc = printProce.GetFixDoc(dgPages, paperSize, GuiStat.PrintMargin);


            }
            catch (Exception ex)
            {
                //goto reTest;
            }
            return dgPages;
        }
        #region IDisposable Support

        private void PatternWkBook_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (!IsDisposed && Cv.IsSizedToPage && !e.Cancel)
            {
                var dlg = MessageBox.Show("You may lose unsaved work\n\rDo you want to close?",
                    "WorkBook is closing!", MessageBoxButton.YesNoCancel, MessageBoxImage.Warning);
                if (dlg == MessageBoxResult.Yes)
                    Dispose(true);
                else e.Cancel = true;
                return;
            }
            if (!e.Cancel)
            {
                if (_tabControlMgr != null)
                {

                    var sharpColors = _tabControlMgr.SharpColors;

                    if (sharpColors.Count > 1 && TabControlMgr.ColorEditMode)
                    {
                        var conctStr = String.Join("\r\n", sharpColors.ToArray());
                        var colrFile = Stat.AppDir + Xt.ColorInfos;

                        File.WriteAllText(colrFile, conctStr);
                    }
                    TabControlMgr.ColorEditMode = false;
                    _tabControlMgr = null;
                    //flInf.Replace(colrFile, colrFile+".bkp");


                    //string ColorsList { get => Stat.AppDir + Xt.ColorInfos; }
                    //File.AppendAllText(Stat.AppDir + Xt.ColorInfos, conctStr);
                    //    Sw.WriteLine(colName);

                    //Sw.Dispose();
                    //Sw = null;


                    //       var sw = File.AppendText(ColorsList);


                    //    sw.WriteLine(colName);

                    //    Sw.Dispose();
                    //    Sw = null;
                    //    _tabControlMgr.Sw.Close();
                }
                Dispose();

            }

        }


        public bool IsDisposed = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!IsDisposed)
            {
                if (disposing)
                {
                    this.Cv = null;
                    // TODO: dispose managed state (managed objects).
                }

                // TODO: free unmanaged resources (unmanaged objects) and override a finalizer below.
                // TODO: set large fields to null.
                //Dispose();
                /*this.NewColorInfo = null; PageSize = null; ProcePrint = null;*/ PagingInfo = null; TabCtrMgr0 = null;
                IsDisposed = true;
                if (Stat.SetActiveWindow != null)
                    Stat.SetActiveWindow.Invoke(this, new DependencyPropertyChangedEventArgs());

            }
        }

        // TODO: override a finalizer only if Dispose(bool disposing) above has code to free unmanaged resources.
        // ~WkbookMgr()
        // {
        //   // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
        //   Dispose(false);
        // }

        // This code added to correctly implement the disposable pattern.
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            //if(!IsDisposed)
            Dispose(true);
            // TODO: uncomment the following line if the finalizer is overridden above.
            // GC.SuppressFinalize(this);
            GC.SuppressFinalize(this);
        }

        ~PatternWkBook()
        {
            Dispose(false);
        }
        #endregion




        //public TabControlMgr TabManager { get { return (TabControlMgr)GetValue("TabManager"); } set { SetValue("TabManager", value); } }



        //static Dictionary<string, object> _values = new Dictionary<string, object>();


        //object GetValue(string p)
        //{

        //    _values.TryGetValue(p, out object value);
        //    return value;
        //}

        //void SetValue(string p, object value)
        //{
        //    if (!object.Equals(value, GetValue(p)))
        //    {
        //        _values[p] = value;
        //    }
        //}


    }


    public delegate object PagingDgt(/*PatternWkBook wkBook,*/ ICollectionView[] sourceItems);
}
