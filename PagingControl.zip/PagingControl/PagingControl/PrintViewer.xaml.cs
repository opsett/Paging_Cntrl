﻿using SharedResource;
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Packaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Xps;
using System.Windows.Xps.Packaging;

namespace PagingControl
{
    /// <summary>
    /// Interaction logic for PrintViewer.xaml
    /// </summary>
    public partial class PrintViewer : Window
    {
        public PrintViewer()
        {
            InitializeComponent();

            //xps
            var stream = new MemoryStream();

            this.DucPackage = Package.Open(stream, FileMode.Create, FileAccess.ReadWrite);
            this.Uri = Stat.DftSaveDir + "printpkg.dat";
            var uri = new Uri(Uri);
            //already in packagestore, so remove
            if (PackageStore.GetPackage(uri) != null)
            {
                PackageStore.RemovePackage(uri);
            }
            PackageStore.AddPackage(uri, DucPackage);
            this.XpsDoc = new XpsDocument(DucPackage);

            //xpsDoc.Uri = uri;
            //XpsDocumentWriter writer = XpsDocument.CreateXpsDocumentWriter(xpsDoc);
            //writer.Write(documentPaginator);

            //FixedDocumentSequence fds = xpsDoc.GetFixedDocumentSequence();

            //dv1.Document = (IDocumentPaginatorSource)fds;
        }

        public IDocumentPaginatorSource Document
        {
            get { return viewer.Document; }
            set
            {
                if (viewer.Document == null)
                    viewer.Document = value;
            }
        }

        public FixedPage documentPaginator { get; private set; }
        public Package DucPackage { get; }
        public XpsDocument XpsDoc { get; }
        public string Uri { get; }
    }
}
