﻿using SharedResource;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PagingControl
{
    /// <summary>
    /// Interaction logic for TabControlMgr.xaml
    /// </summary>
    public partial class TabControlMgr : UserControl
    {
        public TabControlMgr()
        {

            InitializeComponent();

            tabControl.Items.Clear();
            TabControl = tabControl;

            DataContextChanged += TabControlMgr_DataContextChanged;
            TabControl.DataContextChanged += TabControlMgr_DataContextChanged;

            tabControl.SelectionChanged += TabControl_SelectionChanged;

            TempFile = System.IO.Path.GetTempFileName();

            if (Keyboard.Modifiers == ModifierKeys.Alt)           
                ColorEditMode = true;

                var allText = File.ReadAllText(Stat.AppDir + Xt.ColorInfos);
                if (allText != null && allText.Trim() != "")
                {
                    string[] colList = allText.Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);

                    SharpColors.AddRange(colList);

                }


        }

        private void BtnInsert_Click(object sender, RoutedEventArgs e)
        {
            //return;
            var colNm = txtNewColumn.Text.Trim();
            if (colNm == ""||(ContentViewModel)DataContext==null|| ((ContentViewModel)DataContext).SelectedColor==null) return;

            var colInf = ((ContentViewModel)DataContext).SelectedColor as ColorInfo;
            var iCol = colInf.PattnList as System.ComponentModel.ICollectionView;
            var lCol = (ListCollectionView)colInf.PattnList as ListCollectionView;
            var colPropt = lCol.ItemProperties.Select((p, i) => new {Name=p.Name, Index= i });//.ToArray();// => new { Name = x, Index = i }).ToArray();
           
            if (colPropt== null) return;
            
            var dg = ViewsDataGrid.DgViews2;
            //InsertColumn(colPropt, colNm, dg);

            var propt = lCol.ItemProperties;
            var pattns = lCol.SourceCollection.Cast<PrintFormat>().ToArray() as PrintFormat[];
            //var dg = ViewsDataGrid.DgViews2;
        }

        private void InsertColumn(System.ComponentModel.ItemPropertyInfo propt, string colName, DataGrid dataGrid)
        {

            //foreach (var column in columns)
            {

                //< DataGridTextColumn Header = "Names" Binding = "{Binding Name}"  Width = "Auto" />

                var bind = string.Format("Properties[{0}]", propt.Name);
                var binding = new Binding(propt.Name);

                dataGrid.Columns.Add(new CustomBoundColumn()
                {
                    Header = colName,
                    Binding = binding,
                    TemplateName = "CustomTemplate"
                });
            }
            //txtNewCol.Text = "City";

        }




        public List<string> SharpColors = new List<string>();
        public static bool ColorEditMode;
        private void TabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems == null || e.AddedItems.Count < 1)
                return;

            var colInf = e.AddedItems[0] as ColorInfo;


            if (ColorEditMode && colInf != null && tabControl.Items.Count > 1)
            {

                //if (Sw == null)
                //    Sw = File.AppendText(ColorsList);

                var colName = colInf.Val.ToString();
                if (SharpColors.Contains(colName))
                {
                    if (Keyboard.Modifiers == ModifierKeys.Alt)
                        SharpColors.Remove(colName);
                    return;
                }
                SharpColors.Add(colName);



                //ConctStr += (ConctStr.Length > 1 ? "\r\n" : "") + colName;
                //Sw.WriteLine(colName);

                //Sw.Dispose();
                //Sw = null;
            }
        }









        public static string TempFile { get; set; }
        static byte[] EoF { get; set; }

        //public NameList()
        //{

        //    string path = ListSavePath;

        //    if (!File.Exists(path))
        //        File.Create(path);
        //    else
        //    {
        //        string eof2, eof = Encoding.UTF8.GetString(EoF);//.Select(s => Convert.ToString(s));

        //        byte[] byts2, byts = File.ReadAllBytes(path);
        //        while (byts.Length > 0)
        //        {
        //            int cutMark = Encoding.UTF8.GetString(byts).IndexOf("</EOF>");// ".ToList().IndexOf(Convert.ToByte("<"));
        //            eof2 = Encoding.UTF8.GetString(byts.ToList().GetRange(cutMark, EoF.Length).ToArray());

        //            if (eof != eof2)
        //                return;
        //            byts2 = byts.Take(cutMark).ToArray();
        //            var name = (string)Stat.Deserialize((byts2));
        //            Names.Add(name);

        //            byts = byts.Skip(cutMark + eof.Length).ToArray();

        //        }
        //    }
        //}


        //public void SaveList()
        //{
        //    byte[] byts2 = new byte[0] { }, byts = null;
        //    foreach (string n in Names)
        //    {
        //        byts = Stat.Serialize(n);
        //        byts = (byte[])byts.Concat(EoF).ToArray();
        //        byts2 = byts2.Concat(byts).ToArray();
        //    }
        //    File.WriteAllBytes(ListSavePath, byts2);
        //}




















        private void TabControl_Loaded(object sender, RoutedEventArgs e)
        {
            //throw new NotImplementedException();
        }

        private void TabControlMgr_DataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            var colInf = DataContext as ColorInfo;

        }

        private void TabI_SourceUpdated(object sender, /*DataTransfer*/EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void TabI_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {

        }

        private void TabI_Initialized(object sender, EventArgs e)
        {

        }

        private void ScrVw_Loaded(object sender, EventArgs e)
        {
            try
            {
                ((TabItem)((ScrollViewer)((RoutedEventArgs)e).Source).Parent).InvalidateVisual();

            }
            catch (Exception ex)
            {

            }
        }
        //private Dictionary<string, ScrollViewer> TabControlDict { get; }
        //public ContentViewModel Cv { get; set; }



        //public System.Collections.ObjectModel.ObservableCollection<ScrollViewer> _itemSource { get; }

        public ViewsDataGrid GetPrintsGrid { get => new ViewsDataGrid(); }// (PrintsDataGrid)this.TryFindResource("PrintDg"); }
        //public DataGrid DftDataGrid { get; set; }

        public TabControl TabControl { get; }

        private void tabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.Source.GetType() != typeof(TabControl))
                return;
           


            var selectedTab = ((TabControl)e.Source).SelectedItem as TabItem;
            if (selectedTab == null) return;
            tabControl.BorderBrush = selectedTab.BorderBrush;

            if (!selectedTab.Name.Contains("ti"))
                return;
            var key = selectedTab.Name.Replace("ti", "");
            //var scrView = TabControlDict[key];
            //selectedTab.SetValue(ScrollViewer.ContentProperty, scrView);
            //scrView.UpdateLayout();
        }


        public static string TabItemTokenProperty(DependencyObject obj)
        {
            return (string)obj.GetValue(TabItemToken);
        }

        public static void TabItemTokenProperty(DependencyObject obj, string value)
        {
            obj.SetValue(TabItemToken, value);
        }

        // Using a DependencyPropertyExample as the backing store for MyProperty.  This enables animation, styling, binding, etc...  
        public static readonly DependencyProperty TabItemToken =
            DependencyProperty.RegisterAttached("TabItemToken", typeof(string), typeof(TabControlMgr), new PropertyMetadata());

        //public TabItem DftTabPage => dftTabItem;
        //public Style DftTabItemStyle => dftTabItem.Style;
        public string InstantToken { get => Stat.CentenaryToken; }


        int PadLen => TabControl.Items.Count.ToString().Length;
        public int AddTab()
        {
            var dftTab = (TabItem)TabControl.Items[0];
            int i = TabControl.Items.Add(new TabItem());
            var token = InstantToken;
            var newTab = (TabItem)TabControl.Items[i];
            newTab.Name = "ti" + token;
            //newTab.Style = DftTabItemStyle;
            var hdr = "Page: " + i.ToString().PadLeft(PadLen < 2 ? 2 : PadLen, '0');
            newTab.Header = hdr;
            newTab.BorderBrush = Brushes.BlueViolet;
            var scrVw = new ScrollViewer();
            scrVw.HorizontalAlignment = HorizontalAlignment.Stretch;
            scrVw.VerticalAlignment = VerticalAlignment.Stretch;

            scrVw.Name = "sv" + token;
            //TabControlDict.Add(token, scrVw);

            //newTab.Content = scrVw;            
            //TabControlDict.Add(hdr, scrVw);
            return i;
        }

        private string GetTabToken()
        {
            //var dftTab = (TabItem)TabHostCtl.Items[0];
            int i = TabControl.Items.Count + 1;// TabHostCtl.Items.Add(new TabItem());
            var token = InstantToken;
            //var newTab = (TabItem)TabHostCtl.Items[i];

            var newTab = new TabItem();
            //newTab.Style = DftTabItemStyle;
            newTab.Name = "ti" + token;
            //newTab.Style = dftTabItem.Style;
            var hdr = "Page: " + i.ToString().PadLeft(PadLen < 2 ? 2 : PadLen, '0');
            newTab.Header = hdr;
            newTab.BorderBrush = Brushes.BlueViolet;
            var scrVw = new ScrollViewer();
            scrVw.HorizontalAlignment = HorizontalAlignment.Stretch;
            scrVw.VerticalAlignment = VerticalAlignment.Stretch;

            scrVw.Name = "sv" + token;
            //TabControlDict.Add(token, scrVw);

            //newTab.Content = scrVw;            
            //TabControlDict.Add(hdr, scrVw);
            return token;
        }

        public int NewTab => AddTab();

        public TabItem GeTab(int index)
        {
            index = TabControl.Items.Count > index ? index : AddTab();

            return (TabItem)TabControl.Items[index];
        }

        public TabItem GeTab() { return (TabItem)TabControl.Items[AddTab()]; }

        public string NewTabToken { get => GetTabToken(); }
        //public ScrollViewer tabItemViewer { get => TabControlDict[GetTabToken()]; }
        //{

        //var dftTab = (TabItem)TabHostCtl.Items[0];
        //int i = TabHostCtl.Items.Add(new TabItem());
        //var token = InstantToken;
        //var newTab = (TabItem)TabHostCtl.Items[i];
        //newTab.Name = "ti" + token;
        //newTab.Style = dftTab.Style;
        //var hdr = "Page: " + i.ToString().PadLeft(PadLen < 2 ? 2 : PadLen, '0');
        //newTab.Header = hdr;
        //newTab.BorderBrush = Brushes.BlueViolet;
        ////var scrVw = new ScrollViewer();
        ////scrVw.HorizontalAlignment = HorizontalAlignment.Stretch;
        ////scrVw.VerticalAlignment = VerticalAlignment.Stretch;

        ////scrVw.Name = "sv" + token;
        //TabControlDict.Add(token, null);
        //return token.ToString();
        //}

        public int SetTab(int index, object content)
        {
            var dg = content as DataGrid;
            if (dg == null) return 0;

            //TabItem tab =  (TabItem)TabHostCtl.Items[] 
            index = TabControl.Items.Count > index ? index : AddTab();
            var tabI = (TabItem)TabControl.Items[index];

            //tabI.RequestBringIntoView += ScrVw_Loaded;
            //tabI.Initialized += TabI_Initialized;
            //tabI.SourceUpdated += TabI_SourceUpdated;
            //tabI.IsVisibleChanged += TabI_IsVisibleChanged;

            var token = tabI.Name.Replace("ti", "");
            //TabControlDict[token].SetValue(ScrollViewer.ContentProperty, dg);// (ScrollViewer)tabI.Content;

            //dg.InvalidateVisual();

            ////dg.TransformToVisual(scrVw);
            ////scrVw.DataContext = dg;
            //scrVw.Loaded += ScrVw_Loaded;

            //scrVw.Content = dg;
            //scrVw.SetValue(ScrollViewer.ContentProperty, dg); 


            //scrVw.UpdateLayout();
            //if (dg as DataGrid != null && dg.ActualWidth != 0)
            //    scrVw.SetValue(TabItem.WidthProperty, dg.ActualWidth);
            ////new TabItem().SetValue(TabItem.WidthProperty, "Auto");

            return index;
        }

        public int SetTab(ScrollViewer scrView)
        {
            var tabI = new TabItem();
            //tabI.Style = DftTabItemStyle;
            Border bd = new Border();
            bd.Child = scrView;
            bd.HorizontalAlignment = HorizontalAlignment.Stretch;
            bd.VerticalAlignment = VerticalAlignment.Stretch;
            tabI.Content = bd;
            scrView.UpdateLayout();
            var i = TabControl.Items.Add(tabI);

            return i;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            //((TabItem)this.tabControl.ItemContainerGenerator.ItemFromContainer();// Items)
        }

        private void BtnPreview_Click(object sender, RoutedEventArgs e)
        {
            var cv = DataContext as ContentViewModel;

            if (!cv.IsSizedToPage)
                return;

            var list = new List<DataGrid>();
            foreach (ColorInfo ci in cv.Items)
                list.Add((DataGrid)ci.PagingData);

            var sz = new Size(cv.MediaSize.Width.Value, cv.MediaSize.Height.Value);
            var pp = new ProcessPrint();
            pp.PreviewMod = PrintPreview.AllPages;

            this.Cursor = Cursors.AppStarting;
            var arr = list.ToArray().Where(s => s != null).ToArray();

            FixedDocument fDoc = pp.GetFixDoc(arr, sz, GuiStat.PrintMargin);
            
         
            this.Cursor = null;

        }

        private void _viewsDataGrid_SourceUpdated(object sender, DataTransferEventArgs e)
        {

        }

        ////public ScrollViewer DgScrollView { get { return (ScrollViewer)GetValue("DgScrollView"); } set { SetValue("DgScrollView", value); } }
        //public TabControl TabHostCtl2 { get { return (TabControl)GetValue("TabHostCtl"); } set { SetValue("TabHostCtl", value); } }

        //static Dictionary<string, object> _values = new Dictionary<string, object>();

        //object GetValue(string p)
        //{
        //    _values.TryGetValue(p, out object value);
        //    return value;
        //}

        //void SetValue(string p, object value)
        //{
        //    if (!object.Equals(value, GetValue(p)))
        //    {
        //        _values[p] = value;
        //    }
        //}






    }


    public class CustomBoundColumn : DataGridBoundColumn
    {
        public string TemplateName { get; set; }

        protected override FrameworkElement GenerateElement(DataGridCell cell, object dataItem)
        {
            var binding = new Binding(((Binding)Binding).Path.Path);
            binding.Source = dataItem;

            var content = new ContentControl();
            content.ContentTemplate = (DataTemplate)cell.FindResource(TemplateName);
            content.SetBinding(ContentControl.ContentProperty, binding);
            return content;
        }

        protected override FrameworkElement GenerateEditingElement(DataGridCell cell, object dataItem)
        {
            return GenerateElement(cell, dataItem);
        }
    }

}
