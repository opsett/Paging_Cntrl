﻿using SharedResource;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Printing;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;

namespace PagingControl
{
    /// <summary>
    /// Interaction logic for TabItemView.xaml
    /// </summary>
    public partial class DataGridTabView : UserControl
    {
        public DataGridTabView()
        {
            InitializeComponent();

            DftDataGrid = dataGrid;
            DftDataGrid.Style = ColumnHdrStyle;

            DftDataGrid.ItemContainerGenerator.ItemsChanged += ItemContainerGenerator_ItemsChanged;
            dataGrid.LoadingRowDetails += DataGrid_LoadingRowDetails;
            PrintDgt += DispathPrintAsync;

            //dispTimer = new System.Windows.Threading.DispatcherTimer(System.Windows.Threading.DispatcherPriority.Background);
            //dispTimer.Interval = new TimeSpan(0, 0, 10);
            //dispTimer.Tick += DispTimer_Tick;
            //dispTimer.Start();

            DgScrollView = dgScrollView;
        }

        private event Action<bool> PrintDgt;

        private bool PrintSet;
        private bool ProcessPrint
        {
            /*protected internal*/
            set
            {
                ///DnD: The event handle 'IsDone' sends a triger to all methods assigned
                ///to it from anywhere. Such assigned methods or delegated method is can
                ///be regarded as a subscriber to the event. There can be multiple
                ///subscribers to an event. However, the value of the EventHandle,"IsDone"
                ///will be null if no localor external method is subscribing or assigned
                ///to it and it should not be invoked without subscribers 
                if (PrintDgt != null)
                    PrintDgt.Invoke(value);

                PrintSet = value;
            }

            get { return PrintSet; }
        }

        public delegate Task<FixedDocument> PrintAsyncDgt();
        public void DispathPrintAsync(bool boolObj)
        {
            /*||object PrintPreview previewMode*/
            //    ProcessPrint printProce = new ProcessPrint(dataGrid);
            //    printProce.PreviewMod = PrintPreview.AllPages;
            //    await printProce.ReapedItemSource();
            //    PrintProfile(printProce);
            PrintSet = false;

            MethodInfo mth = this.GetType().GetMethod("DispatcherPrintAsync");//, new Type[] { typeof(ProcessPrint), typeof(PageMediaSize) });//.GetMethod("GetColumDepdPropts2", BindingFlags.Public | BindingFlags.Static);

            Delegate dlg = Delegate.CreateDelegate(typeof(PrintAsyncDgt), this, mth);
            Task.Run(() => dataGrid.Dispatcher.Invoke(method: dlg, args: null));

            /*await*/
            //DispatcherPrintAsync();
        }

        public async Task<FixedDocument> DispatcherPrintAsync()
        {
            //FixedDocument fixedDoc = null;
            FixedDocument fxDoc = null;

        ReProcess:

        reTest:
            try
            {


                ProcessPrint printProce = new ProcessPrint(dataGrid);

                printProce.PreviewMod = PrintPreview.AllPages;


                await printProce.ReapedItemSource();

                //dgToPrint.ItemsSource = task.Result;
                //task.Wait();

                PrintDialog pDlg = new PrintDialog();
                //if (!pDlg.ShowDialog().Value)
                //    return null;

                //ProcessPrint printProce;
                PageMediaSize medSize = pDlg.PrintTicket.PageMediaSize;
                //goto ReProcess;// null;

                var paperSize = new Size(medSize.Width.Value, medSize.Height.Value);
                var printHeight = paperSize.Height - (40 + GuiStat.PrintMargin.Top + GuiStat.PrintMargin.Bottom);
                Double printableHeight = printHeight;// printSize.Height;

                //dgPages = dgPages;
                var dgPages = printProce.GetDgPages(printableHeight);//.GetDataGridPages(printableHeight);
                fxDoc = printProce.GetFixDoc(dgPages, paperSize, GuiStat.PrintMargin);
            }
            catch (Exception ex)
            {
                //goto reTest;
            }
            return fxDoc;
        }


        public async Task<DataGrid[]> GetWorkSheets(DataGrid dg, PageMediaSize mediaSize)
        {

            //FixedDocument fixedDoc = null;
            FixedDocument fxDoc = null;

            //ReProcess:
            DataGrid[] dgPages = null;
            //reTest:
            try
            {


                ProcessPrint printProce = new ProcessPrint(dg);

                printProce.PreviewMod = PrintPreview.AllPages;


                await printProce.ReapedItemSource();

                ////dgToPrint.ItemsSource = task.Result;
                ////task.Wait();

                //PrintDialog pDlg = new PrintDialog();
                ////if (!pDlg.ShowDialog().Value)
                ////    return null;

                ////ProcessPrint printProce;
                ////PageMediaSize mediaSize = mediaSize;// pDlg.PrintTicket.PageMediaSize;
                ////goto ReProcess;// null;

                var paperSize = new Size(mediaSize.Width.Value, mediaSize.Height.Value);
                var printHeight = paperSize.Height - (40 + GuiStat.PrintMargin.Top + GuiStat.PrintMargin.Bottom);
                Double printableHeight = printHeight;// printSize.Height;

                dgPages = printProce.GetDgPages(printableHeight);//.GetDataGridPages(printableHeight);


                //fxDoc = printProce.GetFixDoc(dgPages, paperSize, GuiStat.PrintMargin);


            }
            catch (Exception ex)
            {
                //goto reTest;
            }
            return dgPages;
        }

        public async Task<DataGrid[]> GetWorkSheets(DataGrid dg, PageMediaSize mediaSize, TabControlMgr tabCtrMgr)
        {

            //FixedDocument fixedDoc = null;
            FixedDocument fxDoc = null;

            //ReProcess:
            DataGrid[] dgPages = null;
            //reTest:
            try
            {


                ProcessPrint printProce = new ProcessPrint(dg);

                printProce.PreviewMod = PrintPreview.AllPages;


                await printProce.ReapedItemSource();

                ////dgToPrint.ItemsSource = task.Result;
                ////task.Wait();

                //PrintDialog pDlg = new PrintDialog();
                ////if (!pDlg.ShowDialog().Value)
                ////    return null;

                ////ProcessPrint printProce;
                ////PageMediaSize mediaSize = mediaSize;// pDlg.PrintTicket.PageMediaSize;
                ////goto ReProcess;// null;

                var paperSize = new Size(mediaSize.Width.Value, mediaSize.Height.Value);
                var printHeight = paperSize.Height - (40 + GuiStat.PrintMargin.Top + GuiStat.PrintMargin.Bottom);
                Double printableHeight = printHeight;// printSize.Height;

                dgPages = printProce.GetDgPages2(printableHeight, ref tabCtrMgr);//.GetDataGridPages(printableHeight);


                //fxDoc = printProce.GetFixDoc(dgPages, paperSize, GuiStat.PrintMargin);



            }
            catch (Exception ex)
            {
                //goto reTest;
            }
            return dgPages;
        }

        public async Task<ScrollViewer[]> GetDgridViews(DataGrid dg, PageMediaSize mediaSize, TabControlMgr tabCtrMgr)
        {

            //FixedDocument fixedDoc = null;
            FixedDocument fxDoc = null;

            //ReProcess:
            ScrollViewer[] dgPages = null;
            //reTest:
            try
            {


                ProcessPrint printProce = new ProcessPrint(dg);

                printProce.PreviewMod = PrintPreview.AllPages;


                await printProce.ReapedItemSource();

                ////dgToPrint.ItemsSource = task.Result;
                ////task.Wait();

                //PrintDialog pDlg = new PrintDialog();
                ////if (!pDlg.ShowDialog().Value)
                ////    return null;

                ////ProcessPrint printProce;
                ////PageMediaSize mediaSize = mediaSize;// pDlg.PrintTicket.PageMediaSize;
                ////goto ReProcess;// null;

                var paperSize = new Size(mediaSize.Width.Value, mediaSize.Height.Value);
                var printHeight = paperSize.Height - (40 + GuiStat.PrintMargin.Top + GuiStat.PrintMargin.Bottom);
                Double printableHeight = printHeight;// printSize.Height;

                dgPages = printProce.GetDgPages3(printableHeight);//.GetDataGridPages(printableHeight);


                //fxDoc = printProce.GetFixDoc(dgPages, paperSize, GuiStat.PrintMargin);



            }
            catch (Exception ex)
            {
                //goto reTest;
            }
            return dgPages;
        }


        private void OnLoadingRow(object sender, DataGridRowEventArgs e)
        {
            e.Row.Header = (e.Row.GetIndex() + 1).ToString().PadLeft(dataGrid.Items.Count.ToString().Length, '0');
        }


        //private void ContentPresenter_DataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
        //{

        //}

        System.Windows.Threading.DispatcherTimer dispTimer { get; set; }
        private void DataGrid_LoadingRowDetails(object sender, DataGridRowDetailsEventArgs e)
        {
            throw new NotImplementedException();
        }

        private void ItemContainerGenerator_ItemsChanged(object sender, ItemsChangedEventArgs e)
        {
            if (e.ItemCount < 1) return;
            int index = e.Position.Index;
            DataGridRow dRow = (DataGridRow)dataGrid.Items[0];
            return;
            //get all DataGridRow elements in the visual tree
            IEnumerable<DataGridRow> rows = FindVisualChildren<DataGridRow>(dRow);
            foreach (DataGridRow row in rows)
            {
                row.Header = (row.GetIndex() + 1).ToString();
            }
        }

        private static IEnumerable<T> FindVisualChildren<T>(DependencyObject dependencyObject)
            where T : DependencyObject
        {
            if (dependencyObject != null)
            {
                for (int i = 0; i < VisualTreeHelper.GetChildrenCount(dependencyObject); i++)
                {
                    DependencyObject child = VisualTreeHelper.GetChild(dependencyObject, i);
                    if (child != null && child is T)
                    {
                        yield return (T)child;
                    }

                    foreach (T childOfChild in FindVisualChildren<T>(child))
                    {
                        yield return childOfChild;
                    }
                }
            }
        }

        //public PrintCommand PrintData { get => DataSource == null ? new PrintCommand() : new PrintCommand(DftDataGrid); }


        static string[] _lines = "Computers|Washers|Stoves".Split('|');
        static string[] _colors = "Red|Green|Blue|White".Split('|');


        public static readonly DependencyProperty ColumnHdrStyleProperty =
            DependencyProperty.Register("ColumnHdrStyle", typeof(Style), typeof(Control)/*,
              new  PropertyMetadata(false, new PropertyChangedCallback(OnSetTextChanged))*/);


        public Style ColumnHdrStyle
        {
            get { return (Style)GetValue(ColumnHdrStyleProperty); }
            set { SetValue(ColumnHdrStyleProperty, value); }
        }



        private static PrintsDataGrid PrintControl0 => new PrintsDataGrid();
        public static Style GetColumnHdrStyle
        {
            get { return (Style)PrintControl0.FindResource("ColumnHeaderStyle1"); }
        }


        public static Style GetDgRowStyle
        {
            get { return (Style)PrintControl0.FindResource("DgCellStyle"); }
        }

        //private static void OnSetTextChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        //{
        //    throw new NotImplementedException();
        //}

        /// object model
        //public Style ColumnHdrStyle { get { return (Style)GetValue("ColumnHdrStyle"); } set { SetValue("ColumnHdrStyle", value); } }
        public string SNo { get { return (string)GetValue("S/No"); } set { SetValue("S/No", value); } }
        public string PPID { get { return (string)GetValue("PPID"); } set { SetValue("PPID", value); } }
        public string Line { get { return (string)GetValue("Line"); } set { SetValue("Line", value); } }
        public string Color { get { return (string)GetValue("Color"); } set { SetValue("Color", value); } }
        public string Names { get { return (string)GetValue("Names"); } set { SetValue("Names", value); } }
        public double Net { get { return (double)GetDoubleValue("Net"); } set { SetValue("Net", value); } }
        public double GradeStep { get { return (double)GetDoubleValue("GradeStep"); } set { SetValue("GradeStep", value); } }
        public double Gross { get { return (double)GetDoubleValue("Gross"); } set { SetValue("Gross", value); } }
        public double CoopDebit { get { return (double)GetDoubleValue("CoopDebit"); } set { SetValue("CoopDebit", value); } }
        public bool Archived { get { return (bool)GetDoubleValue("Archived"); } set { SetValue("Archived", value); } }
        public int Consistence { get { return (int)GetDoubleValue("Consistence"); } set { SetValue("Consistence", value); } }

        public DataGrid DftDataGrid { get { return (DataGrid)GetValue("DftDataGrid"); } set { SetValue("DftDataGrid", value); } }
        public ScrollViewer DgScrollView { get { return (ScrollViewer)GetValue("DgScrollView"); } set { SetValue("DgScrollView", value); } }
        public ICollectionView DataSource { get { return (ICollectionView)GetValue("DataSource"); } set { SetValue("DataSource", (ICollectionView)value); } }

        public static string[] InputData { get; set; }

        static Dictionary<string, object> _values = new Dictionary<string, object>();

        object GetDoubleValue(string p)
        {
            //object value;
            _values.TryGetValue(p, out object value);
            return value ?? 0;

        }


        object GetValue(string p)
        {
            //object value;
            _values.TryGetValue(p, out object value);
            return value;
        }

        void SetValue(string p, object value)
        {
            if (!object.Equals(value, GetValue(p)))
            {
                _values[p] = value;
                ///Identifies and assingn input data to DataGrid
                if (DataSource != null && (value as ListCollectionView != null))
                    dataGrid.ItemsSource = (ListCollectionView)value;
                OnPropertyChanged(p);
            }
        }


        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string p)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(p));
        }

        protected override void OnPropertyChanged(DependencyPropertyChangedEventArgs e)
        {
            var name = e.Property.Name;
            base.OnPropertyChanged(e);
        }


        public static string[] GetLines()
        {
            return _lines;
        }
        public static string[] GetColors()
        {
            return _colors;
        }

        #region IEditableObject Members

        static Dictionary<string, object> _clone;
        public void BeginEdit()
        {
            if (_clone == null)
            {
                _clone = new Dictionary<string, object>();
            }
            _clone.Clear();
            foreach (var key in _values.Keys)
            {
                _clone[key] = _values[key];
            }
        }
        public void CancelEdit()
        {
            _values.Clear();
            foreach (var key in _clone.Keys)
            {
                _values[key] = _clone[key];
            }
        }
        public void EndEdit()
        {
        }

        //private void _btnPreview_Click(object sender, RoutedEventArgs e)
        //{

        //    var pd = new PrintDialog();

        //    // calculate page size
        //    var sz = new Size(pd.PrintableAreaWidth, pd.PrintableAreaHeight);

        //    // create paginator
        //    //var paginator = new PattnPaginator(dataGrid, ScaleMode.PageWidth, sz, new Thickness(96 / 4), 100);

        //    string tempFileName = System.IO.Path.GetTempFileName();

        //    File.Delete(tempFileName);

        //    using (XpsDocument xpsDocument = new XpsDocument(tempFileName, FileAccess.ReadWrite))
        //    {
        //        XpsDocumentWriter writer = XpsDocument.CreateXpsDocumentWriter(xpsDocument);
        //        if (paginator.PageCount < 1) return;
        //        writer.Write(paginator);
        //        DocumentViewer previewWindow = new DocumentViewer
        //        {

        //            Document = xpsDocument.GetFixedDocumentSequence()
        //        };

        //        Window printpriview = new Window();
        //        printpriview.Content = previewWindow;
        //        printpriview.Title = "C1FlexGrid: Print Preview";
        //        printpriview.Show();

        //    }
        //}

        /// <summary>
        /// Create and return a columns dependency propts (as LocalValueEntry[])
        /// which is suitable for cloning the columns of the specified parameter 
        /// (DataGrid) belongs.
        /// </summary>
        /// <param name="dataGrid">The data</param>
        /// <returns></returns>
        private static List<LocalValueEntry[]> GetColumDepdPropts(DataGrid dataGrid)
        {
            var colDenpdProptsList = new List<LocalValueEntry[]>(dataGrid.Columns.Count);


            for (int x = 0; x < dataGrid.Columns.Count; x++)
            {
                var colDbPropts = new List<LocalValueEntry>();

                DataGridColumn dgCol = dataGrid.Columns[x];
                var enut = dgCol.GetLocalValueEnumerator();

                while (enut.MoveNext())
                {
                    LocalValueEntry colPropt = (LocalValueEntry)enut.Current;
                    if (colPropt == null || colPropt.Property.ReadOnly)
                        continue;

                    colDbPropts.Add(colPropt);
                }

                //LocalValueEntry[] dependPropts = GetDependecyPropts(dgCol);

                colDenpdProptsList.Add(colDbPropts.ToArray());
            }


            /////DnD ToDo: Sample Usage:
            //var newDgPage = new DataGrid();
            //foreach (LocalValueEntry[] dps in ColDpList)
            //{
            //    int rowIndex = ColDpList.IndexOf(dps);
            //    //DnD: Each new column is inititialize with  DataGridTextColumn
            //    ///befor assigning actual column type below.
            //    newDgPage.Columns.Add(new DataGridTextColumn());
            //    //LocalValueEntry[] dps = (LocalValueEntry[])ColDpList[k][1];
            //    ///DnD The actual  DataGridColumn Type and data is now applied 
            //    ///from the cloned columns's dependency propts.
            //    foreach (LocalValueEntry dp in dps)
            //        newDgPage.Columns[rowIndex].SetValue(dp.Property, dp.Value);
            //}

            return colDenpdProptsList;
        }
        private async Task<DataGridRow[]> ReapDataGrid(DataGrid dataGrid)
        {

            List<object> copiedRows = new List<object>();
            List<DataGridRow> dgRows = new List<DataGridRow>();

            foreach (object o in dataGrid.Items)
            {
                int x = dataGrid.Items.IndexOf(o);
                DataGridRow row = (DataGridRow)dataGrid.ItemContainerGenerator.ContainerFromIndex(x);
                //object rowIitem = dataGrid.Items[x];
                //row.Margin = new Thickness(0, 0, 0, 0);
                dgRows.Add(row);

                //if (!row.Item.Equals(rowIitem))
                //    ;

                //copiedRows.Add(rowIitem);
            }
            var dpsPropts = GetColumDepdPropts(dataGrid);

            dataGrid.ItemsSource = copiedRows;

            var rowArray = dgRows.ToArray();

            return rowArray;
        }


        //public delegate Task<FixedDocument> PrintAsyncDgt();
        //public delegate DataGrid[] SubPagesDgt(double printHeight, bool preview);
        //public delegate FixedDocument PrintTaskDgt(ProcessPrint printProce, PageMediaSize mediSize);

        //private async void PrintProfile(DataGrid dgToPrint)
        //{
        //    ProcessPrint printProce = new ProcessPrint(dgToPrint);
        //    printProce.PreviewMod = PrintPreview.AllPages;


        //    await printProce.ReapedItemSource();

        //    //dgToPrint.ItemsSource = task.Result;
        //    //task.Wait();

        //    FixedDocument fixedDoc = null;
        //    PrintDialog pDlg = new PrintDialog();
        //    //if (!pDlg.ShowDialog().Value)
        //    //    return;

        //    var medSize = pDlg.PrintTicket.PageMediaSize;

        //    try
        //    {

        //        MethodInfo mth = typeof(PrintControl).GetMethod("DispatcherPrint", new Type[] { typeof(ProcessPrint), typeof(PageMediaSize) });//.GetMethod("GetColumDepdPropts2", BindingFlags.Public | BindingFlags.Static);

        //        Delegate dlg = Delegate.CreateDelegate(typeof(PrintTaskDgt), this, mth);
        //        var pageObjs = dataGrid.Dispatcher.Invoke(method: dlg, args: new object[] { printProce, medSize });


        //        fixedDoc = (FixedDocument)pageObjs;

        //    }
        //    catch (Exception ex)
        //    {

        //    }



        //}


        //private async void PrintProfile(object printPrObj)
        //{
        //    var printProce = printPrObj as ProcessPrint;
        //    FixedDocument fixedDoc = null;
        //    PrintDialog pDlg = new PrintDialog();
        //    //if (!pDlg.ShowDialog().Value)
        //    //    return;
        //    //await printProce.ReapedItemSource();
        //    var medSize = pDlg.PrintTicket.PageMediaSize;

        //    try
        //    {

        //        MethodInfo mth = typeof(PrintControl).GetMethod("DispatcherPrint", new Type[] { typeof(ProcessPrint), typeof(PageMediaSize) });//.GetMethod("GetColumDepdPropts2", BindingFlags.Public | BindingFlags.Static);

        //        Delegate dlg = Delegate.CreateDelegate(typeof(PrintTaskDgt), this, mth);
        //        var pageObjs = dataGrid.Dispatcher.Invoke(method: dlg, args: new object[] { printProce, medSize });


        //        fixedDoc = (FixedDocument)pageObjs;

        //    }
        //    catch (Exception ex)
        //    {

        //    }



        //}

        public FixedDocument DispatcherPrint(ProcessPrint printProce, PageMediaSize medSize)
        {


            var paperSize = new Size(medSize.Width.Value, medSize.Height.Value);
            var printHeight = paperSize.Height - (40 + GuiStat.PrintMargin.Top + GuiStat.PrintMargin.Bottom);
            Double printableHeight = printHeight;// printSize.Height;
            FixedDocument fxDoc = null;
            try
            {
                var dgPages = printProce.GetDgPages(printableHeight);//.GetDataGridPages(printableHeight);
                fxDoc = printProce.GetFixDoc(dgPages, paperSize, GuiStat.PrintMargin);
            }
            catch (Exception ex)
            {

            }
            return fxDoc;
        }

        //private void PrintProfile2(object printPrObj)
        //{
        //    var printProce = printPrObj as ProcessPrint;
        //    FixedDocument fixedDoc = null;
        //    PrintDialog pDlg = new PrintDialog();
        //    //if (!pDlg.ShowDialog().Value)
        //    //    return;

        //    var medSize = pDlg.PrintTicket.PageMediaSize;
        //    Thickness minMarg = new Thickness(40);
        //    minMarg.Right = 27.75;
        //    var paperSize = new Size(medSize.Width.Value, medSize.Height.Value);
        //    var printHeight = paperSize.Height - (40 + minMarg.Top + minMarg.Bottom);
        //    Double printableHeight = printHeight;// printSize.Height;
        //    try
        //    {
        //        MethodInfo mth = typeof(ProcessPrint).GetMethod("GetDgPages", new Type[] { typeof(double), typeof(Boolean) });//.GetMethod("GetColumDepdPropts2", BindingFlags.Public | BindingFlags.Static);

        //        Delegate dlg = Delegate.CreateDelegate(typeof(SubPagesDgt), printProce, mth);
        //        var pageObjs = dataGrid.Dispatcher.Invoke(method: dlg, args: new object[] { printHeight, false });
        //        /* var task = await GetColumDepdPropts(dataGrid);*/

        //        var dgPages = (DataGrid[])pageObjs;

        //        //dgPages = printProce.GetDataGridPages(printableHeight, false);
        //        var task = printProce.GetFixDoc(dgPages, paperSize, minMarg);

        //    }
        //    catch (Exception ex)
        //    {

        //    }



        //}

        //private async Task<FixedDocument> PrintProfile3(DataGrid originalDg)
        //{

        //    FixedDocument fixedDoc = null;
        //    PrintDialog pDlg = new PrintDialog();
        //    //if (!pDlg.ShowDialog().Value)
        //    //    return;

        //    var medSize = pDlg.PrintTicket.PageMediaSize;
        //    Thickness minMarg = new Thickness(40);
        //    minMarg.Right = 27.75;
        //    var paperSize = new Size(medSize.Width.Value, medSize.Height.Value);
        //    var printHeight = paperSize.Height - (40 + minMarg.Top + minMarg.Bottom);
        //    Double printableHeight = printHeight;// printSize.Height;
        //    try
        //    {
        //        ProcessPrint printProce = new ProcessPrint(originalDg);

        //        List<object> itemSource = await printProce.ReapedItemSource();
        //        originalDg.ItemsSource = itemSource;

        //        var dgPages = printProce.GetDgPages(printableHeight);
        //        var task = printProce.GetFixDoc(dgPages, paperSize, minMarg);

        //        //while (task.Status == TaskStatus.WaitingForActivation)
        //        //    task.Wait(1);
        //        //originalDg.UpdateLayout();

        //        //task.Wait();
        //    }
        //    catch (Exception ex)
        //    {

        //    }

        //    return fixedDoc;
        //}

        //private async Task<FixedDocument> PrintProfileX(DataGrid originalDg)
        //{

        //    FixedDocument fixedDoc = null;
        //    PrintDialog pDlg = new PrintDialog();
        //    //if (!pDlg.ShowDialog().Value)
        //    //    return;

        //    var medSize = pDlg.PrintTicket.PageMediaSize;
        //    Thickness minMarg = new Thickness(40);
        //    minMarg.Right = 27.75;
        //    var paperSize = new Size(medSize.Width.Value, medSize.Height.Value);
        //    var printHeight = paperSize.Height - (40 + minMarg.Top + minMarg.Bottom);
        //    Double printableHeight = printHeight;// printSize.Height;
        //    try
        //    {

        //        //List<LocalValueEntry[]> colDpList =
        //        //WpfPrinting.ReapDagaGrid(ref originalDg, out DataGridRow[] clonedRows);
        //        Task<DataGridRow[]> clonedDgCols = ReapDataGrid(originalDg);

        //        DataGridRow[] clonedRows = clonedDgCols.Result;
        //        var itemSource = clonedRows.Select(r => r.Item).ToArray();
        //        dataGrid.ItemsSource = itemSource;

        //        WpfPrinting print = new WpfPrinting();


        //        var dgPages = print.GetDataGridPages(clonedRows, printableHeight, false).Result;
        //        var task = print.GetFixDoc(dgPages, paperSize, minMarg, true);
        //        fixedDoc = task.Result;

        //        while (task.Status == TaskStatus.WaitingForActivation)
        //            task.Wait(1);


        //        //task.Wait();
        //    }
        //    catch (Exception ex)
        //    {

        //    }

        //    return fixedDoc;
        //    //  Thread thr = new Thread(parThr);
        //    //      thr.SetApartmentState(ApartmentState.STA);
        //    //      thr.Name = "PrintProfile";

        //    //      thr.Start(dataGrid);

        //    //var dgPages =    print.GetDgPagesAsync((DataGrid)dgObj, false);

        //}


        private void DispTimer_Tick(object sender, EventArgs e)
        {
            if (PrintSet)
                ProcessPrint = true;
            PrintSet = false;

        }


        private void btnPrint_Click(object sender, RoutedEventArgs e)
        {

            if (true)
            {
                //Thread.CurrentThread.SetApartmentState(ApartmentState.MTA);
                ApartmentState aSt = Thread.CurrentThread.GetApartmentState();

            reProcess:
                dispTimer.Stop();
                dispTimer.Interval = new TimeSpan(0, 0, 1);
                PrintSet = true;
                dispTimer.Start();
                return;

            }


        }

        private void dataGrid_RowEditEnding(object sender, DataGridRowEditEndingEventArgs e)
        {

        }

        private void dataGrid_RowDetailsVisibilityChanged(object sender, DataGridRowDetailsEventArgs e)
        {

        }



        #endregion



        private void ContentPresenter_Selected(object sender, RoutedEventArgs e)
        {

        }


        private void dataGrid_LoadingRowDetails(object sender, DataGridRowDetailsEventArgs e)
        {

        }

        private void _btnPreview_Click(object sender, RoutedEventArgs e)
        {

        }

        private void dataGrid_LoadingRow(object sender, DataGridRowEventArgs e)
        {

        }
    }

}
