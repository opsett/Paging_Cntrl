﻿using SharedResource;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Printing;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Xps;
using System.Windows.Xps.Packaging;

namespace PagingControl
{
    /// <summary>
    /// Interaction logic for UserControl1.xaml
    /// </summary>
    public partial class DataGridMgr : UserControl
    {
        public DataGridMgr()
        {
            InitializeComponent();

            DftDataGrid = dataGrid;
            DftDataGrid.Style = ColumnHdrStyle;

            DftDataGrid.ItemContainerGenerator.ItemsChanged += ItemContainerGenerator_ItemsChanged;
            dataGrid.LoadingRowDetails += dataGrid_LoadingRowDetails;
            PrintDgt += DispathPrintAsync;

            //dispTimer = new System.Windows.Threading.DispatcherTimer(System.Windows.Threading.DispatcherPriority.Background);
            //dispTimer.Interval = new TimeSpan(0, 0, 10);
            //dispTimer.Tick += DispTimer_Tick;
            //dispTimer.Start();

            DgScrollView = null;// dgScrollView;
        }


        private void dataGrid_LoadingRowDetails(object sender, DataGridRowDetailsEventArgs e)
        {

        }

        private event Action<bool> PrintDgt;

        private bool PrintSet;
        private bool ProcessPrint
        {
            /*protected internal*/
            set
            {
                ///DnD: The event handle 'IsDone' sends a triger to all methods assigned
                ///to it from anywhere. Such assigned methods or delegated method is can
                ///be regarded as a subscriber to the event. There can be multiple
                ///subscribers to an event. However, the value of the EventHandle,"IsDone"
                ///will be null if no localor external method is subscribing or assigned
                ///to it and it should not be invoked without subscribers 
                if (PrintDgt != null)
                    PrintDgt.Invoke(value);

                PrintSet = value;
            }

            get { return PrintSet; }
        }

        public delegate Task<FixedDocument> PrintAsyncDgt();
        public void DispathPrintAsync(bool boolObj)
        {
            /*||object PrintPreview previewMode*/
            //    ProcessPrint printProce = new ProcessPrint(dataGrid);
            //    printProce.PreviewMod = PrintPreview.AllPages;
            //    await printProce.ReapedItemSource();
            //    PrintProfile(printProce);
            PrintSet = false;

            MethodInfo mth = this.GetType().GetMethod("DispatcherPrintAsync");//, new Type[] { typeof(ProcessPrint), typeof(PageMediaSize) });//.GetMethod("GetColumDepdPropts2", BindingFlags.Public | BindingFlags.Static);

            Delegate dlg = Delegate.CreateDelegate(typeof(PrintAsyncDgt), this, mth);
            Task.Run(() => dataGrid.Dispatcher.Invoke(method: dlg, args: null));

            /*await*/
            //DispatcherPrintAsync();
        }

        public async Task<FixedDocument> DispatcherPrintAsync()
        {
            //FixedDocument fixedDoc = null;
            FixedDocument fxDoc = null;

        ReProcess:

        reTest:
            try
            {


                ProcessPrint printProce = new ProcessPrint(dataGrid);

                printProce.PreviewMod = PrintPreview.AllPages;


                await printProce.ReapedItemSource();

                //dgToPrint.ItemsSource = task.Result;
                //task.Wait();

                PrintDialog pDlg = new PrintDialog();
                //if (!pDlg.ShowDialog().Value)
                //    return null;

                //ProcessPrint printProce;
                PageMediaSize medSize = pDlg.PrintTicket.PageMediaSize;
                //goto ReProcess;// null;

                var paperSize = new Size(medSize.Width.Value, medSize.Height.Value);
                var printHeight = paperSize.Height - (40 + GuiStat.PrintMargin.Top + GuiStat.PrintMargin.Bottom);
                Double printableHeight = printHeight;// printSize.Height;

                //dgPages = dgPages;
                var dgPages = printProce.GetDgPages(printableHeight);//.GetDataGridPages(printableHeight);
                fxDoc = printProce.GetFixDoc(dgPages, paperSize, GuiStat.PrintMargin);
            }
            catch (Exception ex)
            {
                //goto reTest;
            }
            return fxDoc;
        }


        public async Task<DataGrid[]> GetWorkSheets(DataGrid dg, PageMediaSize mediaSize)
        {

            //FixedDocument fixedDoc = null;
            FixedDocument fxDoc = null;

            //ReProcess:
            DataGrid[] dgPages= null;
        //reTest:
            try
            {


                ProcessPrint printProce = new ProcessPrint(dg);

                printProce.PreviewMod = PrintPreview.AllPages;


                await printProce.ReapedItemSource();

                ////dgToPrint.ItemsSource = task.Result;
                ////task.Wait();

                //PrintDialog pDlg = new PrintDialog();
                ////if (!pDlg.ShowDialog().Value)
                ////    return null;

                ////ProcessPrint printProce;
                ////PageMediaSize mediaSize = mediaSize;// pDlg.PrintTicket.PageMediaSize;
                ////goto ReProcess;// null;

                var paperSize = new Size(mediaSize.Width.Value, mediaSize.Height.Value);
                var printHeight = paperSize.Height - (40 + GuiStat.PrintMargin.Top + GuiStat.PrintMargin.Bottom);
                Double printableHeight = printHeight;// printSize.Height;

                dgPages = printProce.GetDgPages(printableHeight);//.GetDataGridPages(printableHeight);


                //fxDoc = printProce.GetFixDoc(dgPages, paperSize, GuiStat.PrintMargin);


            }
            catch (Exception ex)
            {
                //goto reTest;
            }
            return dgPages;
        }

        public async Task<DataGrid[]> GetWorkSheets(DataGrid dg, PageMediaSize mediaSize,  TabControlMgr tabCtrMgr)
        {

            //FixedDocument fixedDoc = null;
            FixedDocument fxDoc = null;

            //ReProcess:
            DataGrid[] dgPages= null;
        //reTest:
            try
            {


                ProcessPrint printProce = new ProcessPrint(dg);

                printProce.PreviewMod = PrintPreview.AllPages;


                await printProce.ReapedItemSource();

                ////dgToPrint.ItemsSource = task.Result;
                ////task.Wait();

                //PrintDialog pDlg = new PrintDialog();
                ////if (!pDlg.ShowDialog().Value)
                ////    return null;

                ////ProcessPrint printProce;
                ////PageMediaSize mediaSize = mediaSize;// pDlg.PrintTicket.PageMediaSize;
                ////goto ReProcess;// null;

                var paperSize = new Size(mediaSize.Width.Value, mediaSize.Height.Value);
                var printHeight = paperSize.Height - (40 + GuiStat.PrintMargin.Top + GuiStat.PrintMargin.Bottom);
                Double printableHeight = printHeight;// printSize.Height;

                dgPages = printProce.GetDgPages2(printableHeight, ref tabCtrMgr);//.GetDataGridPages(printableHeight);


                //fxDoc = printProce.GetFixDoc(dgPages, paperSize, GuiStat.PrintMargin);



            }
            catch (Exception ex)
            {
                //goto reTest;
            }
            return dgPages;
        }

        public async Task<ScrollViewer[]> GetScrViews(DataGrid dg, PageMediaSize mediaSize)
        {

            //FixedDocument fixedDoc = null;
            FixedDocument fxDoc = null;

            //ReProcess:
            ScrollViewer[] dgPages= null;
        //reTest:
            try
            {


                ProcessPrint printProce = new ProcessPrint(dg);

                printProce.PreviewMod = PrintPreview.AllPages;


                await printProce.ReapedItemSource();

                ////dgToPrint.ItemsSource = task.Result;
                ////task.Wait();

                //PrintDialog pDlg = new PrintDialog();
                ////if (!pDlg.ShowDialog().Value)
                ////    return null;

                ////ProcessPrint printProce;
                ////PageMediaSize mediaSize = mediaSize;// pDlg.PrintTicket.PageMediaSize;
                ////goto ReProcess;// null;

                var paperSize = new Size(mediaSize.Width.Value, mediaSize.Height.Value);
                var printHeight = paperSize.Height - (40 + GuiStat.PrintMargin.Top + GuiStat.PrintMargin.Bottom);
                Double printableHeight = printHeight;// printSize.Height;

                dgPages = printProce.GetDgPages3(printableHeight);//.GetDataGridPages(printableHeight);


                //fxDoc = printProce.GetFixDoc(dgPages, paperSize, GuiStat.PrintMargin);



            }
            catch (Exception ex)
            {
                //goto reTest;
            }
            return dgPages;
        }

        private void OnLoadingRow(object sender, DataGridRowEventArgs e)
        {
            e.Row.Header = (e.Row.GetIndex() + 1).ToString().PadLeft(dataGrid.Items.Count.ToString().Length, '0');
        }


        //private void ContentPresenter_DataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
        //{

        //}

        System.Windows.Threading.DispatcherTimer dispTimer { get; set; }
 

        private void ItemContainerGenerator_ItemsChanged(object sender, ItemsChangedEventArgs e)
        {
            if (e.ItemCount < 1) return;
            int index = e.Position.Index;
            DataGridRow dRow = (DataGridRow)dataGrid.Items[0];
            return;
            //get all DataGridRow elements in the visual tree
            IEnumerable<DataGridRow> rows = FindVisualChildren<DataGridRow>(dRow);
            foreach (DataGridRow row in rows)
            {
                row.Header = (row.GetIndex() + 1).ToString();
            }
        }

        private static IEnumerable<T> FindVisualChildren<T>(DependencyObject dependencyObject)
            where T : DependencyObject
        {
            if (dependencyObject != null)
            {
                for (int i = 0; i < VisualTreeHelper.GetChildrenCount(dependencyObject); i++)
                {
                    DependencyObject child = VisualTreeHelper.GetChild(dependencyObject, i);
                    if (child != null && child is T)
                    {
                        yield return (T)child;
                    }

                    foreach (T childOfChild in FindVisualChildren<T>(child))
                    {
                        yield return childOfChild;
                    }
                }
            }
        }

        //public PrintCommand PrintData { get => DataSource == null ? new PrintCommand() : new PrintCommand(DftDataGrid); }


        static string[] _lines = "Computers|Washers|Stoves".Split('|');
        static string[] _colors = "Red|Green|Blue|White".Split('|');


        public static readonly DependencyProperty ColumnHdrStyleProperty =
            DependencyProperty.Register("ColumnHdrStyle", typeof(Style), typeof(Control)/*,
              new  PropertyMetadata(false, new PropertyChangedCallback(OnSetTextChanged))*/);


        public Style ColumnHdrStyle
        {
            get { return (Style)GetValue(ColumnHdrStyleProperty); }
            set { SetValue(ColumnHdrStyleProperty, value); }
        }



        private static DataGridMgr PrintControl0 => new DataGridMgr();
        public static Style GetColumnHdrStyle
        {
            get { return (Style)PrintControl0.FindResource("ColumnHeaderStyle1"); }
        }


        public static Style GetDgRowStyle
        {
            get { return (Style)PrintControl0.FindResource("DgCellStyle"); }
        }

        //private static void OnSetTextChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        //{
        //    throw new NotImplementedException();
        //}

        /// object model
        //public Style ColumnHdrStyle { get { return (Style)GetValue("ColumnHdrStyle"); } set { SetValue("ColumnHdrStyle", value); } }
        public string SNo { get { return (string)GetValue("S/No"); } set { SetValue("S/No", value); } }
        public string PPID { get { return (string)GetValue("PPID"); } set { SetValue("PPID", value); } }
        public string Line { get { return (string)GetValue("Line"); } set { SetValue("Line", value); } }
        public string Color { get { return (string)GetValue("Color"); } set { SetValue("Color", value); } }
        public string Names { get { return (string)GetValue("Names"); } set { SetValue("Names", value); } }
        public double Net { get { return (double)GetDoubleValue("Net"); } set { SetValue("Net", value); } }
        public double GradeStep { get { return (double)GetDoubleValue("GradeStep"); } set { SetValue("GradeStep", value); } }
        public double Gross { get { return (double)GetDoubleValue("Gross"); } set { SetValue("Gross", value); } }
        public double CoopDebit { get { return (double)GetDoubleValue("CoopDebit"); } set { SetValue("CoopDebit", value); } }
        public bool Archived { get { return (bool)GetDoubleValue("Archived"); } set { SetValue("Archived", value); } }
        public int Consistence { get { return (int)GetDoubleValue("Consistence"); } set { SetValue("Consistence", value); } }

        public DataGrid DftDataGrid { get { return (DataGrid)GetValue("DftDataGrid"); } set { SetValue("DftDataGrid", value); } }
        public ScrollViewer DgScrollView { get { return (ScrollViewer)GetValue("DgScrollView"); } set { SetValue("DgScrollView", value); } }
        public ICollectionView DataSource { get { return (ICollectionView)GetValue("DataSource"); } set { SetValue("DataSource", (ICollectionView)value); } }

        public static string[] InputData { get; set; }

        static Dictionary<string, object> _values = new Dictionary<string, object>();

        object GetDoubleValue(string p)
        {
            //object value;
            _values.TryGetValue(p,out object value);
            return value ?? 0;

        }


        object GetValue(string p)
        {
            //object value;
            _values.TryGetValue(p, out object value);
            return value;
        }

        void SetValue(string p, object value)
        {
            if (!object.Equals(value, GetValue(p)))
            {
                _values[p] = value;
                ///Identifies and assingn input data to DataGrid
                if (DataSource != null && (value as ListCollectionView != null))
                    dataGrid.ItemsSource = (ListCollectionView)value;
                OnPropertyChanged(p);
            }
        }


        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string p)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(p));
        }

        protected override void OnPropertyChanged(DependencyPropertyChangedEventArgs e)
        {
            var name = e.Property.Name;
            base.OnPropertyChanged(e);
        }


        public static string[] GetLines()
        {
            return _lines;
        }
        public static string[] GetColors()
        {
            return _colors;
        }

        #region IEditableObject Members

        static Dictionary<string, object> _clone;
        public void BeginEdit()
        {
            if (_clone == null)
            {
                _clone = new Dictionary<string, object>();
            }
            _clone.Clear();
            foreach (var key in _values.Keys)
            {
                _clone[key] = _values[key];
            }
        }
        public void CancelEdit()
        {
            _values.Clear();
            foreach (var key in _clone.Keys)
            {
                _values[key] = _clone[key];
            }
        }
        public void EndEdit()
        {
        }
        #endregion

        /// <summary>
        /// Create and return a columns dependency propts (as LocalValueEntry[])
        /// which is suitable for cloning the columns of the specified parameter 
        /// (DataGrid) belongs.
        /// </summary>
        /// <param name="dataGrid">The data</param>
        /// <returns></returns>
        private static List<LocalValueEntry[]> GetColumDepdPropts(DataGrid dataGrid)
        {
            var colDenpdProptsList = new List<LocalValueEntry[]>(dataGrid.Columns.Count);


            for (int x = 0; x < dataGrid.Columns.Count; x++)
            {
                var colDbPropts = new List<LocalValueEntry>();

                DataGridColumn dgCol = dataGrid.Columns[x];
                var enut = dgCol.GetLocalValueEnumerator();

                while (enut.MoveNext())
                {
                    LocalValueEntry colPropt = (LocalValueEntry)enut.Current;
                    if (colPropt == null || colPropt.Property.ReadOnly)
                        continue;

                    colDbPropts.Add(colPropt);
                }

                //LocalValueEntry[] dependPropts = GetDependecyPropts(dgCol);

                colDenpdProptsList.Add(colDbPropts.ToArray());
            }


            /////DnD ToDo: Sample Usage:
            //var newDgPage = new DataGrid();
            //foreach (LocalValueEntry[] dps in ColDpList)
            //{
            //    int rowIndex = ColDpList.IndexOf(dps);
            //    //DnD: Each new column is inititialize with  DataGridTextColumn
            //    ///befor assigning actual column type below.
            //    newDgPage.Columns.Add(new DataGridTextColumn());
            //    //LocalValueEntry[] dps = (LocalValueEntry[])ColDpList[k][1];
            //    ///DnD The actual  DataGridColumn Type and data is now applied 
            //    ///from the cloned columns's dependency propts.
            //    foreach (LocalValueEntry dp in dps)
            //        newDgPage.Columns[rowIndex].SetValue(dp.Property, dp.Value);
            //}

            return colDenpdProptsList;
        }
        private async Task<DataGridRow[]> ReapDataGrid(DataGrid dataGrid)
        {

            List<object> copiedRows = new List<object>();
            List<DataGridRow> dgRows = new List<DataGridRow>();

            foreach (object o in dataGrid.Items)
            {
                int x = dataGrid.Items.IndexOf(o);
                DataGridRow row = (DataGridRow)dataGrid.ItemContainerGenerator.ContainerFromIndex(x);
                //object rowIitem = dataGrid.Items[x];
                //row.Margin = new Thickness(0, 0, 0, 0);
                dgRows.Add(row);

                //if (!row.Item.Equals(rowIitem))
                //    ;

                //copiedRows.Add(rowIitem);
            }
            var dpsPropts = GetColumDepdPropts(dataGrid);

            dataGrid.ItemsSource = copiedRows;

            var rowArray = dgRows.ToArray();

            return rowArray;
        }


        //public delegate Task<FixedDocument> PrintAsyncDgt();
        //public delegate DataGrid[] SubPagesDgt(double printHeight, bool preview);
        //public delegate FixedDocument PrintTaskDgt(ProcessPrint printProce, PageMediaSize mediSize);

        //private async void PrintProfile(DataGrid dgToPrint)
        //{
        //    ProcessPrint printProce = new ProcessPrint(dgToPrint);
        //    printProce.PreviewMod = PrintPreview.AllPages;


        //    await printProce.ReapedItemSource();

        //    //dgToPrint.ItemsSource = task.Result;
        //    //task.Wait();

        //    FixedDocument fixedDoc = null;
        //    PrintDialog pDlg = new PrintDialog();
        //    //if (!pDlg.ShowDialog().Value)
        //    //    return;

        //    var medSize = pDlg.PrintTicket.PageMediaSize;

        //    try
        //    {

        //        MethodInfo mth = typeof(PrintControl).GetMethod("DispatcherPrint", new Type[] { typeof(ProcessPrint), typeof(PageMediaSize) });//.GetMethod("GetColumDepdPropts2", BindingFlags.Public | BindingFlags.Static);

        //        Delegate dlg = Delegate.CreateDelegate(typeof(PrintTaskDgt), this, mth);
        //        var pageObjs = dataGrid.Dispatcher.Invoke(method: dlg, args: new object[] { printProce, medSize });


        //        fixedDoc = (FixedDocument)pageObjs;

        //    }
        //    catch (Exception ex)
        //    {

        //    }



        //}


        //private async void PrintProfile(object printPrObj)
        //{
        //    var printProce = printPrObj as ProcessPrint;
        //    FixedDocument fixedDoc = null;
        //    PrintDialog pDlg = new PrintDialog();
        //    //if (!pDlg.ShowDialog().Value)
        //    //    return;
        //    //await printProce.ReapedItemSource();
        //    var medSize = pDlg.PrintTicket.PageMediaSize;

        //    try
        //    {

        //        MethodInfo mth = typeof(PrintControl).GetMethod("DispatcherPrint", new Type[] { typeof(ProcessPrint), typeof(PageMediaSize) });//.GetMethod("GetColumDepdPropts2", BindingFlags.Public | BindingFlags.Static);

        //        Delegate dlg = Delegate.CreateDelegate(typeof(PrintTaskDgt), this, mth);
        //        var pageObjs = dataGrid.Dispatcher.Invoke(method: dlg, args: new object[] { printProce, medSize });


        //        fixedDoc = (FixedDocument)pageObjs;

        //    }
        //    catch (Exception ex)
        //    {

        //    }



        //}

        public FixedDocument DispatcherPrint(ProcessPrint printProce, PageMediaSize medSize)
        {


            var paperSize = new Size(medSize.Width.Value, medSize.Height.Value);
            var printHeight = paperSize.Height - (40 + GuiStat.PrintMargin.Top + GuiStat.PrintMargin.Bottom);
            Double printableHeight = printHeight;// printSize.Height;
            FixedDocument fxDoc = null;
            try
            {
                var dgPages = printProce.GetDgPages(printableHeight);//.GetDataGridPages(printableHeight);
                fxDoc = printProce.GetFixDoc(dgPages, paperSize, GuiStat.PrintMargin);
            }
            catch (Exception ex)
            {

            }
            return fxDoc;
        }

        //private void PrintProfile2(object printPrObj)
        //{
        //    var printProce = printPrObj as ProcessPrint;
        //    FixedDocument fixedDoc = null;
        //    PrintDialog pDlg = new PrintDialog();
        //    //if (!pDlg.ShowDialog().Value)
        //    //    return;

        //    var medSize = pDlg.PrintTicket.PageMediaSize;
        //    Thickness minMarg = new Thickness(40);
        //    minMarg.Right = 27.75;
        //    var paperSize = new Size(medSize.Width.Value, medSize.Height.Value);
        //    var printHeight = paperSize.Height - (40 + minMarg.Top + minMarg.Bottom);
        //    Double printableHeight = printHeight;// printSize.Height;
        //    try
        //    {
        //        MethodInfo mth = typeof(ProcessPrint).GetMethod("GetDgPages", new Type[] { typeof(double), typeof(Boolean) });//.GetMethod("GetColumDepdPropts2", BindingFlags.Public | BindingFlags.Static);

        //        Delegate dlg = Delegate.CreateDelegate(typeof(SubPagesDgt), printProce, mth);
        //        var pageObjs = dataGrid.Dispatcher.Invoke(method: dlg, args: new object[] { printHeight, false });
        //        /* var task = await GetColumDepdPropts(dataGrid);*/

        //        var dgPages = (DataGrid[])pageObjs;

        //        //dgPages = printProce.GetDataGridPages(printableHeight, false);
        //        var task = printProce.GetFixDoc(dgPages, paperSize, minMarg);

        //    }
        //    catch (Exception ex)
        //    {

        //    }



        //}

        //private async Task<FixedDocument> PrintProfile3(DataGrid originalDg)
        //{

        //    FixedDocument fixedDoc = null;
        //    PrintDialog pDlg = new PrintDialog();
        //    //if (!pDlg.ShowDialog().Value)
        //    //    return;

        //    var medSize = pDlg.PrintTicket.PageMediaSize;
        //    Thickness minMarg = new Thickness(40);
        //    minMarg.Right = 27.75;
        //    var paperSize = new Size(medSize.Width.Value, medSize.Height.Value);
        //    var printHeight = paperSize.Height - (40 + minMarg.Top + minMarg.Bottom);
        //    Double printableHeight = printHeight;// printSize.Height;
        //    try
        //    {
        //        ProcessPrint printProce = new ProcessPrint(originalDg);

        //        List<object> itemSource = await printProce.ReapedItemSource();
        //        originalDg.ItemsSource = itemSource;

        //        var dgPages = printProce.GetDgPages(printableHeight);
        //        var task = printProce.GetFixDoc(dgPages, paperSize, minMarg);

        //        //while (task.Status == TaskStatus.WaitingForActivation)
        //        //    task.Wait(1);
        //        //originalDg.UpdateLayout();

        //        //task.Wait();
        //    }
        //    catch (Exception ex)
        //    {

        //    }

        //    return fixedDoc;
        //}

        //private async Task<FixedDocument> PrintProfileX(DataGrid originalDg)
        //{

        //    FixedDocument fixedDoc = null;
        //    PrintDialog pDlg = new PrintDialog();
        //    //if (!pDlg.ShowDialog().Value)
        //    //    return;

        //    var medSize = pDlg.PrintTicket.PageMediaSize;
        //    Thickness minMarg = new Thickness(40);
        //    minMarg.Right = 27.75;
        //    var paperSize = new Size(medSize.Width.Value, medSize.Height.Value);
        //    var printHeight = paperSize.Height - (40 + minMarg.Top + minMarg.Bottom);
        //    Double printableHeight = printHeight;// printSize.Height;
        //    try
        //    {

        //        //List<LocalValueEntry[]> colDpList =
        //        //WpfPrinting.ReapDagaGrid(ref originalDg, out DataGridRow[] clonedRows);
        //        Task<DataGridRow[]> clonedDgCols = ReapDataGrid(originalDg);

        //        DataGridRow[] clonedRows = clonedDgCols.Result;
        //        var itemSource = clonedRows.Select(r => r.Item).ToArray();
        //        dataGrid.ItemsSource = itemSource;

        //        WpfPrinting print = new WpfPrinting();


        //        var dgPages = print.GetDataGridPages(clonedRows, printableHeight, false).Result;
        //        var task = print.GetFixDoc(dgPages, paperSize, minMarg, true);
        //        fixedDoc = task.Result;

        //        while (task.Status == TaskStatus.WaitingForActivation)
        //            task.Wait(1);


        //        //task.Wait();
        //    }
        //    catch (Exception ex)
        //    {

        //    }

        //    return fixedDoc;
        //    //  Thread thr = new Thread(parThr);
        //    //      thr.SetApartmentState(ApartmentState.STA);
        //    //      thr.Name = "PrintProfile";

        //    //      thr.Start(dataGrid);

        //    //var dgPages =    print.GetDgPagesAsync((DataGrid)dgObj, false);

        //}


        private void DispTimer_Tick(object sender, EventArgs e)
        {
            if (PrintSet)
                ProcessPrint = true;
            PrintSet = false;

        }


        private void btnPrint_Click(object sender, RoutedEventArgs e)
        {

            if (true)
            {
                //Thread.CurrentThread.SetApartmentState(ApartmentState.MTA);
                ApartmentState aSt = Thread.CurrentThread.GetApartmentState();

            reProcess:
                dispTimer.Stop();
                dispTimer.Interval = new TimeSpan(0, 0, 1);
                PrintSet = true;
                dispTimer.Start();
                return;

            }


        }

        private void _btnPreview_Click(object sender, RoutedEventArgs e)
        {

        }

        private void dataGrid_RowDetailsVisibilityChanged(object sender, DataGridRowDetailsEventArgs e)
        {

        }

        private void dataGrid_RowEditEnding(object sender, DataGridRowEditEndingEventArgs e)
        {

        }

    }



    public class ProcessPrint
    {
        public ProcessPrint(DataGrid originalDg)
        {
            this.DataGridRows = ReapDataGrid(ref originalDg, out var columnsDpList);
            this.ColumnsDpList = columnsDpList;
            //originalDg.Items.Count
        }




        /// <summary>
        /// The DataGrid colums dependency propts are assigned to this property
        /// for recoursive use incloning columns
        /// </summary>
        private List<LocalValueEntry[]> ColumnsDpList { get; }
        private DataGridRow[] DataGridRows { get; }

        private static List<object> ItemSource0 { get; set; }
        public async Task<List<object>> ReapedItemSource()
        {
            return ItemSource0;// DataGridRows.Select(r => r.Item).ToList();

        }

        public PrintPreview PreviewMod { get; set; }

        private DataGridRow[] ReapDataGrid(ref DataGrid dataGrid, out List<LocalValueEntry[]> columnDepdPropts)
        {
            ///DnD Reap column hearder and assing to local variable columnDepdPropts 
            columnDepdPropts = GetColumDepdPropts(dataGrid);

            List<object> copiedRows = new List<object>();
            List<DataGridRow> dgRows = new List<DataGridRow>();

            foreach (object o in dataGrid.Items)
            {
                int x = dataGrid.Items.IndexOf(o);
                DataGridRow row = (DataGridRow)dataGrid.ItemContainerGenerator.ContainerFromIndex(x);
               //row =  (DataGridRow)dataGrid.ItemContainerGenerator.ContainerFromItem(o);
                object rowIitem = dataGrid.Items[x];
                //row.Margin = new Thickness(0, 0, 0, 0);
                dgRows.Add(row);

                //if (!row.Item.Equals(rowIitem))
                //    ;

                copiedRows.Add(rowIitem);
            }
            dataGrid.ItemsSource = ItemSource0 = copiedRows;
            var rowArray = dgRows.ToArray();

            return rowArray;
        }


        public ProcessPrint()
        {
        }
        public const double cm = 37;
        public double Margin = 0.75 * cm;
        public double PageWidth = 21 * cm;
        public double PageHeight = 29 * cm;
        public double RowHeight = 0.7 * cm;
        public bool PageNumberVisibility = true;
        public bool DateVisibility = true;
        public double FontSize = 14;
        public double HeaderFontSize = 14;
        public bool IsBold = false;

        public FixedDocument GetFixDoc(IList dataGridPages, Size printSize, Thickness printMargin)
        {

            Double printableWidth = printSize.Width;
            Double printableHeight = printSize.Height;

            FixedDocument fixedDoc = new FixedDocument();

            var margin = printMargin;

            string now = DateTime.Now.ToString("dd/MMM/yyy");//.ToShortDateString();

            var pgs = dataGridPages.Count.ToString();
            foreach (DataGrid dg in dataGridPages)
            {

                // add date
                TextBlock dateText = new TextBlock();
                if (DateVisibility) dateText.Visibility = Visibility.Visible;
                else dateText.Visibility = Visibility.Hidden;

                dateText.Text = now;

                //List<DataGrid> dg = new List<DataGrid>();
                int pageNumber = dataGridPages.IndexOf(dg) + 1;


                // add page number
                TextBlock PageNumberText = new TextBlock();
                if (PageNumberVisibility) PageNumberText.Visibility = Visibility.Visible;
                else PageNumberText.Visibility = Visibility.Hidden;

                PageNumberText.Text = "Page : " + pageNumber.ToString().PadLeft(pgs.Length, '0') + "/" + dataGridPages.Count;
                PageNumberText.SetValue(TextElement.FontWeightProperty, FontWeights.Bold);


                FixedPage.SetTop(dateText, printableHeight - 25);
                FixedPage.SetLeft(dateText, Margin + margin.Left);

                FixedPage.SetTop(PageNumberText, printableHeight - 25);
                FixedPage.SetLeft(PageNumberText, Margin + (printableWidth - PageNumberText.Text.Length * 10) / 2);
                //var testIt = newDgPage.SelectedItem;


                //FixedPageFromCanvas(newDgPage, size, pageNumber, PageHeightWithMargin, PageHeightWithMargin);

                var size = new Size(printableWidth, printableHeight);

                var canv = Preview.GetVisualCanvas(dg, size, new Thickness(0));

                var fixedPage = new FixedPage
                {
                    Background = Brushes.White,
                    Width = printableWidth,
                    Height = printableHeight,
                    Margin = new Thickness(0),

                };

                //fixedPage.Children.Add(dateText);
                //fixedPage.Children.Add(PageNumberText);

                //fixedPage.Children.Add(newDgPage);
                FixedPage.SetLeft(canv, Margin + margin.Left);
                FixedPage.SetTop(canv, margin.Top);

                fixedPage.Children.Add(canv);
                fixedPage.Children.Add(dateText);
                fixedPage.Children.Add(PageNumberText);


                PageContent pageContent = new PageContent();
                ((IAddChild)pageContent).AddChild(fixedPage);


                fixedDoc.Pages.Add(pageContent);



            }
            if (PreviewMod == PrintPreview.AllPages)
                new Preview(fixedDoc.DocumentPaginator).ShowDialog();

            //await Task.Run(() => fixedDoc.GetType());

            return fixedDoc;
        }

        public async Task<FixedDocument> GetFixDocAsync(IList dataGridPages, Size printSize, Thickness printMargin, bool previewMode)
        {

            Double printableWidth = printSize.Width;
            Double printableHeight = printSize.Height;

            FixedDocument fixedDoc = new FixedDocument();

            var margin = printMargin;

            string now = DateTime.Now.ToShortDateString();

            foreach (DataGrid dg in dataGridPages)
            {

                // add date
                TextBlock dateText = new TextBlock();
                if (DateVisibility) dateText.Visibility = Visibility.Visible;
                else dateText.Visibility = Visibility.Hidden;

                dateText.Text = now;

                //List<DataGrid> dg = new List<DataGrid>();
                int pageNumber = dataGridPages.IndexOf(dg) + 1;


                // add page number
                TextBlock PageNumberText = new TextBlock();
                if (PageNumberVisibility) PageNumberText.Visibility = Visibility.Visible;
                else PageNumberText.Visibility = Visibility.Hidden;

                PageNumberText.Text = "Page : " + pageNumber;

                FixedPage.SetTop(dateText, printableHeight - 25);
                FixedPage.SetLeft(dateText, Margin + margin.Left);

                FixedPage.SetTop(PageNumberText, printableHeight - 25);
                FixedPage.SetLeft(PageNumberText, Margin + (printableWidth - PageNumberText.Text.Length * 10) / 2);
                //var testIt = newDgPage.SelectedItem;


                //FixedPageFromCanvas(newDgPage, size, pageNumber, PageHeightWithMargin, PageHeightWithMargin);

                var size = new Size(printableWidth, printableHeight);

                var canv = Preview.GetVisualCanvas(dg, size, new Thickness(0));

                var fixedPage = new FixedPage
                {
                    Background = Brushes.White,
                    Width = printableWidth,
                    Height = printableHeight,
                    Margin = new Thickness(0),

                };

                //fixedPage.Children.Add(dateText);
                //fixedPage.Children.Add(PageNumberText);

                //fixedPage.Children.Add(newDgPage);
                FixedPage.SetLeft(canv, Margin + margin.Left);
                FixedPage.SetTop(canv, margin.Top);

                fixedPage.Children.Add(canv);
                fixedPage.Children.Add(dateText);
                fixedPage.Children.Add(PageNumberText);


                PageContent pageContent = new PageContent();
                ((IAddChild)pageContent).AddChild(fixedPage);


                fixedDoc.Pages.Add(pageContent);



            }
            if (previewMode)
                new Preview(fixedDoc.DocumentPaginator).ShowDialog();

            //await Task.Run(() => fixedDoc.GetType());

            return fixedDoc;
        }

        public async Task<DataGrid[]> GetDataGridPagesAsync(Double printHeight, bool previewEachPage)
        {
        reprocess:

            List<LocalValueEntry[]> clonedColmsDps = ColumnsDpList;

            /*  MethodInfo mi2 = typeof(C).GetMethod("M2",
            BindingFlags.Public | BindingFlags.Static);*/

            /*MethodInfo mth = typeof(WpfPrinting).GetMethod("GetColumDepdPropts", new Type[] {dataGrid.GetType() });//.GetMethod("GetColumDepdPropts2", BindingFlags.Public | BindingFlags.Static);
            Delegate dlg = Delegate.CreateDelegate(typeof(D3), this, mth);
           var task = dataGrid.Dispatcher.Invoke(method: dlg, args: dataGrid);*/

            /* var task = await GetColumDepdPropts(dataGrid);
            while (task.Status == TaskStatus.WaitingForActivation)
            task.Wait(1);*/

            //ColDpList = clonedColmsDps;

            Double printableHeight = printHeight;

            List<DataGrid> dgPages = new List<DataGrid>();
            int position = 0, pageNumber = 0;
            for (; ; )
            {
                DataGrid newDgPage = new DataGrid();// GetClonedDg(gridCoy);

                //DnD Enrich new DataGrid page with cloned static columns data
                foreach (LocalValueEntry[] dps in ColumnsDpList)
                {
                    int rowIndex = ColumnsDpList.IndexOf(dps);
                    //DnD: Each new column is inititialize with ad DataGrid Text Column
                    newDgPage.Columns.Add(new DataGridTextColumn());

                    //LocalValueEntry[] dps = (LocalValueEntry[])ColDpList[k][1];

                    //DnD The actual  DataGridColumn Type and data is now applied 
                    //...from the cloned columns's dependency propts.
                    foreach (LocalValueEntry dp in dps)
                        newDgPage.Columns[rowIndex].SetValue(dp.Property, dp.Value);
                }

                double currentPgHeight = 0;

                ++pageNumber;

                while (currentPgHeight < printableHeight && position < this.DataGridRows.Length)
                {
                    DataGridRow row = this.DataGridRows[position++];

                    ///DnD Helps to resolve the irregular print margin,
                    ///observed, especially at the starting page(s)
                    row.UpdateLayout();
                    row.Margin = new Thickness(-5, 0, 0, 0);

                    newDgPage.Items.Add(row);

                    if (row.ActualHeight < 1)
                        continue;
                    currentPgHeight += row.ActualHeight;
                }

                newDgPage.Name = "Page_" + pageNumber.ToString().PadLeft(3, '0');
                dgPages.Add(newDgPage);

                ///DnD ToDo Previewed pages suffers exception except and have to
                ///be regenerated without previewing. Workaround needs to be created 
                if (previewEachPage)
                    Preview.PrintVisual(newDgPage);

                if (position < this.DataGridRows.Length)
                    ;
                else return dgPages.ToArray();
            }
        }

        static Style DgRowStyle0;
        static Style DgRowStyle
        {
            get
            {
                DgRowStyle0 = null;
                if (DgRowStyle0 == null)
                {
                    DgRowStyle0 = DataGridMgr.GetDgRowStyle;
                }
                return DgRowStyle0;
            }
        }
        static Style ColumnHdrStyle0;
        static Style ColumnHdrStyle
        {
            get
            {
                //ColumnHdrStyle0 = null;
                if (ColumnHdrStyle0 == null)
                {
                    /*//DnD Space to Enable either this->*/
                    ColumnHdrStyle0 = DataGridMgr.GetColumnHdrStyle;
                    /* DnD Or->* /
                    var style = new Style { TargetType = typeof(DataGridColumnHeader) };
                    style.Setters.Add(new Setter(DataGridColumnHeader.HeightProperty, 30.0));
                    //style.Setters.Add(new Setter(DataGridColumnHeader.WidthProperty, DataGridLength.Auto));
                    style.Setters.Add(new Setter(DataGridColumnHeader.PaddingProperty, new Thickness(1, 2, 1, 2)));
                    style.Setters.Add(new Setter(DataGridColumnHeader.BackgroundProperty, Brushes.Gray));
                    style.Setters.Add(new Setter(DataGridColumnHeader.ForegroundProperty, Brushes.White));
                    style.Setters.Add(new Setter(DataGridColumnHeader.FontSizeProperty, 14.0));///new FontSizeConverter().ConvertFrom(14)
                    style.Setters.Add(new Setter(DataGridColumnHeader.FontWeightProperty, FontWeights.Bold));
                    style.Setters.Add(new Setter(DataGridColumnHeader.BorderBrushProperty, Brushes.Black));
                    style.Setters.Add(new Setter(DataGridColumnHeader.BorderThicknessProperty, new Thickness(1, 2, 1, 2)));

                    //style.SetValue(style.FontSizeProperty, 10.0);
                    //style.Setters.Add(new Setter(DataGridColumnHeader.FontSizeProperty, 30.0));;

                    //< Setter Property = "DataGridColumnHeader.Height" Value = "30" />
                    //< !--< Setter Property = "DataGridColumnHeader.Width" Value = "Auto" /> -->
                    //< Setter Property = "DataGridColumnHeader.Padding" Value = "2,0" />
                    //< Setter Property = "DataGridColumnHeader.Background" Value = "Black" />
                    //< Setter Property = "DataGridColumnHeader.Foreground" Value = "White" />
                    //< Setter Property = "DataGridColumnHeader.FontSize" Value = "14" />
                    //< Setter Property = "DataGridColumnHeader.FontWeight"  Value = "Bold" />
                    //< Setter Property = "DataGridColumnHeader.BorderBrush" Value = "White" />
                    //< Setter Property = "DataGridColumnHeader.BorderThickness" Value = "1,2,1,2" />

                    ColumnHdrStyle0 = style;
                    //*/
                }
                return ColumnHdrStyle0;
            }
        }
        /// <summary>
        ///Utilizes two class propts,  ColumnsDpList & DataGridRows(for columns and rows, respectively),
        ///to reconstruct sub pages of the DataGrid that was used at the constructor to initialize this class.
        /// </summary>
        /// <param name="printHeight">The print height excluding margins, hearders and footers</param>
        /// <param name="previewEachPage">Yes to preview each page. ToDo Bug: previewding causes malfuction. Workaround needed</param>
        /// <returns></returns>
        public DataGrid[] GetDgPages(Double printHeight)
        {
            Double printableHeight = printHeight;


            //string resxFile = "/CustomControls;component/Themes/resFrameStyleOfficeButton.xaml".Trim();


            //if (_customFrame != null)
            //{
            //    if (WindowState == WindowState.Normal)
            //    {
            //        //UpdateFrameAppearance(uri);


            //        ResourceDictionary currentResources = new ResourceDictionary();

            //        foreach (DictionaryEntry entry in Resources)
            //        {
            //            currentResources[entry.Key] = entry.Value;
            //        }

            //        Uri uri = new Uri(resxFile, UriKind.Relative);
            //        ResourceDictionary fromFile = Application.LoadComponent(uri) as ResourceDictionary;
            //        currentResources.MergedDictionaries.Add(fromFile);

            //        Resources = currentResources;

            //        // Make ASYNCHRONOUS call to method that can react to new style
            //        // (new settings are NOT detected when you call the method directly)
            //        new Thread(() => { UpdateFrameBehavior(); }).Start();
            //    }
            DependencyProperty HeaderDP = DataGridMgr.ColumnHdrStyleProperty;
            ////HeaderDP.AddOwner(this.GetType());
            //Type typ = HeaderDP.OwnerType;
            //DataGridColumnHeader dgHeader = new DataGridColumnHeader();
            //dgHeader.Style = new Style(typeof(DataGridColumnHeader), PrintControl.ColumnHdrStyle2);

            List<DataGrid> dgPages = new List<DataGrid>();
            var fontSizes = new double[ColumnsDpList.Count];
            double val = 0;
            var maxWidths = new double[ColumnsDpList.Count];

            int position = 0, pageNumber = 0;
            for (; ; )
            {
                DataGrid newDgPage = new DataGrid();// GetClonedDg(gridCoy);
                
                //newDgPage.SetValue(DataGrid.ColumnHeaderStyleProperty, PrintControl.ColumnHdrStyleProperty);
                //DnD Enrich new DataGrid page with cloned static columns data
                foreach (LocalValueEntry[] dps in this.ColumnsDpList)
                {
                    int idx = this.ColumnsDpList.IndexOf(dps);
                    //DnD: Each new column is inititialize with ad DataGrid Text Column
                    newDgPage.Columns.Add(new DataGridTextColumn());

                    newDgPage.MaxColumnWidth = (double)int.MaxValue;

                    //newDgPage.Columns[rowIndex].Header = dgHeader;
                    //LocalValueEntry[] dps = (LocalValueEntry[])ColDpList[k][1];

                    ///DnD The actual  DataGridColumn Type and data is now applied 
                    ///from the cloned columns's dependency propts.
                    foreach (LocalValueEntry dp in dps)
                        newDgPage.Columns[idx].SetValue(dp.Property, dp.Value);

                    val = (Double)newDgPage.Columns[idx].GetValue(DataGridColumnHeader.FontSizeProperty);
                    fontSizes[idx] = val;

                    //val = (Double)newDgPage.Columns[idx].GetValue(DataGridColumnHeader.MaxWidthProperty);
                    //maxWidths[idx] = val;

                    //retTry:
                    //try
                    //{

                    //}catch(Exception ex)
                    //{
                    //    goto retTry; 
                    //}

                    //newDgPage.SetValue(dps[0].Property, HeaderDP);
                    //newDgPage.Columns[rowIndex].Header = PrintControl.ColumnHdrStyle2;
                }
                //newDgPage. = PrintControl.ColumnHdrStyle2;

                ///DnD ToDo: Source form original DataGrid view
                //fontSizes.Aggregate()

                ///DnD The HeaderCulumn fontsize is increased by 2.0
                if (true /*DnD To be implemented in GUI Settings*/ && ColumnHdrStyle0 == null)
                {
                    newDgPage.ColumnHeaderStyle = ColumnHdrStyle;
                    //newDgPage.ColumnHeaderStyle = ColumnHdrStyle.Setters.Remove(new Setter(DataGridColumnHeader.FontSizeProperty 14));

                    double heightestValue = fontSizes.Aggregate(0.0, (longest, next) => next > longest ? next : longest);
                    double lowestValue = fontSizes.Aggregate(heightestValue, (lowest, next) => next < lowest ? next : lowest);
                    val = heightestValue == lowestValue ? heightestValue + 2.0 : 14;

                    newDgPage.ColumnHeaderStyle.Setters.Add(new Setter(DataGridColumnHeader.FontSizeProperty, new FontSizeConverter().ConvertFrom(val)));



                    //newDgPage.ColumnHeaderStyle.Setters.Add(new Setter(DataGridColumnHeader.MaxWidthProperty, 140.0));
                }
                else
                    newDgPage.ColumnHeaderStyle = ColumnHdrStyle;

                int x = 0;
                //foreach (DataGridColumn cl in newDgPage.Columns)
                //{
                //    val = (Double)cl.GetValue(DataGridColumnHeader.MaxWidthProperty);
                //    maxWidths[x++] = val;
                //}

                var cellWidths = newDgPage.Columns.Select(w => w.Width.DesiredValue).ToArray();
                // Return the final result as an upper case string.
                //fruit => fruit.ToString().PadLeft(());



                //foreach(DataGridColumn dgCol in newDgPage.Columns)
                //    dgCo(DataGridColumnHeader.FontSizeProperty, new FontSizeConverter().ConvertFrom(14))
                //style.Setters.Add(new Setter(DataGridColumnHeader.FontSizeProperty, 14/*new FontSizeConverter().ConvertFrom(14)*/));

                //var cellWidths2 = newDgPage.Columns.Select(w => w.Width.DesiredValue).ToArray();
                //var cellWidths2a = newDgPage.Columns.Select(w => w.Width.DisplayValue).ToArray();
                //var cellWidths2b = newDgPage.Columns.Select(w => w.Width.Value).ToArray();
                double currentPgHeight = 0;

                ++pageNumber;

                DataGridRow row = null;
                //var rowHeaders = DataGridRows.Select(h => (DataGridRowHeader)h.Item);
                //var rowHeaders2 = DataGridRows.Select(h => (DataGridRowHeader)h.Header);
                //double largestRow = rowHeaders.Aggregate(0.0, (longest, next) => next > longest ? next : longest);
                //int lowestValue = rowHeaders.Aggregate(largestRow, (lowest, next) => next < lowest ? next : lowest);
                //val = largestRow == lowestValue ? largestRow  : 14;
                var pageList = new System.Collections.ObjectModel.ObservableCollection<PrintFormat>(); 
                int rowHder = 0;
                while (currentPgHeight < printableHeight && position < this.DataGridRows.Length)
                {
                    row = this.DataGridRows[position++];
                    if (row == null)
                        continue;
                    row.UpdateLayout();///DnD Helps to resolve the irregular print margin,
                                       ///observed, especially at the starting page(s)

                    row.Margin = new Thickness(-5, 0, 0, 0);

                    if (true/*DnD To be implemented in GUI Settings*/ && rowHder != null)
                        row.Header = null;
                    //var rowHeaders3 = DataGridRows.Select(h => h.HeaderTemplate);

                    newDgPage.Items.Add(row);
                    pageList.Add(row.Item as PrintFormat); 
                    if (row.ActualHeight < 1)
                        continue;
                    currentPgHeight += row.ActualHeight;
                }
                newDgPage.Tag = new ListCollectionView(pageList);
                //newDgPage.Columns[2].Width.DesiredValue = 12.0;

                //var cellWidths = newDgPage.Columns.Select(w => w.Width).ToArray();
                //newDgPage.ColumnHeaderStyle = ColumnHdrStyle;

                //var cellWidths1a = newDgPage.Columns.Select(w => w.Width.DisplayValue).ToArray();
                //var cellWidths1b = newDgPage.Columns.Select(w => w.Width.Value).ToArray();
                //newDgPage.ColumnHeaderStyle = ColumnHdrStyle;

                //var colEnut = newDgPage.Columns.GetEnumerator();

                //for (int c = 0; c < newDgPage.Columns.Count; c++)
                //    newDgPage.Columns[c].Width = new DataGridLength(cellWidths[c], DataGridLengthUnitType.Pixel);

                ///DnD Contrain Colums' width to align with cell's  width
                //var cellWidths2 = newDgPage.Columns.Select(w => w.Width.DesiredValue).ToArray();
                foreach (DataGridColumn col in newDgPage.Columns)
                {
                    //col.Width = cellWidths[newDgPage.Columns.IndexOf(col)];
                    col.Width = new DataGridLength(cellWidths[newDgPage.Columns.IndexOf(col)], DataGridLengthUnitType.Pixel);
                    //col.ActualWidth
                }
                //for (int c = 0; c < newDgPage.Columns.Count; c++)
                //    if (newDgPage.Columns[c].Width.DesiredValue < cellWidths[c])
                //        newDgPage.Columns[c].Width   =cellWidths[c];
                // new DataGridLength(.IndexOf(col)].ActualWidth, DataGridLengthUnitType.SizeToCells);


                //}

                /*///DnD Utilise the last row items's width to update each column header's width
                ///
                x=0;
                var enut = row.GetLocalValueEnumerator();
                var rowCells = new LocalValueEntry[enut.Count];
                while (enut.MoveNext())
                    rowCells[x++] = enut.Current;
                //newDgPage.CellStyle.

                x = 0;
                foreach (var newRow in newDgPage.Columns)
                {
                    if (rowCells[x] == null || rowCells[x].Property.ReadOnly)
                        continue;
                    var val2 = row.GetValue(rowCells[x++].Property);
                    //newRow.Width = new DataGridLength(row.[x].ActualWidth, DataGridLengthUnitType.SizeToCells);
                }
                */

                newDgPage.Name = "Page_" + pageNumber.ToString().PadLeft(3, '0');
                dgPages.Add(newDgPage);

                ///DnD ToDo Previewed pages suffers exception except and have to
                ///be regenerated without previewing. Workaround needs to be created 
                if (this.PreviewMod == PrintPreview.EachPage)
                    Preview.PrintVisual(newDgPage);

                if (position < this.DataGridRows.Length)
                {
                    if (pageNumber == 1 && this.PreviewMod == PrintPreview.FirstPage)
                        Preview.PrintVisual(newDgPage);

                    ;
                }
                else
                {
                    if (this.PreviewMod == PrintPreview.LastPage)
                        Preview.PrintVisual(newDgPage);
                    return dgPages.ToArray();
                }
            }
        }

        /// <summary>
        ///Utilizes two class propts,  ColumnsDpList & DataGridRows(for columns and rows, respectively),
        ///to reconstruct sub pages of the DataGrid that was used at the constructor to initialize this class.
        /// </summary>
        /// <param name="printHeight">The print height excluding margins, hearders and footers</param>
        /// <param name="previewEachPage">Yes to preview each page. ToDo Bug: previewding causes malfuction. Workaround needed</param>
        /// <returns></returns>
        public DataGrid[] GetDgPages2(Double printHeight, ref TabControlMgr tabControllMgr)
        {
            Double printableHeight = printHeight;


            //string resxFile = "/CustomControls;component/Themes/resFrameStyleOfficeButton.xaml".Trim();


            //if (_customFrame != null)
            //{
            //    if (WindowState == WindowState.Normal)
            //    {
            //        //UpdateFrameAppearance(uri);


            //        ResourceDictionary currentResources = new ResourceDictionary();

            //        foreach (DictionaryEntry entry in Resources)
            //        {
            //            currentResources[entry.Key] = entry.Value;
            //        }

            //        Uri uri = new Uri(resxFile, UriKind.Relative);
            //        ResourceDictionary fromFile = Application.LoadComponent(uri) as ResourceDictionary;
            //        currentResources.MergedDictionaries.Add(fromFile);

            //        Resources = currentResources;

            //        // Make ASYNCHRONOUS call to method that can react to new style
            //        // (new settings are NOT detected when you call the method directly)
            //        new Thread(() => { UpdateFrameBehavior(); }).Start();
            //    }
            DependencyProperty HeaderDP = DataGridMgr.ColumnHdrStyleProperty;
            ////HeaderDP.AddOwner(this.GetType());
            //Type typ = HeaderDP.OwnerType;
            //DataGridColumnHeader dgHeader = new DataGridColumnHeader();
            //dgHeader.Style = new Style(typeof(DataGridColumnHeader), PrintControl.ColumnHdrStyle2);

            List<DataGrid> dgPages = new List<DataGrid>();
            var fontSizes = new double[ColumnsDpList.Count];
            double val = 0;
            var maxWidths = new double[ColumnsDpList.Count];

            int position = 0, pageNumber = 0;
            for (; ; )
            {
                DataGrid newDgPage = new DataGrid();
                //newDgPage.EnableColumnVirtualization = false;
                //newDgPage.EnableRowVirtualization = false;
                
                var tabItem = tabControllMgr.GeTab();
                ScrollViewer scrVw = (ScrollViewer)tabItem.Content;
                scrVw.SetValue(ScrollViewer.ContentProperty, newDgPage);

                //newDgPage.SetValue(DataGrid.ColumnHeaderStyleProperty, PrintControl.ColumnHdrStyleProperty);
                //DnD Enrich new DataGrid page with cloned static columns data
                foreach (LocalValueEntry[] dps in this.ColumnsDpList)
                {
                    int idx = this.ColumnsDpList.IndexOf(dps);
                    //DnD: Each new column is inititialize with ad DataGrid Text Column
                    newDgPage.Columns.Add(new DataGridTextColumn());

                    newDgPage.MaxColumnWidth = (double)int.MaxValue;

                    //newDgPage.Columns[rowIndex].Header = dgHeader;
                    //LocalValueEntry[] dps = (LocalValueEntry[])ColDpList[k][1];

                    ///DnD The actual  DataGridColumn Type and data is now applied 
                    ///from the cloned columns's dependency propts.
                    foreach (LocalValueEntry dp in dps)
                        newDgPage.Columns[idx].SetValue(dp.Property, dp.Value);

                    val = (Double)newDgPage.Columns[idx].GetValue(DataGridColumnHeader.FontSizeProperty);
                    fontSizes[idx] = val;

                    //val = (Double)newDgPage.Columns[idx].GetValue(DataGridColumnHeader.MaxWidthProperty);
                    //maxWidths[idx] = val;

                    //retTry:
                    //try
                    //{

                    //}catch(Exception ex)
                    //{
                    //    goto retTry; 
                    //}

                    //newDgPage.SetValue(dps[0].Property, HeaderDP);
                    //newDgPage.Columns[rowIndex].Header = PrintControl.ColumnHdrStyle2;
                }
                //newDgPage. = PrintControl.ColumnHdrStyle2;

                ///DnD ToDo: Source form original DataGrid view
                //fontSizes.Aggregate()

                ///DnD The HeaderCulumn fontsize is increased by 2.0
                if (true /*DnD To be implemented in GUI Settings*/ && ColumnHdrStyle0 == null)
                {
                    newDgPage.ColumnHeaderStyle = ColumnHdrStyle;
                    //newDgPage.ColumnHeaderStyle = ColumnHdrStyle.Setters.Remove(new Setter(DataGridColumnHeader.FontSizeProperty 14));

                    double heightestValue = fontSizes.Aggregate(0.0, (longest, next) => next > longest ? next : longest);
                    double lowestValue = fontSizes.Aggregate(heightestValue, (lowest, next) => next < lowest ? next : lowest);
                    val = heightestValue == lowestValue ? heightestValue + 2.0 : 14;

                    newDgPage.ColumnHeaderStyle.Setters.Add(new Setter(DataGridColumnHeader.FontSizeProperty, new FontSizeConverter().ConvertFrom(val)));



                    //newDgPage.ColumnHeaderStyle.Setters.Add(new Setter(DataGridColumnHeader.MaxWidthProperty, 140.0));
                }
                else
                    newDgPage.ColumnHeaderStyle = ColumnHdrStyle;

                int x = 0;
                //foreach (DataGridColumn cl in newDgPage.Columns)
                //{
                //    val = (Double)cl.GetValue(DataGridColumnHeader.MaxWidthProperty);
                //    maxWidths[x++] = val;
                //}

                var cellWidths = newDgPage.Columns.Select(w => w.Width.DesiredValue).ToArray();
                // Return the final result as an upper case string.
                //fruit => fruit.ToString().PadLeft(());



                //foreach(DataGridColumn dgCol in newDgPage.Columns)
                //    dgCo(DataGridColumnHeader.FontSizeProperty, new FontSizeConverter().ConvertFrom(14))
                //style.Setters.Add(new Setter(DataGridColumnHeader.FontSizeProperty, 14/*new FontSizeConverter().ConvertFrom(14)*/));

                //var cellWidths2 = newDgPage.Columns.Select(w => w.Width.DesiredValue).ToArray();
                //var cellWidths2a = newDgPage.Columns.Select(w => w.Width.DisplayValue).ToArray();
                //var cellWidths2b = newDgPage.Columns.Select(w => w.Width.Value).ToArray();
                double currentPgHeight = 0;

                ++pageNumber;

                DataGridRow row = null;
                //var rowHeaders = DataGridRows.Select(h => (DataGridRowHeader)h.Item);
                //var rowHeaders2 = DataGridRows.Select(h => (DataGridRowHeader)h.Header);
                //double largestRow = rowHeaders.Aggregate(0.0, (longest, next) => next > longest ? next : longest);
                //int lowestValue = rowHeaders.Aggregate(largestRow, (lowest, next) => next < lowest ? next : lowest);
                //val = largestRow == lowestValue ? largestRow  : 14;

                int rowHder = 0;
                while (currentPgHeight < printableHeight && position < this.DataGridRows.Length)
                {
                    row = this.DataGridRows[position++];
                    if (row == null)
                        continue;
                    row.UpdateLayout();///DnD Helps to resolve the irregular print margin,
                                       ///observed, especially at the starting page(s)

                    row.Margin = new Thickness(-5, 0, 0, 0);

                    if (true/*DnD To be implemented in GUI Settings*/ && rowHder != null)
                        row.Header = null;
                    //var rowHeaders3 = DataGridRows.Select(h => h.HeaderTemplate);

                    newDgPage.Items.Add(row);

                    if (row.ActualHeight < 1)
                        continue;
                    currentPgHeight += row.ActualHeight;
                }
                //newDgPage.Columns[2].Width.DesiredValue = 12.0;

                //var cellWidths = newDgPage.Columns.Select(w => w.Width).ToArray();
                //newDgPage.ColumnHeaderStyle = ColumnHdrStyle;

                //var cellWidths1a = newDgPage.Columns.Select(w => w.Width.DisplayValue).ToArray();
                //var cellWidths1b = newDgPage.Columns.Select(w => w.Width.Value).ToArray();
                //newDgPage.ColumnHeaderStyle = ColumnHdrStyle;

                //var colEnut = newDgPage.Columns.GetEnumerator();

                //for (int c = 0; c < newDgPage.Columns.Count; c++)
                //    newDgPage.Columns[c].Width = new DataGridLength(cellWidths[c], DataGridLengthUnitType.Pixel);

                ///DnD Contrain Colums' width to align with cell's  width
                //var cellWidths2 = newDgPage.Columns.Select(w => w.Width.DesiredValue).ToArray();
                foreach (DataGridColumn col in newDgPage.Columns)
                {
                    //col.Width = cellWidths[newDgPage.Columns.IndexOf(col)];
                    col.Width = new DataGridLength(cellWidths[newDgPage.Columns.IndexOf(col)], DataGridLengthUnitType.Pixel);
                    //col.ActualWidth
                }
                //for (int c = 0; c < newDgPage.Columns.Count; c++)
                //    if (newDgPage.Columns[c].Width.DesiredValue < cellWidths[c])
                //        newDgPage.Columns[c].Width   =cellWidths[c];
                // new DataGridLength(.IndexOf(col)].ActualWidth, DataGridLengthUnitType.SizeToCells);


                //}

                /*///DnD Utilise the last row items's width to update each column header's width
                ///
                x=0;
                var enut = row.GetLocalValueEnumerator();
                var rowCells = new LocalValueEntry[enut.Count];
                while (enut.MoveNext())
                    rowCells[x++] = enut.Current;
                //newDgPage.CellStyle.

                x = 0;
                foreach (var newRow in newDgPage.Columns)
                {
                    if (rowCells[x] == null || rowCells[x].Property.ReadOnly)
                        continue;
                    var val2 = row.GetValue(rowCells[x++].Property);
                    //newRow.Width = new DataGridLength(row.[x].ActualWidth, DataGridLengthUnitType.SizeToCells);
                }
                */

                newDgPage.Name = "Page_" + pageNumber.ToString().PadLeft(3, '0');
                dgPages.Add(newDgPage);

                ///DnD ToDo Previewed pages suffers exception except and have to
                ///be regenerated without previewing. Workaround needs to be created 
                if (this.PreviewMod == PrintPreview.EachPage)
                    Preview.PrintVisual(newDgPage);

                if (position < this.DataGridRows.Length)
                {
                    if (pageNumber == 1 && this.PreviewMod == PrintPreview.FirstPage)
                        Preview.PrintVisual(newDgPage);

                    ;
                }
                else
                {
                    if (this.PreviewMod == PrintPreview.LastPage)
                        Preview.PrintVisual(newDgPage);
                    return dgPages.ToArray();
                }
            }
        }

        /// <summary>
        ///Utilizes two class propts,  ColumnsDpList & DataGridRows(for columns and rows, respectively),
        ///to reconstruct sub pages of the DataGrid that was used at the constructor to initialize this class.
        /// </summary>
        /// <param name="printHeight">The print height excluding margins, hearders and footers</param>
        /// <param name="previewEachPage">Yes to preview each page. ToDo Bug: previewding causes malfuction. Workaround needed</param>
        /// <returns></returns>
        public ScrollViewer[] GetDgPages3(Double printHeight)
        {
            Double printableHeight = printHeight;


            //string resxFile = "/CustomControls;component/Themes/resFrameStyleOfficeButton.xaml".Trim();


            //if (_customFrame != null)
            //{
            //    if (WindowState == WindowState.Normal)
            //    {
            //        //UpdateFrameAppearance(uri);


            //        ResourceDictionary currentResources = new ResourceDictionary();

            //        foreach (DictionaryEntry entry in Resources)
            //        {
            //            currentResources[entry.Key] = entry.Value;
            //        }

            //        Uri uri = new Uri(resxFile, UriKind.Relative);
            //        ResourceDictionary fromFile = Application.LoadComponent(uri) as ResourceDictionary;
            //        currentResources.MergedDictionaries.Add(fromFile);

            //        Resources = currentResources;

            //        // Make ASYNCHRONOUS call to method that can react to new style
            //        // (new settings are NOT detected when you call the method directly)
            //        new Thread(() => { UpdateFrameBehavior(); }).Start();
            //    }
            DependencyProperty HeaderDP = DataGridMgr.ColumnHdrStyleProperty;
            ////HeaderDP.AddOwner(this.GetType());
            //Type typ = HeaderDP.OwnerType;
            //DataGridColumnHeader dgHeader = new DataGridColumnHeader();
            //dgHeader.Style = new Style(typeof(DataGridColumnHeader), PrintControl.ColumnHdrStyle2);

            List<ScrollViewer> dgPages = new List<ScrollViewer>();
            var fontSizes = new double[ColumnsDpList.Count];
            double val = 0;
            var maxWidths = new double[ColumnsDpList.Count];

            int position = 0, pageNumber = 0;
            for (; ; )
            {
                DataGrid newDgPage = new DataGrid();
                //newDgPage.EnableColumnVirtualization = false;
                //newDgPage.EnableRowVirtualization = false;

                //var tabItem = tabControllMgr.GeTab();
                var scrVw = new ScrollViewer();// (ScrollViewer)tabItem.Content;
                scrVw.SetValue(ScrollViewer.ContentProperty, newDgPage);

                //newDgPage.SetValue(DataGrid.ColumnHeaderStyleProperty, PrintControl.ColumnHdrStyleProperty);
                //DnD Enrich new DataGrid page with cloned static columns data
                foreach (LocalValueEntry[] dps in this.ColumnsDpList)
                {
                    int idx = this.ColumnsDpList.IndexOf(dps);
                    //DnD: Each new column is inititialize with ad DataGrid Text Column
                    newDgPage.Columns.Add(new DataGridTextColumn());

                    newDgPage.MaxColumnWidth = (double)int.MaxValue;

                    //newDgPage.Columns[rowIndex].Header = dgHeader;
                    //LocalValueEntry[] dps = (LocalValueEntry[])ColDpList[k][1];

                    ///DnD The actual  DataGridColumn Type and data is now applied 
                    ///from the cloned columns's dependency propts.
                    foreach (LocalValueEntry dp in dps)
                        newDgPage.Columns[idx].SetValue(dp.Property, dp.Value);

                    val = (Double)newDgPage.Columns[idx].GetValue(DataGridColumnHeader.FontSizeProperty);
                    fontSizes[idx] = val;

                    //val = (Double)newDgPage.Columns[idx].GetValue(DataGridColumnHeader.MaxWidthProperty);
                    //maxWidths[idx] = val;

                    //retTry:
                    //try
                    //{

                    //}catch(Exception ex)
                    //{
                    //    goto retTry; 
                    //}

                    //newDgPage.SetValue(dps[0].Property, HeaderDP);
                    //newDgPage.Columns[rowIndex].Header = PrintControl.ColumnHdrStyle2;
                }
                //newDgPage. = PrintControl.ColumnHdrStyle2;

                ///DnD ToDo: Source form original DataGrid view
                //fontSizes.Aggregate()

                ///DnD The HeaderCulumn fontsize is increased by 2.0
                if (true /*DnD To be implemented in GUI Settings*/ && ColumnHdrStyle0 == null)
                {
                    newDgPage.ColumnHeaderStyle = ColumnHdrStyle;
                    //newDgPage.ColumnHeaderStyle = ColumnHdrStyle.Setters.Remove(new Setter(DataGridColumnHeader.FontSizeProperty 14));

                    double heightestValue = fontSizes.Aggregate(0.0, (longest, next) => next > longest ? next : longest);
                    double lowestValue = fontSizes.Aggregate(heightestValue, (lowest, next) => next < lowest ? next : lowest);
                    val = heightestValue == lowestValue ? heightestValue + 2.0 : 14;

                    newDgPage.ColumnHeaderStyle.Setters.Add(new Setter(DataGridColumnHeader.FontSizeProperty, new FontSizeConverter().ConvertFrom(val)));



                    //newDgPage.ColumnHeaderStyle.Setters.Add(new Setter(DataGridColumnHeader.MaxWidthProperty, 140.0));
                }
                else
                    newDgPage.ColumnHeaderStyle = ColumnHdrStyle;

                int x = 0;
                //foreach (DataGridColumn cl in newDgPage.Columns)
                //{
                //    val = (Double)cl.GetValue(DataGridColumnHeader.MaxWidthProperty);
                //    maxWidths[x++] = val;
                //}

                var cellWidths = newDgPage.Columns.Select(w => w.Width.DesiredValue).ToArray();
                // Return the final result as an upper case string.
                //fruit => fruit.ToString().PadLeft(());



                //foreach(DataGridColumn dgCol in newDgPage.Columns)
                //    dgCo(DataGridColumnHeader.FontSizeProperty, new FontSizeConverter().ConvertFrom(14))
                //style.Setters.Add(new Setter(DataGridColumnHeader.FontSizeProperty, 14/*new FontSizeConverter().ConvertFrom(14)*/));

                //var cellWidths2 = newDgPage.Columns.Select(w => w.Width.DesiredValue).ToArray();
                //var cellWidths2a = newDgPage.Columns.Select(w => w.Width.DisplayValue).ToArray();
                //var cellWidths2b = newDgPage.Columns.Select(w => w.Width.Value).ToArray();
                double currentPgHeight = 0;

                ++pageNumber;

                DataGridRow row = null;
                //var rowHeaders = DataGridRows.Select(h => (DataGridRowHeader)h.Item);
                //var rowHeaders2 = DataGridRows.Select(h => (DataGridRowHeader)h.Header);
                //double largestRow = rowHeaders.Aggregate(0.0, (longest, next) => next > longest ? next : longest);
                //int lowestValue = rowHeaders.Aggregate(largestRow, (lowest, next) => next < lowest ? next : lowest);
                //val = largestRow == lowestValue ? largestRow  : 14;

                int rowHder = 0;
                while (currentPgHeight < printableHeight && position < this.DataGridRows.Length)
                {
                    row = this.DataGridRows[position++];
                    if (row == null)
                        continue;
                    row.UpdateLayout();///DnD Helps to resolve the irregular print margin,
                                       ///observed, especially at the starting page(s)

                    row.Margin = new Thickness(-5, 0, 0, 0);

                    if (true/*DnD To be implemented in GUI Settings*/ && rowHder != null)
                        row.Header = null;
                    //var rowHeaders3 = DataGridRows.Select(h => h.HeaderTemplate);

                    newDgPage.Items.Add(row);

                    if (row.ActualHeight < 1)
                        continue;
                    currentPgHeight += row.ActualHeight;
                }
                newDgPage.UpdateLayout();
                //scrVw.UpdateLayout();
                //newDgPage.Columns[2].Width.DesiredValue = 12.0;

                //var cellWidths = newDgPage.Columns.Select(w => w.Width).ToArray();
                //newDgPage.ColumnHeaderStyle = ColumnHdrStyle;

                //var cellWidths1a = newDgPage.Columns.Select(w => w.Width.DisplayValue).ToArray();
                //var cellWidths1b = newDgPage.Columns.Select(w => w.Width.Value).ToArray();
                //newDgPage.ColumnHeaderStyle = ColumnHdrStyle;

                //var colEnut = newDgPage.Columns.GetEnumerator();

                //for (int c = 0; c < newDgPage.Columns.Count; c++)
                //    newDgPage.Columns[c].Width = new DataGridLength(cellWidths[c], DataGridLengthUnitType.Pixel);

                ///DnD Contrain Colums' width to align with cell's  width
                //var cellWidths2 = newDgPage.Columns.Select(w => w.Width.DesiredValue).ToArray();
                foreach (DataGridColumn col in newDgPage.Columns)
                {
                    //col.Width = cellWidths[newDgPage.Columns.IndexOf(col)];
                    col.Width = new DataGridLength(cellWidths[newDgPage.Columns.IndexOf(col)], DataGridLengthUnitType.Pixel);
                    //col.ActualWidth
                }
                //for (int c = 0; c < newDgPage.Columns.Count; c++)
                //    if (newDgPage.Columns[c].Width.DesiredValue < cellWidths[c])
                //        newDgPage.Columns[c].Width   =cellWidths[c];
                // new DataGridLength(.IndexOf(col)].ActualWidth, DataGridLengthUnitType.SizeToCells);


                //}

                /*///DnD Utilise the last row items's width to update each column header's width
                ///
                x=0;
                var enut = row.GetLocalValueEnumerator();
                var rowCells = new LocalValueEntry[enut.Count];
                while (enut.MoveNext())
                    rowCells[x++] = enut.Current;
                //newDgPage.CellStyle.

                x = 0;
                foreach (var newRow in newDgPage.Columns)
                {
                    if (rowCells[x] == null || rowCells[x].Property.ReadOnly)
                        continue;
                    var val2 = row.GetValue(rowCells[x++].Property);
                    //newRow.Width = new DataGridLength(row.[x].ActualWidth, DataGridLengthUnitType.SizeToCells);
                }
                */

                newDgPage.Name = "Page_" + pageNumber.ToString().PadLeft(3, '0');
                dgPages.Add(scrVw);

                ///DnD ToDo Previewed pages suffers exception except and have to
                ///be regenerated without previewing. Workaround needs to be created 
                if (this.PreviewMod == PrintPreview.EachPage)
                    Preview.PrintVisual(newDgPage);

                if (position < this.DataGridRows.Length)
                {
                    if (pageNumber == 1 && this.PreviewMod == PrintPreview.FirstPage)
                        Preview.PrintVisual(newDgPage);

                    ;
                }
                else
                {
                    if (this.PreviewMod == PrintPreview.LastPage)
                        Preview.PrintVisual(newDgPage);
                    return dgPages.ToArray();
                }
            }
        }

        public ColorInfo[] GetDgPages4(Double printHeight, PatternWkBook workBook)
        {
            Double printableHeight = printHeight;

            DependencyProperty HeaderDP = DataGridMgr.ColumnHdrStyleProperty;


            //List<DataGrid> dgPages = new List<DataGrid>();
            var fontSizes = new double[ColumnsDpList.Count];
            double val = 0;
            var maxWidths = new double[ColumnsDpList.Count];

            var colInfoList = new List<ColorInfo>();
            workBook.PrintMode = true;
            int position = 0, pageNumber = 0;
            for (; ; )
            {
                colInfoList.Add(workBook.NewColorInfo);

                DataGrid newDgPage = colInfoList[colInfoList.Count - 1].DataGridPaging ;// new DataGrid();

                foreach (LocalValueEntry[] dps in this.ColumnsDpList)
                {
                    int idx = this.ColumnsDpList.IndexOf(dps);
                    //DnD: Each new column is inititialize with ad DataGrid Text Column
                    newDgPage.Columns.Add(new DataGridTextColumn());

                    newDgPage.MaxColumnWidth = (double)int.MaxValue;

                    foreach (LocalValueEntry dp in dps)
                        newDgPage.Columns[idx].SetValue(dp.Property, dp.Value);

                    val = (Double)newDgPage.Columns[idx].GetValue(DataGridColumnHeader.FontSizeProperty);
                    fontSizes[idx] = val;


                }


                ///DnD The HeaderCulumn fontsize is increased by 2.0
                if (true /*DnD To be implemented in GUI Settings*/ && ColumnHdrStyle0 == null)
                {
                    newDgPage.ColumnHeaderStyle = ColumnHdrStyle;
                    //newDgPage.ColumnHeaderStyle = ColumnHdrStyle.Setters.Remove(new Setter(DataGridColumnHeader.FontSizeProperty 14));

                    double heightestValue = fontSizes.Aggregate(0.0, (longest, next) => next > longest ? next : longest);
                    double lowestValue = fontSizes.Aggregate(heightestValue, (lowest, next) => next < lowest ? next : lowest);
                    val = heightestValue == lowestValue ? heightestValue + 2.0 : 14;

                    newDgPage.ColumnHeaderStyle.Setters.Add(new Setter(DataGridColumnHeader.FontSizeProperty, new FontSizeConverter().ConvertFrom(val)));


                }
                else
                    newDgPage.ColumnHeaderStyle = ColumnHdrStyle;

                int x = 0;
                //foreach (DataGridColumn cl in newDgPage.Columns)
                //{
                //    val = (Double)cl.GetValue(DataGridColumnHeader.MaxWidthProperty);
                //    maxWidths[x++] = val;
                //}

                var cellWidths = newDgPage.Columns.Select(w => w.Width.DesiredValue).ToArray();
                // Return the final result as an upper case string.
                //fruit => fruit.ToString().PadLeft(());



                //foreach(DataGridColumn dgCol in newDgPage.Columns)
                //    dgCo(DataGridColumnHeader.FontSizeProperty, new FontSizeConverter().ConvertFrom(14))
                //style.Setters.Add(new Setter(DataGridColumnHeader.FontSizeProperty, 14/*new FontSizeConverter().ConvertFrom(14)*/));

                //var cellWidths2 = newDgPage.Columns.Select(w => w.Width.DesiredValue).ToArray();
                //var cellWidths2a = newDgPage.Columns.Select(w => w.Width.DisplayValue).ToArray();
                //var cellWidths2b = newDgPage.Columns.Select(w => w.Width.Value).ToArray();
                double currentPgHeight = 0;

                ++pageNumber;

                DataGridRow row = null;
                //var rowHeaders = DataGridRows.Select(h => (DataGridRowHeader)h.Item);
                //var rowHeaders2 = DataGridRows.Select(h => (DataGridRowHeader)h.Header);
                //double largestRow = rowHeaders.Aggregate(0.0, (longest, next) => next > longest ? next : longest);
                //int lowestValue = rowHeaders.Aggregate(largestRow, (lowest, next) => next < lowest ? next : lowest);
                //val = largestRow == lowestValue ? largestRow  : 14;

                int rowHder = 0;
                while (currentPgHeight < printableHeight && position < this.DataGridRows.Length)
                {
                    row = this.DataGridRows[position++];
                    if (row == null)
                        continue;
                    row.UpdateLayout();///DnD Helps to resolve the irregular print margin,
                                       ///observed, especially at the starting page(s)

                    row.Margin = new Thickness(-5, 0, 0, 0);

                    if (true/*DnD To be implemented in GUI Settings*/ && rowHder != null)
                        row.Header = null;
                    //var rowHeaders3 = DataGridRows.Select(h => h.HeaderTemplate);

                    newDgPage.Items.Add(row);

                    if (row.ActualHeight < 1)
                        continue;
                    currentPgHeight += row.ActualHeight;
                }
                //newDgPage.Columns[2].Width.DesiredValue = 12.0;

                //var cellWidths = newDgPage.Columns.Select(w => w.Width).ToArray();
                //newDgPage.ColumnHeaderStyle = ColumnHdrStyle;

                //var cellWidths1a = newDgPage.Columns.Select(w => w.Width.DisplayValue).ToArray();
                //var cellWidths1b = newDgPage.Columns.Select(w => w.Width.Value).ToArray();
                //newDgPage.ColumnHeaderStyle = ColumnHdrStyle;

                //var colEnut = newDgPage.Columns.GetEnumerator();

                //for (int c = 0; c < newDgPage.Columns.Count; c++)
                //    newDgPage.Columns[c].Width = new DataGridLength(cellWidths[c], DataGridLengthUnitType.Pixel);

                ///DnD Contrain Colums' width to align with cell's  width
                //var cellWidths2 = newDgPage.Columns.Select(w => w.Width.DesiredValue).ToArray();
                foreach (DataGridColumn col in newDgPage.Columns)
                {
                    //col.Width = cellWidths[newDgPage.Columns.IndexOf(col)];
                    col.Width = new DataGridLength(cellWidths[newDgPage.Columns.IndexOf(col)], DataGridLengthUnitType.Pixel);
                    //col.ActualWidth
                }
                //for (int c = 0; c < newDgPage.Columns.Count; c++)
                //    if (newDgPage.Columns[c].Width.DesiredValue < cellWidths[c])
                //        newDgPage.Columns[c].Width   =cellWidths[c];
                // new DataGridLength(.IndexOf(col)].ActualWidth, DataGridLengthUnitType.SizeToCells);


                //}

                /*///DnD Utilise the last row items's width to update each column header's width
                ///
                x=0;
                var enut = row.GetLocalValueEnumerator();
                var rowCells = new LocalValueEntry[enut.Count];
                while (enut.MoveNext())
                    rowCells[x++] = enut.Current;
                //newDgPage.CellStyle.

                x = 0;
                foreach (var newRow in newDgPage.Columns)
                {
                    if (rowCells[x] == null || rowCells[x].Property.ReadOnly)
                        continue;
                    var val2 = row.GetValue(rowCells[x++].Property);
                    //newRow.Width = new DataGridLength(row.[x].ActualWidth, DataGridLengthUnitType.SizeToCells);
                }
                */

                newDgPage.Name = "Page_" + pageNumber.ToString().PadLeft(3, '0');
                //dgPages.Add(newDgPage);

                ///DnD ToDo Previewed pages suffers exception except and have to
                ///be regenerated without previewing. Workaround needs to be created 
                if (this.PreviewMod == PrintPreview.EachPage)
                    Preview.PrintVisual(newDgPage);

                if (position < this.DataGridRows.Length)
                {
                    if (pageNumber == 1 && this.PreviewMod == PrintPreview.FirstPage)
                        Preview.PrintVisual(newDgPage);

                    ;
                }
                else
                {
                    if (this.PreviewMod == PrintPreview.LastPage)
                        Preview.PrintVisual(newDgPage);
                    return colInfoList.ToArray();
                }
            }
            
        }


        private Visual PerformTransform(Visual v, PrintQueue pq)
        {
            ContainerVisual root = new ContainerVisual();
            const double inch = 96;

            // Set the margins.
            double xMargin = 1.25 * inch;
            double yMargin = 1 * inch;

            PrintTicket pt = pq.UserPrintTicket;
            Double printableWidth = pt.PageMediaSize.Width.Value;
            Double printableHeight = pt.PageMediaSize.Height.Value;

            Double xScale = (printableWidth - xMargin * 2) / printableWidth;
            Double yScale = (printableHeight - yMargin * 2) / printableHeight;

            root.Children.Add(v);
            root.Transform = new MatrixTransform(xScale, 0, 0, yScale, xMargin, yMargin);

            return root;
        }


        /// <summary>
        /// Create and return a dictionary object suitable for cloning the columns
        /// of the DataGrid specified parameter (DataGrid) belongs.
        /// </summary>
        /// <param name="dataGrid"></param>
        /// <returns></returns>
        public static Dictionary<int, object[]> GetColumDict2(DataGrid dataGrid)
        {
            var colDict = new Dictionary<int, object[]>();
            for (int x = 0; x < dataGrid.Columns.Count; x++)
            {
                //colDict.Add(x, new object[2]); 
                DataGridColumn dgCol = dataGrid.Columns[x];
                DependencyObjectType colTyp = dgCol.DependencyObjectType;
                DataGridColumn dgCol2 = null;
                switch (colTyp.Name)
                {
                    case "DataGridTextColumn":
                        dgCol2 = new DataGridTextColumn();
                        break;

                    case "DataGridComboBoxColumn":
                        dgCol2 = new DataGridComboBoxColumn();
                        break;

                    case "DataGridCheckBoxColumn":
                        dgCol2 = new DataGridCheckBoxColumn();
                        break;

                    case "DataGridTemplateColumn":
                        dgCol2 = new DataGridTemplateColumn();
                        break;

                    default:
                        throw new NotImplementedException("Missing Switch Case");

                }

                LocalValueEntry[] dependPropts = GetDependecyPropts(dgCol);

                colDict.Add(x, new object[2] { dgCol2, dependPropts });
            }

            return colDict;
        }



        /// <summary>
        /// Create and return a columns dependency propts (as LocalValueEntry[])
        /// which is suitable for cloning the columns of the specified parameter 
        /// (DataGrid) belongs.
        /// </summary>
        /// <param name="dataGrid">The data</param>
        /// <returns></returns>
        private static List<LocalValueEntry[]> GetColumDepdPropts(DataGrid dataGrid)
        {
            var colDenpdProptsList = new List<LocalValueEntry[]>(dataGrid.Columns.Count);

            double fontSz;
            var fontSizes = new double[dataGrid.Columns.Count];

            for (int x = 0; x < dataGrid.Columns.Count; x++)
            {
                var colDbPropts = new List<LocalValueEntry>();

                DataGridColumn dgCol = dataGrid.Columns[x];

                fontSz = (Double)dgCol.GetValue(DataGridColumnHeader.FontSizeProperty);
                fontSizes[x] = fontSz;

                var enut = dgCol.GetLocalValueEnumerator();

                while (enut.MoveNext())
                {
                    LocalValueEntry colPropt = (LocalValueEntry)enut.Current;
                    if (colPropt == null || colPropt.Property.ReadOnly)
                        continue;
                    colDbPropts.Add(colPropt);

                }



                colDenpdProptsList.Add(colDbPropts.ToArray());
            }


            return colDenpdProptsList;
        }


        public async Task<List<LocalValueEntry[]>> GetColumDepdProptsAsync(DataGrid dataGrid)
        {
            var colDenpdProptsList = new List<LocalValueEntry[]>(dataGrid.Columns.Count);

            await Task.Run(() =>
            {
                for (int x = 0; x < dataGrid.Columns.Count; x++)
                {
                    var colDbPropts = new List<LocalValueEntry>();

                    DataGridColumn dgCol = dataGrid.Columns[x];
                    var enut = dgCol.GetLocalValueEnumerator();

                    while (enut.MoveNext())
                    {
                        LocalValueEntry colPropt = (LocalValueEntry)enut.Current;
                        if (colPropt == null || colPropt.Property.ReadOnly)
                            continue;

                        colDbPropts.Add(colPropt);
                    }

                    //LocalValueEntry[] dependPropts = GetDependecyPropts(dgCol);

                    colDenpdProptsList.Add(colDbPropts.ToArray());
                }
            });

            return colDenpdProptsList;
        }


        public object GetColumDepdPropts(object dgObj)
        {
            var dataGrid = dgObj as DataGrid;
            var colDenpdProptsList = new List<LocalValueEntry[]>(dataGrid.Columns.Count);

            //await Task.Run(() =>
            //{
            for (int x = 0; x < dataGrid.Columns.Count; x++)
            {
                var colDbPropts = new List<LocalValueEntry>();

                DataGridColumn dgCol = dataGrid.Columns[x];
                var enut = dgCol.GetLocalValueEnumerator();

                while (enut.MoveNext())
                {
                    LocalValueEntry colPropt = (LocalValueEntry)enut.Current;
                    if (colPropt == null || colPropt.Property.ReadOnly)
                        continue;

                    colDbPropts.Add(colPropt);
                }

                //LocalValueEntry[] dependPropts = GetDependecyPropts(dgCol);

                colDenpdProptsList.Add(colDbPropts.ToArray());
            }
            //});

            /////DnD ToDo: Sample Usage:
            //var newDgPage = new DataGrid();
            //foreach (LocalValueEntry[] dps in ColDpList)
            //{
            //    int rowIndex = ColDpList.IndexOf(dps);
            //    //DnD: Each new column is inititialize with  DataGridTextColumn
            //    ///befor assigning actual column type below.
            //    newDgPage.Columns.Add(new DataGridTextColumn());
            //    //LocalValueEntry[] dps = (LocalValueEntry[])ColDpList[k][1];
            //    ///DnD The actual  DataGridColumn Type and data is now applied 
            //    ///from the cloned columns's dependency propts.
            //    foreach (LocalValueEntry dp in dps)
            //        newDgPage.Columns[rowIndex].SetValue(dp.Property, dp.Value);
            //}

            return colDenpdProptsList;
        }

        private static LocalValueEntry[] GetDependecyPropts(DataGridColumn dgColumn)
        {
            var colDbPropts = new List<LocalValueEntry>();

            var enut = dgColumn.GetLocalValueEnumerator();

            while (enut.MoveNext())
            {
                LocalValueEntry colPropt = (LocalValueEntry)enut.Current;
                if (colPropt == null || colPropt.Property.ReadOnly)
                    continue;

                colDbPropts.Add(colPropt);
            }

            return colDbPropts.ToArray();
        }

        public DataGrid GetClonedDg(DataGrid grid)
        {
            var ColDpList = GetColumDepdProptsAsync(grid).Result;
            var newDgPage = new DataGrid();
            foreach (LocalValueEntry[] dps in ColDpList)
            {
                int rowIndex = ColDpList.IndexOf(dps);
                //DnD: Each new column is inititialize with  DataGridTextColumn
                ///befor assigning actual column type below.
                newDgPage.Columns.Add(new DataGridTextColumn());
                //LocalValueEntry[] dps = (LocalValueEntry[])ColDpList[k][1];
                ///DnD The actual  DataGridColumn Type and data is now applied 
                ///from the cloned columns's dependency propts.
                foreach (LocalValueEntry dp in dps)
                    newDgPage.Columns[rowIndex].SetValue(dp.Property, dp.Value);
            }
            return newDgPage;
        }




        private static List<DataGridColumn> GetDgColumnsList(DataGrid grid)
        {
            List<DataGridColumn> dgCols = new List<DataGridColumn>();
            for (int x = 0; x < grid.Columns.Count; x++)
            {

                DependencyObjectType colTyp = grid.Columns[x].DependencyObjectType;
                switch (colTyp.Name)
                {
                    case "DataGridTextColumn":
                        dgCols.Add(new DataGridTextColumn());
                        break;

                    case "DataGridComboBoxColumn":
                        dgCols.Add(new DataGridComboBoxColumn());
                        break;
                    case "DataGridCheckBoxColumn":
                        dgCols.Add(new DataGridCheckBoxColumn());
                        break;
                    case "DataGridTemplateColumn":
                        dgCols.Add(new DataGridTemplateColumn());
                        break;
                    default:
                        throw new NotImplementedException("Missing Switch Case");

                }

            }
            return dgCols;
        }


        private static DataGrid CloneFromDgColumns(IList<DataGridColumn> dgColumns)
        {
            DataGrid dgClone = new DataGrid();

            var headers = new Dictionary<int, LocalValueEntry[]>();
            var dgCols = dgColumns.ToArray();

            for (int x = 0; x < dgCols.Length; x++)// DataGridColumn col in dgCols)
            {
                var col = dgCols[x];
                int colIndex = x;// dgCols.IndexOf(col);

                col.Header = col.Header;
                var enut = dgCols[colIndex].GetLocalValueEnumerator();
                var colDetails = new List<LocalValueEntry>();//[enut.Count];
                                                             //int x = 0;
                                                             //enut.Reset();
                while (enut.MoveNext())
                {
                    LocalValueEntry colPropt = (LocalValueEntry)enut.Current;
                    if (colPropt == null || colPropt.Property.ReadOnly)
                        continue;

                    colDetails.Add(colPropt);
                }

                headers.Add(colIndex, colDetails.ToArray());
            }

            foreach (int k in headers.Keys)
            {
                LocalValueEntry[] dps = headers[k];
                foreach (LocalValueEntry dtl in dps)
                    dgClone.Columns[k].SetValue(dtl.Property, dtl.Value);
            }

            return dgClone;
        }

        //private FixedPage FixedPageFromCanvas(DataGrid gridToAdd, Size pageSize, int pageNumber, double leftOffSet, double topOffSet)
        //{
        //    var fixedPage = new FixedPage();
        //    fixedPage.Background = Brushes.White;
        //    fixedPage.Width = pageSize.Width;
        //    fixedPage.Height = pageSize.Height;

        //    // add date
        //    TextBlock dateText = new TextBlock();
        //    if (DateVisibility) dateText.Visibility = Visibility.Visible;
        //    else dateText.Visibility = Visibility.Hidden;

        //    string now = DateTime.Now.ToShortDateString();
        //    dateText.Text = now;

        //    // add page number
        //    TextBlock PageNumberText = new TextBlock();
        //    if (PageNumberVisibility) PageNumberText.Visibility = Visibility.Visible;
        //    else PageNumberText.Visibility = Visibility.Hidden;
        //    PageNumberText.Text = "Page : " + pageNumber;

        //    FixedPage.SetTop(dateText, topOffSet);
        //    FixedPage.SetLeft(dateText, Margin);

        //    FixedPage.SetTop(PageNumberText, topOffSet);
        //    FixedPage.SetLeft(PageNumberText, leftOffSet - PageNumberText.Text.Length * 10);

        //    var margins = new Thickness(Margin * 2);
        //    Canvas canv = Preview.GetVisualCanvas(gridToAdd, pageSize, margins);

        //    fixedPage.Children.Add(canv);
        //    fixedPage.Children.Add(dateText);
        //    fixedPage.Children.Add(PageNumberText);

        //    return fixedPage;
        //}


        //public void PrintFixedDocument(FixedDocument fixedDoc, PrintDialog printDialog)
        //{
        //    XpsDocumentWriter writer = PrintQueue.CreateXpsDocumentWriter(printDialog.PrintQueue);
        //    writer.Write(fixedDoc, printDialog.PrintTicket);
        //}

    }


    public class Preview : Window
    {
        public Preview(UIElement uIElement, Size size)
        {
            //var paginator = new FlexPaginator(dataGrid, ScaleMode.PageWidth, sz, new Thickness(96 / 4), 100);
            string tempFileName = System.IO.Path.GetTempFileName();
            File.Delete(tempFileName);

            //uIElement.Measure(new Size(900, 9900));
            if (uIElement.GetType() == typeof(DataGrid))
            {
                DataGrid dg = uIElement as DataGrid;
                //((DataGrid)uIElement).ScrollIntoView(dg.Items[dg.Items.Count-1]);
            }

            using (XpsDocument xpsDocument = new XpsDocument(tempFileName, FileAccess.ReadWrite))
            {
                System.Windows.Xps.XpsDocumentWriter writer = XpsDocument.CreateXpsDocumentWriter(xpsDocument);
                if (uIElement.RenderSize == null) return;
                writer.Write(uIElement);
                DocumentViewer previewWindow = new DocumentViewer
                {

                    Document = xpsDocument.GetFixedDocumentSequence()
                };

                //Window printpriview = new Window();
                //printpriview.Content = previewWindow;
                //printpriview.Title = "PayPattern: Print Preview";
                //printpriview.Show();

                //Window printpriview = new Window();
                this.Width = size.Width + 200;
                this.Height = size.Height + 50;

                this.Content = previewWindow;
                this.Title = "PayPattern: Print Preview";
                //this.Show();

            }
        }

        public Preview(DocumentPaginator paginator)
        {
            //var paginator = new FlexPaginator(dataGrid, ScaleMode.PageWidth, sz, new Thickness(96 / 4), 100);
            string tempFileName = System.IO.Path.GetTempFileName();

            File.Delete(tempFileName);

            using (XpsDocument xpsDocument = new XpsDocument(tempFileName, FileAccess.ReadWrite))
            {
                System.Windows.Xps.XpsDocumentWriter writer = XpsDocument.CreateXpsDocumentWriter(xpsDocument);
                paginator.ComputePageCount();
                if (paginator.PageCount < 1) return;
                writer.Write(paginator);
                DocumentViewer previewWindow = new DocumentViewer
                {

                    Document = xpsDocument.GetFixedDocumentSequence()
                };

                //Window printpriview = new Window();
                //printpriview.Content = previewWindow;
                //printpriview.Title = "PayPattern: Print Preview";
                //printpriview.Show();

                //Window printpriview = new Window();
                this.Content = previewWindow;
                this.Title = "PayPattern: Print Preview";
                //this.Show();

            }
        }

        public Preview(DocumentPaginator paginator, string range)
        {
            //var paginator = new FlexPaginator(dataGrid, ScaleMode.PageWidth, sz, new Thickness(96 / 4), 100);
            string tempFileName = System.IO.Path.GetTempFileName();

            File.Delete(tempFileName);

            using (XpsDocument xpsDocument = new XpsDocument(tempFileName, FileAccess.ReadWrite))
            {
                System.Windows.Xps.XpsDocumentWriter writer = XpsDocument.CreateXpsDocumentWriter(xpsDocument);
                if (paginator.PageCount < 1) return;

                //while(pgNo<)
                //paginator.GetPage(9)
                writer.Write(paginator);
                DocumentViewer previewWindow = new DocumentViewer
                {

                    Document = xpsDocument.GetFixedDocumentSequence()
                };

                //Window printpriview = new Window();
                //printpriview.Content = previewWindow;
                //printpriview.Title = "PayPattern: Print Preview";
                //printpriview.Show();

                //Window printpriview = new Window();
                this.Content = previewWindow;
                this.Title = "PayPattern: Print Preview";
                //this.Show();

            }
        }


        public static void PrintVisual(DataGrid dg, ScrollViewer panel)
        {
            PrintDialog dlg = new PrintDialog();

            //btnPrint.Visibility = Visibility.Hidden;
            //label1.Visibility = Visibility.Hidden;

            //this.Background = Brushes.White;
            //  cnv.Background = Brushes.White;
            //scroll.Visibility = Visibility.Visible;
            //panel.Visibility = Visibility.Hidden;
            dg.Background = Brushes.White;
            //this.Width = 350;
            string tempFileName = System.IO.Path.GetTempFileName();

            File.Delete(tempFileName);

            using (XpsDocument xpsDocument = new XpsDocument(tempFileName, FileAccess.ReadWrite))
            {
                System.Windows.Xps.XpsDocumentWriter writer = XpsDocument.CreateXpsDocumentWriter(xpsDocument);
                //if (paginator.PageCount < 1) return;
                Visual vis = panel.Content as Visual;
                writer.Write(vis);

                DocumentViewer previewWindow = new DocumentViewer
                {


                    Document = xpsDocument.GetFixedDocumentSequence()
                };

                Window wind = new Window
                {
                    Content = previewWindow
                };
                wind.ShowDialog();
            }
        }

        public static void PrintVisual(DataGrid dg, Size printSize)
        {
            PrintDialog dlg = new PrintDialog();

            //btnPrint.Visibility = Visibility.Hidden;
            //label1.Visibility = Visibility.Hidden;

            //this.Background = Brushes.White;
            //  cnv.Background = Brushes.White;
            //scroll.Visibility = Visibility.Visible;
            //panel.Visibility = Visibility.Hidden;
            dg.RenderSize = new Size(850, 900);
            dg.Arrange(new Rect(printSize));
            dg.UpdateLayout();
            dg.Background = Brushes.White;
            //this.Width = 350;
            string tempFileName = System.IO.Path.GetTempFileName();

            File.Delete(tempFileName);

            using (XpsDocument xpsDocument = new XpsDocument(tempFileName, FileAccess.ReadWrite))
            {
                System.Windows.Xps.XpsDocumentWriter writer = XpsDocument.CreateXpsDocumentWriter(xpsDocument);
                //if (paginator.PageCount < 1) return;
                Visual vis = dg as Visual;
                writer.Write(vis);

                DocumentViewer previewWindow = new DocumentViewer
                {


                    Document = xpsDocument.GetFixedDocumentSequence()
                };

                Window wind = new Window
                {
                    Content = previewWindow
                };
                wind.ShowDialog();
            }
        }
        public static void PrintVisual(DataGrid dg)
        {
            PrintDialog dlg = new PrintDialog();

            //btnPrint.Visibility = Visibility.Hidden;
            //label1.Visibility = Visibility.Hidden;

            //this.Background = Brushes.White;
            //  cnv.Background = Brushes.White;
            //scroll.Visibility = Visibility.Visible;
            //panel.Visibility = Visibility.Hidden;
            var sz = dg.RenderSize.Height < 100 ? new Size(850, 900) : dg.RenderSize;

            dg.Arrange(new Rect(sz));
            dg.UpdateLayout();
            dg.Background = Brushes.White;
            //this.Width = 350;
            string tempFileName = System.IO.Path.GetTempFileName();

            File.Delete(tempFileName);

            using (XpsDocument xpsDocument = new XpsDocument(tempFileName, FileAccess.ReadWrite))
            {
                System.Windows.Xps.XpsDocumentWriter writer = XpsDocument.CreateXpsDocumentWriter(xpsDocument);
                //if (paginator.PageCount < 1) return;
                Visual vis = dg as Visual;
                writer.Write(vis);

                DocumentViewer previewWindow = new DocumentViewer
                {


                    Document = xpsDocument.GetFixedDocumentSequence()
                };

                Window wind = new Window
                {
                    Content = previewWindow
                };
                wind.ShowDialog();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="printobject"></param>
        /// <param name="pageSize"></param>
        /// <param name="margin"></param>
        /// <returns></returns>
        public static Canvas GetVisualCanvas(FrameworkElement printobject, Size pageSize, Thickness margin)
        {
            printobject.Margin = new Thickness(0, 0, 0, 0);
            Visual vis = printobject as Visual;

            VisualBrush vb2 = new VisualBrush(vis);
            //vb2.Stretch = Stretch.None;
            vb2.AlignmentX = AlignmentX.Left;
            vb2.AlignmentY = AlignmentY.Top;
            vb2.ViewboxUnits = BrushMappingMode.Absolute;
            vb2.TileMode = TileMode.None;
            vb2.Stretch = Stretch.Uniform;
            vb2.Viewbox = new Rect(pageSize);

            vb2.AutoLayoutContent = true;
            margin.Right = 40;
            //Size visibleSize = new Size(pageSize.Width + margin.Left + margin.Right, pageSize.Height + margin.Top + margin.Bottom);
            Canvas.SetLeft(printobject, 0);
            Canvas canv = new Canvas
            {
                Width = pageSize.Width,// visibleSize.Width,
                Height = pageSize.Height,// visibleSize.Height,
                Background = vb2,
                Margin = margin,

                //Padding = new Thickness(0)

            };
            return canv;
        }
    }

}