﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PagingControl
{
    /// <summary>
    /// Interaction logic for DataGridModel.xaml
    /// </summary>
    public partial class ViewsDataGrid : UserControl, IDisposable
    {
        public ViewsDataGrid() 
        {
            InitializeComponent();
            //DataContext = new ContentViewModel();
            DataContextChanged += OnDataContextChanged;
            DgViews2 = DgViews = dataGridViews;

            DgViews.Cursor = Cursors.Wait;
            DgViews.Loaded += ViewsDataGrid_Loaded;
            //this.Loaded += ViewsDataGrid_Loaded;
            var col = DgViews.Columns[2] as DataGridColumn;

            DgViews.DataContextChanged += DgViews_DataContextChanged;
            //this.DataContext
            //this.ItemSource =(ICollectionView) DgViews.ItemsSource;

            
            ViewsDataGrid.GetColumnHdrStyle = GetColumnHdrStyle ??(Style)this.FindResource("ColumnHeaderStyle1");

            //var sourceBinding = new Binding("ItemSource");
            //sourceBinding.Source = this;
            //sourceBinding.Mode = BindingMode.TwoWay;
            //dataGridViews.SetBinding(DataGrid.ItemsSourceProperty, sourceBinding);
        }


        public bool IsDisposed = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!IsDisposed)
            {
                if (disposing)
                {

                }

            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        ~ViewsDataGrid()
        {
            Dispose(IsDisposed);
        }

        public DataGrid DgViews { get; set; }
        public static DataGrid DgViews2 { get; set; }

        private void OnDataContextChanged(object sender, System.Windows.DependencyPropertyChangedEventArgs e)
        {
            //var info = DataContext as ColorInfo;
            //if (info == null) return;
            //this.Key =IdText.Text = info.Key;
            //this.ColorBrush = info.Val;
            DataContextChanged -= OnDataContextChanged; // load text only once
        }

        //public static DataGrid VwDataGrid { get; set; }
        private void DgViews_DataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
        {


            object obj = /*((ColorInfo)*/((DataGrid)sender).DataContext/*).PattnList as ListCollectionView*/;
            obj = obj as ColorInfo;
            if (obj == null || obj.GetType() != typeof(ColorInfo))
                return;

            var printformats = (ColorInfo)obj;
            //var grp = printformats.ItemProperties;
            DgViews.DataContextChanged -= DgViews_DataContextChanged;

            //this.DataContext
            //throw new NotImplementedException();

        }

        private void InsertColumn(DataGridColumn[] columns, DataGrid dataGrid)
        {

            foreach (var column in columns)
            {

                //< DataGridTextColumn Header = "Names" Binding = "{Binding Name}"  Width = "Auto" />

                var bind = string.Format("Properties[{0}]");//, column.Index);
                var binding = new Binding(bind);

                dataGrid.Columns.Add(new CustomBoundColumn()
                {
                    //Header = column.Name,
                    Binding = binding,
                    //TemplateName = DgViews.Columns[2].HeaderTemplate.FindName()// "CustomTemplate"
                });
            }
            //txtNewCol.Text = "City";

        }


        private static double HeaderFontSize = 14;
        private static Style columnStyle
        {
            get
            {
                var colStyle = new Style(typeof(DataGridColumnHeader));
                columnStyle.Setters.Add(new Setter(Control.FontSizeProperty, HeaderFontSize));
                columnStyle.Setters.Add(new Setter(Control.HorizontalContentAlignmentProperty, HorizontalAlignment.Center));
                columnStyle.Setters.Add(new Setter(Control.BorderThicknessProperty, new Thickness(0, 0.5, 0, 1.5)));
                columnStyle.Setters.Add(new Setter(Control.BackgroundProperty, Brushes.White));
                columnStyle.Setters.Add(new Setter(Control.BorderBrushProperty, Brushes.Black));
                columnStyle.Setters.Add(new Setter(Control.FontWeightProperty, FontWeights.SemiBold));
                return colStyle;
            }
        }
        private DataGridColumn AddColumn(DataGrid grid)
        {
            DataGridColumn dgCol = null;
            foreach (var column in grid.Columns)
            {
                if (column.Visibility != Visibility.Visible) continue;
                if (column.GetType() != typeof(DataGridTextColumn))
                {
                    //DataGridColumn cl = null;
                    if (column.GetType() == typeof(DataGridTemplateColumn))
                    {
                        DataGridTemplateColumn cl = new DataGridTemplateColumn();
                        cl.HeaderStyle = columnStyle;
                        cl.Header = column.Header;
                        //cl.Width = column.ActualWidth / GridActualWidth * PageWidthWithMargin;
                        //cl.Binding = ((DataGridTemplateColumn)column).Binding;

                        dgCol = cl;
                    }
                    else
                    if (column.GetType() == typeof(DataGridCheckBoxColumn))
                    {
                        DataGridCheckBoxColumn cl = new DataGridCheckBoxColumn();
                        cl.HeaderStyle = columnStyle;
                        cl.Header = column.Header;
                        //cl.Width = column.ActualWidth / GridActualWidth * PageWidthWithMargin;
                        cl.Binding = ((DataGridCheckBoxColumn)column).Binding;

                        dgCol = cl;


                    }

                }
                else
                {
                    DataGridTextColumn textColumn = new DataGridTextColumn();
                    textColumn.HeaderStyle = columnStyle;
                    textColumn.Header = column.Header;
                    //textColumn.Width = column.ActualWidth / GridActualWidth * PageWidthWithMargin;

                    textColumn.Binding = ((DataGridTextColumn)column).Binding;
                    dgCol = textColumn;

                    //DataGridColumn dgCol = textColumn.bin;

                }
            }

            return dgCol;
        }

        private void ViewsDataGrid_Loaded(object sender, RoutedEventArgs e)
        {
            DgViews.Cursor = null;
            this.Loaded -= ViewsDataGrid_Loaded;
        }


        //    public static readonly DependencyProperty ColumnHdrStyleProperty =
        //DependencyProperty.Register("ColumnHdrStyle", typeof(Style), typeof(Control)/*,
        //          new  PropertyMetadata(false, new PropertyChangedCallback(OnSetTextChanged))*/);


        //public Style ColumnHdrStyle
        //{
        //    get { return (Style)GetValue(ColumnHdrStyleProperty); }
        //    set { SetValue(ColumnHdrStyleProperty, value); }
        //}

        public string Key { get; private set; }
        public Color ColorBrush { get; private set; }

        //private static ViewsDataGrid PrintControl0 => new ViewsDataGrid();
        public static Style GetColumnHdrStyle { get; private set; }
        //{
        //    get { return (Style)PrintControl0.FindResource("ColumnHeaderStyle1"); }
        //}

        public ICollectionView ItemSource { get; set; }
    }


}
