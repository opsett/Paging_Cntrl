﻿using SharedResource;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Printing;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Threading;
using System.Windows.Xps;
using System.Windows.Xps.Packaging;

namespace PagingControl
{

    public class ProcessPrint : IDisposable
    {
        public const double cm = 37;
        public static double Margin = 0.75 * cm;
        public double PageWidth = 21 * cm;
        //public double PageHeight = 29 * cm;
        //public double RowHeight = 0.7 * cm;
        public static bool PageNumberVisibility = true;
        public static bool DateVisibility = true;
        public double FontSize = 14;
        public double HeaderFontSize = 14;
        public bool IsBold = false;
        public ProcessPrint()
        {
            PatternWkBook.PagingInfo = this;
        }
        public ProcessPrint(DataGrid originalDg)
        {
            //this.DataGridRows = ReapDataGrid(ref originalDg, out var columnsDpList);
            //this.ColumnsDpList = columnsDpList;
            //this.SourceDataGrid = originalDg;

            ReapDataGrid(ref originalDg);
            this.ColumnsDpList = GetColumDepdPropts(originalDg);//, out var columnsDpList);
                                                                //columnsDpList;
            this.SourceDataGrid = originalDg;
            PatternWkBook.PagingInfo = this;
            //PageTemplate = new PagingTemplate();

        }


        //[ThreadStatic()]
        //private static PagingTemplate PageTemplate0;
        //public static PagingTemplate PageTemplate
        //{
        //    get => PageTemplate0 = PageTemplate0 == null ?
        //        new PagingTemplate() : PageTemplate0;
        //}
        private static TextBlock GetGespatch(TextBlock tb)
        {
            TextBlock txtBlock = null;
            tb.Dispatcher.Invoke(() => txtBlock = new TextBlock());
            return txtBlock;
        }

        //public static ViewsDataGrid PageTemplate0;
        //public static ViewsDataGrid _viewsDataGrid { get; set; } = _viewsDataGrid == null ? new ViewsDataGrid() : _viewsDataGrid;
        public static ViewsDataGrid _viewsDataGrid { get => new ViewsDataGrid(); }

        public static PagingTemplate PageTemplate2 { get; set; } = PageTemplate2 == null ?
            new PagingTemplate() : PageTemplate2;

        //public static TextBlock DateText { get; set; } = DateText == null ?
        //    new TextBlock() :(!DateText.Dispatcher.CheckAccess()? GetGespatch(DateText): DateText);

        public static TextBlock NewTxtBlock { get => new TextBlock(); }

        public static Window NewWindow { get => new Window(); }


        //public static TextBlock PageNumbText { get; set; } = PageNumbText == null ?
        //    new TextBlock() : PageNumbText;

        public static PagingTemplate PageTemplate0;
        public static PagingTemplate PageTemplate => NewTemplate();


        private static PagingTemplate NewTemplate()
        {
            PagingTemplate pt = null;
            if (PageTemplate2 == null || PageTemplate2.Dispatcher.CheckAccess())
                pt = PageTemplate2;
            else
            {
                object val = null;
                PageTemplate2.Dispatcher.Invoke(() =>
                {
                    pt = new PagingTemplate();


                    //val = pt.GetValue(PagingTemplate.PageTemplateProperty);

                });
            }
            //return pt = (PagingTemplate)val;

            return/* PageTemplate2 = PageTemplate0 =*/ pt.PageTemplate;// PagingTemplate.PageTemplateProperty;// pt;
        }
        /// <summary>
        /// This long format is prefers as the short coalesc format often fails
        /// </summary>
        //public static TextBlock _textBlock { get => new TextBlock(); }

        //public static TextBlock _textBlock { get; set; } = _textBlock == null ? 
        //    new TextBlock() : _textBlock;

        //public static PagingTemplate GetPageTemplate { get => new PagingTemplate().PageTemplate;}
        //{
        //    return new PagingTemplate().PageTemplate;
        //}
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sourceDatagrid">The source datagrid: it layout must have been visually rendered
        /// by calling [.UpdateLayout] on its visual container such window or usercontrol </param>
        /// <param name="mediaSize"></param>
        public ProcessPrint(DataGrid sourceDatagrid, PageMediaSize mediaSize)
        {



            //var pattnStrArr = PrintFormat.GetSamplePattern(pttnList, out PrintFormat[] pttnArr);
            var paperSize = new Size(mediaSize.Width.Value, mediaSize.Height.Value);
            var printHeight = paperSize.Height - (40 + GuiStat.PrintMargin.Top + GuiStat.PrintMargin.Bottom);
            this.PageHeight = printHeight;// printSize.Height;
            //procePrint.PreviewMod = PrintPreview.None;

            ///DnD ChrOder: Should be assinged 1st
            this.PageSize = new Size((int)mediaSize.Width, (int)mediaSize.Height);// mediaSize;

            this.ColumnsDpList = GetColumDepdPropts(sourceDatagrid);//, out var columnsDpList);

            this.DataGridRows = ReapDataGrid(ref sourceDatagrid);

            //columnsDpList;
            this.SourceDataGrid = sourceDatagrid;

            //if (this.DataGridRows == null) return;
            //this.SizeUpMode = sizeUpMode;

            ///DnD this.DataGridRows is assigned by ReapDataGrid;

            //if (this.SizeUpMode || (this.SizeUpMode = copiedRows.Count == 1))
            //    while (copiedRows.Count < RowsPerPage)
            //        copiedRows.Add(row);

            PatternWkBook.PagingInfo = this;

        }

        public ProcessPrint ProcessPage(string[] pttnList, PageMediaSize media, PatternWkBook wkBook)
        {
            //var dg = new DataGrid();
            ///DnD: Use single row data to create a dagagrid row
            var pattnStrArr = PrintFormat.GetSamplePattern(pttnList, out PrintFormat[] pttnArr);


            ViewsDataGrid dgm = new ViewsDataGrid();
            var dg = dgm.DgViews;
            dg.ItemsSource = pattnStrArr;
            /* ///*/
            var tabControlMgr = wkBook.TabCtrMgr;

            ///DnD: ChrOrdered
            ///DnD tabControlMgr is temporally used to optimized  datagrid by using its
            ///[UpdateLayout()] function while hosting datagrid as content. Thereafter
            ///the must be datagrid is detached by asigning null as content. Same procese
            ///is repeated below before finally reusing the [tabcontrolMgr] as to host
            ///tabpages. Such reuses instead of using new instances helps conserve overhead
            var contHold = tabControlMgr.Content;
            tabControlMgr.Content = dgm;
            tabControlMgr.UpdateLayout();
            tabControlMgr.Content = null;
            tabControlMgr.Content = contHold;
            ///*/
            //this.PattnList = pttnList;

            ///DnD: ChrOdered
            var pp = new ProcessPrint(dg, media);
            pp.PattnList = pttnList;
            return pp;
        }

        private string[] PattnList { get; set; }
        public DataGrid SourceDataGrid { get; private set; }


        public string[][] SplitListToPages() { return SplitListToPages(this.PattnList, this.RowsPerPage); }
        public string[][] SplitListToPages(string[] pttnList, int rowsPerPage)
        {
            return Stat.ReSizeToArr(pttnList, rowsPerPage)
                 .Select(i => (string[])(i.Select(ii => (string)ii).ToArray())).ToArray();
        }



        /// <summary>
        /// This boolean value, whem true indicates that this class's object  is
        /// intented to aid in calculating the number of datagrid rows 
        /// that will fit into the page size specified in  MediaSize.
        /// </summary>
        //public bool DupMode { get; set; }

        /// <summary>
        /// The DataGrid colums dependency propts are assigned to this property
        /// for recoursive use incloning columns
        /// </summary>
        public List<LocalValueEntry[]> ColumnsDpList { get; private set; }
        public DataGridRow[] DataGridRows { get; private set; }

        //private DataGridRow[] DupDgridRows { get; set; }
        //private string[][] SourceList { get; set; }

        //public DataGrid PrintPage { get => GetDgPages(UnitRowHeight)[0]; }

        //public double UnitRowHeight { get=> DataGridRows[0].ActualHeight; }

        //private static List<object> ItemSource0 { get; set; }
        //public async Task<List<object>> ReapedItemSource()
        //{
        //    return ItemSource0;// DataGridRows.Select(r => r.Item).ToList();

        //}

        public PrintPreview PreviewMod { get; set; }

        //public ListCollectionView DuplicateSeeds { get; set; }


        /// <summary>
        /// Collates the rows of the reffed parameter [dataGrid] as Dependency
        /// Properties, such that the reaped rows are no longer attached and
        /// therefor, can be safely used in creating rows in a new datagrid. 
        /// 
        /// Additionally this function also computes the number of datagrid rows
        /// that will fill the indicated page-size [MediaSize] and assign the
        /// value to the class propt, [RowsPerPage].
        /// 
        /// </summary>
        /// <param name="dataGrid">The Datagrid which rows are to be cloned</param>
        /// <returns></returns>
        public DataGridRow[] ReapDataGrid(ref DataGrid dataGrid)
        {
            ///DnD Reap column hearder and assing to local variable columnDepdPropts 
            if (dataGrid.Items.Count < 1) return null;

            if ((DataGridRow)dataGrid.ItemContainerGenerator.ContainerFromIndex(0) == null
               && !OptimizeVisual(dataGrid)) return null;

            List<object> copiedRows = new List<object>(), pageRows;
            List<DataGridRow> dgRows = new List<DataGridRow>();
            DataGridRow row = null;
            int x = 0;
            while (x < dataGrid.Items.Count)
            {
                //int x = dataGrid.Items.IndexOf(o);
                row = (DataGridRow)dataGrid.ItemContainerGenerator.ContainerFromIndex(x);
                //row =  (DataGridRow)dataGrid.ItemContainerGenerator.ContainerFromItem(o);
                object rowIitem = dataGrid.Items[x++];
                //row.Margin = new Thickness(0, 0, 0, 0);
                dgRows.Add(row);

                //if (!row.Item.Equals(rowIitem))
                //    ;

                copiedRows.Add(rowIitem);
                //if (DupMode)
                //{
                //    return new DataGridRow[] { (DataGridRow)rowIitem };
                //}

            }


            //this.DataGridRows = dgRows.ToArray();

            ///DnD The number of DataGrid rows that will size a page is next computer
            if (dgRows[0].ActualHeight > 0)
            {

                double ht = dgRows[0].ActualHeight,
                sumHt = dgRows.Sum(h => h.ActualHeight);
                var count = dgRows.Count;

                while (sumHt < this.PageHeight)
                    sumHt = ++count * ht;

                RowsPerPage = count;

            }

            dataGrid.ItemsSource = copiedRows;
            var rowArray = dgRows.ToArray();

            return rowArray;
        }

        private bool OptimizeVisual(DataGrid dg)
        {

            var tabMgr = new TabControlMgr();
            var wind = new Window();
            wind.Content = tabMgr;

            tabMgr.Content = dg;
            tabMgr.UpdateLayout();
            wind.Close();
            var row = (DataGridRow)dg.ItemContainerGenerator.ContainerFromIndex(0);
            return row != null && row.ActualHeight < 0;
        }
        public DataGridRow[] ReapDataGridXXX(ref DataGrid dataGrid)
        {
            ///DnD Reap column hearder and assing to local variable columnDepdPropts 
            if (dataGrid.Items.Count < 1) return null;

            List<object> copiedRows = new List<object>(), pageRows;
            List<DataGridRow> dgRows = new List<DataGridRow>();
            DataGridRow row = null;

            foreach (object o in dataGrid.Items)
            {
                int x = dataGrid.Items.IndexOf(o);
                row = (DataGridRow)dataGrid.ItemContainerGenerator.ContainerFromIndex(x);
                //row =  (DataGridRow)dataGrid.ItemContainerGenerator.ContainerFromItem(o);
                object rowIitem = dataGrid.Items[x];
                //row.Margin = new Thickness(0, 0, 0, 0);
                dgRows.Add(row);

                //if (!row.Item.Equals(rowIitem))
                //    ;

                copiedRows.Add(rowIitem);
                //if (DupMode)
                //{
                //    return new DataGridRow[] { (DataGridRow)rowIitem };
                //}

            }

            //this.DataGridRows = dgRows.ToArray();

            ///DnD The number of DataGrid rows that will size a page is next computer
            if (dgRows[0].ActualHeight > 0)
            {

                double ht = dgRows[0].ActualHeight,
                sumHt = dgRows.Sum(h => h.ActualHeight);
                var count = dgRows.Count;

                while (sumHt < this.PageHeight)
                    sumHt = ++count * ht;

                RowsPerPage = count;

            }

            dataGrid.ItemsSource = copiedRows;
            var rowArray = dgRows.ToArray();

            return rowArray;
        }


        public FixedDocument GetFixDoc(IList dataGridPages, Size printSize, Thickness printMargin)
        {
            if (dataGridPages == null || dataGridPages.Count < 1) return null;
            ////return null;
            //System.Windows.Input.Cursors.Wait;
            //System.Windows.Input.CursorType.Wait;
            Double printableWidth = printSize.Width;
            Double printableHeight = printSize.Height;

            FixedDocument fixedDoc = new FixedDocument();

            var margin = printMargin;

            string now = DateTime.Now.ToString("dd/MMM/yyy");//.ToShortDateString();

            var pgs = dataGridPages.Count.ToString();
            foreach (DataGrid dg in dataGridPages)
            {

                // add date
                TextBlock dateText = new TextBlock();
                if (DateVisibility) dateText.Visibility = Visibility.Visible;
                else dateText.Visibility = Visibility.Hidden;

                dateText.Text = now;

                //List<DataGrid> dg = new List<DataGrid>();
                int pageNumber = dataGridPages.IndexOf(dg) + 1;


                // add page number
                TextBlock PageNumberText = new TextBlock();
                if (PageNumberVisibility) PageNumberText.Visibility = Visibility.Visible;
                else PageNumberText.Visibility = Visibility.Hidden;

                PageNumberText.Text = "Page : " + pageNumber.ToString().PadLeft(pgs.Length, '0') + "/" + dataGridPages.Count;
                PageNumberText.SetValue(TextElement.FontWeightProperty, FontWeights.Bold);


                FixedPage.SetTop(dateText, printableHeight - 25);
                FixedPage.SetLeft(dateText, Margin + margin.Left);

                FixedPage.SetTop(PageNumberText, printableHeight - 25);
                FixedPage.SetLeft(PageNumberText, Margin + (printableWidth - PageNumberText.Text.Length * 10) / 2);
                //var testIt = newDgPage.SelectedItem;


                //FixedPageFromCanvas(newDgPage, size, pageNumber, PageHeightWithMargin, PageHeightWithMargin);

                var size = new Size(printableWidth, printableHeight);

                var canv = Preview.GetVisualCanvas(dg, size, new Thickness(0));

                var fixedPage = new FixedPage
                {
                    Background = Brushes.White,
                    Width = printableWidth,
                    Height = printableHeight,
                    Margin = new Thickness(0),

                };

                //fixedPage.Children.Add(dateText);
                //fixedPage.Children.Add(PageNumberText);

                //fixedPage.Children.Add(newDgPage);
                FixedPage.SetLeft(canv, Margin + margin.Left);
                FixedPage.SetTop(canv, margin.Top);

                fixedPage.Children.Add(canv);
                fixedPage.Children.Add(dateText);
                fixedPage.Children.Add(PageNumberText);


                PageContent pageContent = new PageContent();
                ((IAddChild)pageContent).AddChild(fixedPage);


                fixedDoc.Pages.Add(pageContent);



            }
            if (PreviewMod == PrintPreview.AllPages)
                new Preview(fixedDoc.DocumentPaginator).ShowDialog();

            //await Task.Run(() => fixedDoc.GetType());

            return fixedDoc;
        }

        public FixedDocument GetFixDoc(UIElement[] dgs, Size printSize, Thickness printMargin)
        {
            if (dgs == null || dgs.Length < 1) return null;
            ////return null;
            //System.Windows.Input.Cursors.Wait;
            //System.Windows.Input.CursorType.Wait;
            Double printableWidth = printSize.Width;
            Double printableHeight = printSize.Height;

            FixedDocument fixedDoc = new FixedDocument();

            var margin = printMargin;

            string now = DateTime.Now.ToString("dd/MMM/yyy");//.ToShortDateString();

            var pgs = dgs.Length.ToString();
            int x = 0;
            while (x < dgs.Length)
            {

                TextBlock dateText = new TextBlock();
                if (DateVisibility) dateText.Visibility = Visibility.Visible;
                else dateText.Visibility = Visibility.Hidden;

                dateText.Text = now;

                //List<DataGrid> dg = new List<DataGrid>();
                //int pageNumber = dataGridPages.IndexOf(dg) + 1;

                int pageNumber = x + 1;

                // add page number
                TextBlock PageNumberText = new TextBlock();
                if (PageNumberVisibility) PageNumberText.Visibility = Visibility.Visible;
                else PageNumberText.Visibility = Visibility.Hidden;

                PageNumberText.Text = "Page : " + pageNumber.ToString().PadLeft(pgs.Length, '0') + "/" + dgs.Length;
                PageNumberText.SetValue(TextElement.FontWeightProperty, FontWeights.Bold);


                FixedPage.SetTop(dateText, printableHeight - 25);
                FixedPage.SetLeft(dateText, Margin + margin.Left);

                FixedPage.SetTop(PageNumberText, printableHeight - 25);
                FixedPage.SetLeft(PageNumberText, Margin + (printableWidth - PageNumberText.Text.Length * 10) / 2);
                //var testIt = newDgPage.SelectedItem;


                //FixedPageFromCanvas(newDgPage, size, pageNumber, PageHeightWithMargin, PageHeightWithMargin);

                var size = new Size(printableWidth, printableHeight);

                //var canv = Preview.GetVisualCanvas(dgs[x], size, new Thickness(0));
                var dg = dgs[x];
                var fixedPage = new FixedPage
                {
                    Background = Brushes.White,
                    Width = printableWidth,
                    Height = printableHeight,
                    Margin = new Thickness(0),

                };

                //fixedPage.Children.Add(dateText);
                //fixedPage.Children.Add(PageNumberText);

                //fixedPage.Children.Add(newDgPage);
                FixedPage.SetLeft(dg, Margin + margin.Left);
                FixedPage.SetTop(dg, margin.Top);

                fixedPage.Children.Add(dg);
                fixedPage.Children.Add(dateText);
                fixedPage.Children.Add(PageNumberText);


                PageContent pageContent = new PageContent();
                ((IAddChild)pageContent).AddChild(fixedPage);


                fixedDoc.Pages.Add(pageContent);

                x++;

            }


            return fixedDoc;
        }

        public FixedDocument GetFixDoc(DataGrid[] dgs, Size printSize, Thickness printMargin)
        {
            if (dgs == null || dgs.Length < 1) return null;
            ////return null;
            //System.Windows.Input.Cursors.Wait;
            //System.Windows.Input.CursorType.Wait;
            Double printableWidth = printSize.Width;
            Double printableHeight = printSize.Height;

            FixedDocument fixedDoc = new FixedDocument();

            var margin = printMargin;

            string now = DateTime.Now.ToString("dd/MMM/yyy");//.ToShortDateString();

            var pgs = dgs.Length.ToString();
            int x = 0;
            while (x < dgs.Length)
            {

                TextBlock dateText = new TextBlock();
                if (DateVisibility) dateText.Visibility = Visibility.Visible;
                else dateText.Visibility = Visibility.Hidden;

                dateText.Text = now;

                //List<DataGrid> dg = new List<DataGrid>();
                //int pageNumber = dataGridPages.IndexOf(dg) + 1;

                int pageNumber = x + 1;

                // add page number
                TextBlock PageNumberText = new TextBlock();
                if (PageNumberVisibility) PageNumberText.Visibility = Visibility.Visible;
                else PageNumberText.Visibility = Visibility.Hidden;

                PageNumberText.Text = "Page : " + pageNumber.ToString().PadLeft(pgs.Length, '0') + "/" + dgs.Length;
                PageNumberText.SetValue(TextElement.FontWeightProperty, FontWeights.Bold);


                FixedPage.SetTop(dateText, printableHeight - 25);
                FixedPage.SetLeft(dateText, Margin + margin.Left);

                FixedPage.SetTop(PageNumberText, printableHeight - 25);
                FixedPage.SetLeft(PageNumberText, Margin + (printableWidth - PageNumberText.Text.Length * 10) / 2);
                //var testIt = newDgPage.SelectedItem;


                //FixedPageFromCanvas(newDgPage, size, pageNumber, PageHeightWithMargin, PageHeightWithMargin);

                var size = new Size(printableWidth, printableHeight);

                var canv = Preview.GetVisualCanvas(dgs[x], size, new Thickness(0));

                var fixedPage = new FixedPage
                {
                    Background = Brushes.White,
                    Width = printableWidth,
                    Height = printableHeight,
                    Margin = new Thickness(0),

                };

                //fixedPage.Children.Add(dateText);
                //fixedPage.Children.Add(PageNumberText);

                //fixedPage.Children.Add(newDgPage);
                FixedPage.SetLeft(canv, Margin + margin.Left);
                FixedPage.SetTop(canv, margin.Top);

                fixedPage.Children.Add(canv);
                fixedPage.Children.Add(dateText);
                fixedPage.Children.Add(PageNumberText);


                PageContent pageContent = new PageContent();
                ((IAddChild)pageContent).AddChild(fixedPage);


                fixedDoc.Pages.Add(pageContent);

                x++;

            }
            if (PreviewMod == PrintPreview.AllPages)
                new Preview(fixedDoc.DocumentPaginator).ShowDialog();

            //await Task.Run(() => fixedDoc.GetType());

            return fixedDoc;
        }


        public static async Task<PattnPaginator> GetFixPagesAsync(DataGrid[] dgs, Size printSize, Thickness printMargin)
        {
            if (dgs == null || dgs.Length < 1) return null;
            ////return null;
            //System.Windows.Input.Cursors.Wait;
            //System.Windows.Input.CursorType.Wait;
            Double printableWidth = printSize.Width;
            Double printableHeight = printSize.Height;

            //FixedDocument fixedDoc = new FixedDocument();
            var fxPages = new List<FixedPage>();
            var margin = printMargin;

            string now = DateTime.Now.ToString("dd/MMM/yyy");//.ToShortDateString();

            var pgs = dgs.Length.ToString();
            int x = 0;
            while (x < dgs.Length)
            {
                TextBlock dateText = ProcessPrint.NewTxtBlock;

                if (DateVisibility) dateText.Visibility = Visibility.Visible;
                else dateText.Visibility = Visibility.Hidden;

                dateText.Text = now;

                int pageNumber = x + 1;

                // add page number
                TextBlock PageNumberText = ProcessPrint.NewTxtBlock;
                if (PageNumberVisibility) PageNumberText.Visibility = Visibility.Visible;
                else PageNumberText.Visibility = Visibility.Hidden;

                PageNumberText.Text = "Page : " + pageNumber.ToString().PadLeft(pgs.Length, '0') + "/" + dgs.Length;
                PageNumberText.SetValue(TextElement.FontWeightProperty, FontWeights.Bold);


                FixedPage.SetTop(dateText, printableHeight - 25);
                FixedPage.SetLeft(dateText, Margin + margin.Left);

                FixedPage.SetTop(PageNumberText, printableHeight - 25);
                FixedPage.SetLeft(PageNumberText, Margin + (printableWidth - PageNumberText.Text.Length * 10) / 2);

                var size = new Size(printableWidth, printableHeight);

                var canv = Preview.GetVisualCanvas(dgs[x], size, new Thickness(0));

                var fixedPage = new FixedPage
                {
                    Background = Brushes.White,
                    Width = printableWidth,
                    Height = printableHeight,
                    Margin = new Thickness(0),

                };

                FixedPage.SetLeft(canv, Margin + margin.Left);
                FixedPage.SetTop(canv, margin.Top);

                fixedPage.Children.Add(canv);
                fixedPage.Children.Add(dateText);
                fixedPage.Children.Add(PageNumberText);

                fxPages.Add(fixedPage);

                x++;

            }

            var pagntor = new PattnPaginator(fxPages.ToArray(), printSize, ScaleMode.ActualSize);

            return pagntor;
        }


        public static async Task<FixedDocument> GetFixedDocAsync(DataGrid[] dgs, Size printSize, Thickness printMargin)
        {
            if (dgs == null || dgs.Length < 1) return null;
            ////return null;
            //System.Windows.Input.Cursors.Wait;
            //System.Windows.Input.CursorType.Wait;
            Double printableWidth = printSize.Width;
            Double printableHeight = printSize.Height;

            FixedDocument fixedDoc = new FixedDocument();
            var fxPages = new List<FixedPage>();
            var margin = printMargin;

            string now = DateTime.Now.ToString("dd/MMM/yyy");//.ToShortDateString();

            var pgs = dgs.Length.ToString();
            int x = 0;
            for (; x < dgs.Length; x++)
            {
                TextBlock dateText = ProcessPrint.NewTxtBlock;

                if (DateVisibility) dateText.Visibility = Visibility.Visible;
                else dateText.Visibility = Visibility.Hidden;

                dateText.Text = now;

                int pageNumber = x + 1;

                // add page number
                TextBlock PageNumberText = ProcessPrint.NewTxtBlock;
                if (PageNumberVisibility) PageNumberText.Visibility = Visibility.Visible;
                else PageNumberText.Visibility = Visibility.Hidden;

                PageNumberText.Text = "Page : " + pageNumber.ToString().PadLeft(pgs.Length, '0') + "/" + dgs.Length;
                PageNumberText.SetValue(TextElement.FontWeightProperty, FontWeights.Bold);


                FixedPage.SetTop(dateText, printableHeight - 25);
                FixedPage.SetLeft(dateText, Margin + margin.Left);

                FixedPage.SetTop(PageNumberText, printableHeight - 25);
                FixedPage.SetLeft(PageNumberText, Margin + (printableWidth - PageNumberText.Text.Length * 10) / 2);

                var size = new Size(printableWidth, printableHeight);

                var canv = Preview.GetVisualCanvas(dgs[x], size, new Thickness(0));

                var fixedPage = new FixedPage
                {
                    Background = Brushes.White,
                    Width = printableWidth,
                    Height = printableHeight,
                    Margin = new Thickness(0),

                };

                FixedPage.SetLeft(canv, Margin + margin.Left);
                FixedPage.SetTop(canv, margin.Top);

                fixedPage.Children.Add(canv);
                fixedPage.Children.Add(dateText);
                fixedPage.Children.Add(PageNumberText);


                PageContent pageContent = new PageContent();
                ((IAddChild)pageContent).AddChild(fixedPage);


                fixedDoc.Pages.Add(pageContent);



            }


            return fixedDoc;
        }


        public FixedPage[] GetFixPages(DataGrid[] dgs, Size printSize, Thickness printMargin)
        {
            if (dgs == null || dgs.Length < 1) return null;
            ////return null;
            //System.Windows.Input.Cursors.Wait;
            //System.Windows.Input.CursorType.Wait;
            Double printableWidth = printSize.Width;
            Double printableHeight = printSize.Height;

            //FixedDocument fixedDoc = new FixedDocument();
            var fxPages = new List<FixedPage>();
            var margin = printMargin;

            string now = DateTime.Now.ToString("dd/MMM/yyy");//.ToShortDateString();

            var pgs = dgs.Length.ToString();
            int x = 0;
            while (x < dgs.Length)
            {
                //var pt = ProcessPrint.PageTemplate2;
                TextBlock dateText = new TextBlock();// ProcessPrint.DateText;// pt.TextBlock;// ProcessPrint.PageTemplate.TextBlock;// new TextBlock();

                if (DateVisibility) dateText.Visibility = Visibility.Visible;
                else dateText.Visibility = Visibility.Hidden;

                dateText.Text = now;

                //List<DataGrid> dg = new List<DataGrid>();
                //int pageNumber = dataGridPages.IndexOf(dg) + 1;

                int pageNumber = x + 1;

                // add page number
                TextBlock PageNumberText = new TextBlock();// ProcessPrint.PageNumbText;//.PageTemplate.TextBlock;//ProcessPrint._textBlock;//  new TextBlock();
                if (PageNumberVisibility) PageNumberText.Visibility = Visibility.Visible;
                else PageNumberText.Visibility = Visibility.Hidden;

                PageNumberText.Text = "Page : " + pageNumber.ToString().PadLeft(pgs.Length, '0') + "/" + dgs.Length;
                PageNumberText.SetValue(TextElement.FontWeightProperty, FontWeights.Bold);


                FixedPage.SetTop(dateText, printableHeight - 25);
                FixedPage.SetLeft(dateText, Margin + margin.Left);

                FixedPage.SetTop(PageNumberText, printableHeight - 25);
                FixedPage.SetLeft(PageNumberText, Margin + (printableWidth - PageNumberText.Text.Length * 10) / 2);
                //var testIt = newDgPage.SelectedItem;


                //FixedPageFromCanvas(newDgPage, size, pageNumber, PageHeightWithMargin, PageHeightWithMargin);

                var size = new Size(printableWidth, printableHeight);

                var canv = Preview.GetVisualCanvas(dgs[x], size, new Thickness(0));

                var fixedPage = new FixedPage
                {
                    Background = Brushes.White,
                    Width = printableWidth,
                    Height = printableHeight,
                    Margin = new Thickness(0),

                };

                FixedPage.SetLeft(canv, Margin + margin.Left);
                FixedPage.SetTop(canv, margin.Top);

                fixedPage.Children.Add(canv);
                fixedPage.Children.Add(dateText);
                fixedPage.Children.Add(PageNumberText);


                //PageContent pageContent = new PageContent();
                //((IAddChild)pageContent).AddChild(fixedPage);


                //fixedDoc.Pages.Add(pageContent);
                fxPages.Add(fixedPage);
                x++;

            }


            return fxPages.ToArray();
        }

        public async Task<FixedDocument> GetFixDocAsync(IList dataGridPages, Size printSize, Thickness printMargin, bool previewMode)
        {

            Double printableWidth = printSize.Width;
            Double printableHeight = printSize.Height;

            FixedDocument fixedDoc = new FixedDocument();

            var margin = printMargin;

            string now = DateTime.Now.ToShortDateString();

            foreach (DataGrid dg in dataGridPages)
            {

                // add date
                TextBlock dateText = new TextBlock();
                if (DateVisibility) dateText.Visibility = Visibility.Visible;
                else dateText.Visibility = Visibility.Hidden;

                dateText.Text = now;

                //List<DataGrid> dg = new List<DataGrid>();
                int pageNumber = dataGridPages.IndexOf(dg) + 1;


                // add page number
                TextBlock PageNumberText = new TextBlock();
                if (PageNumberVisibility) PageNumberText.Visibility = Visibility.Visible;
                else PageNumberText.Visibility = Visibility.Hidden;

                PageNumberText.Text = "Page : " + pageNumber;

                FixedPage.SetTop(dateText, printableHeight - 25);
                FixedPage.SetLeft(dateText, Margin + margin.Left);

                FixedPage.SetTop(PageNumberText, printableHeight - 25);
                FixedPage.SetLeft(PageNumberText, Margin + (printableWidth - PageNumberText.Text.Length * 10) / 2);
                //var testIt = newDgPage.SelectedItem;


                //FixedPageFromCanvas(newDgPage, size, pageNumber, PageHeightWithMargin, PageHeightWithMargin);

                var size = new Size(printableWidth, printableHeight);

                var canv = Preview.GetVisualCanvas(dg, size, new Thickness(0));

                var fixedPage = new FixedPage
                {
                    Background = Brushes.White,
                    Width = printableWidth,
                    Height = printableHeight,
                    Margin = new Thickness(0),

                };

                //fixedPage.Children.Add(dateText);
                //fixedPage.Children.Add(PageNumberText);

                //fixedPage.Children.Add(newDgPage);
                FixedPage.SetLeft(canv, Margin + margin.Left);
                FixedPage.SetTop(canv, margin.Top);

                fixedPage.Children.Add(canv);
                fixedPage.Children.Add(dateText);
                fixedPage.Children.Add(PageNumberText);


                PageContent pageContent = new PageContent();
                ((IAddChild)pageContent).AddChild(fixedPage);


                fixedDoc.Pages.Add(pageContent);



            }
            if (previewMode)
                new Preview(fixedDoc.DocumentPaginator).ShowDialog();

            //await Task.Run(() => fixedDoc.GetType());

            return fixedDoc;
        }

        public DataGrid[] GetDataGridPages(Double printHeight, bool previewEachPage)
        {
        reprocess:

            List<LocalValueEntry[]> clonedColmsDps = ColumnsDpList;

            /*  MethodInfo mi2 = typeof(C).GetMethod("M2",
            BindingFlags.Public | BindingFlags.Static);*/

            /*MethodInfo mth = typeof(WpfPrinting).GetMethod("GetColumDepdPropts", new Type[] {dataGrid.GetType() });//.GetMethod("GetColumDepdPropts2", BindingFlags.Public | BindingFlags.Static);
            Delegate dlg = Delegate.CreateDelegate(typeof(D3), this, mth);
           var task = dataGrid.Dispatcher.Invoke(method: dlg, args: dataGrid);*/

            /* var task = await GetColumDepdPropts(dataGrid);
            while (task.Status == TaskStatus.WaitingForActivation)
            task.Wait(1);*/

            //ColDpList = clonedColmsDps;

            Double printableHeight = printHeight;

            List<DataGrid> dgPages = new List<DataGrid>();
            int position = 0, pageNumber = 0;
            for (; ; )
            {
                DataGrid newDgPage = new DataGrid();// GetClonedDg(gridCoy);

                //DnD Enrich new DataGrid page with cloned static columns data
                foreach (LocalValueEntry[] dps in ColumnsDpList)
                {
                    int rowIndex = ColumnsDpList.IndexOf(dps);
                    //DnD: Each new column is inititialize with ad DataGrid Text Column
                    newDgPage.Columns.Add(new DataGridTextColumn());

                    //LocalValueEntry[] dps = (LocalValueEntry[])ColDpList[k][1];

                    //DnD The actual  DataGridColumn Type and data is now applied 
                    //...from the cloned columns's dependency propts.
                    foreach (LocalValueEntry dp in dps)
                        newDgPage.Columns[rowIndex].SetValue(dp.Property, dp.Value);
                }

                double currentPgHeight = 0;

                ++pageNumber;

                while (currentPgHeight < printableHeight && position < this.DataGridRows.Length)
                {
                    DataGridRow row = this.DataGridRows[position++];

                    ///DnD Helps to resolve the irregular print margin,
                    ///observed, especially at the starting page(s)
                    row.UpdateLayout();
                    row.Margin = new Thickness(-5, 0, 0, 0);

                    newDgPage.Items.Add(row);

                    if (row.ActualHeight < 1)
                        continue;
                    currentPgHeight += row.ActualHeight;
                }

                newDgPage.Name = "Page_" + pageNumber.ToString().PadLeft(3, '0');
                dgPages.Add(newDgPage);

                ///DnD ToDo Previewed pages suffers exception except and have to
                ///be regenerated without previewing. Workaround needs to be created 
                if (previewEachPage)
                    Preview.PrintVisual(newDgPage);

                if (position < this.DataGridRows.Length)
                    ;
                else return dgPages.ToArray();
            }
        }

        //public DataGrid[] Duplicate(DataGrid dupSeeds)
        //{
        //    var count = dupSeeds.Items.Count;
        //    this.PreviewMod = PrintPreview.None;

        //    var modeHold = this.DupMode;
        //    this.DupMode = true;
        //    this.DupDgridRows = ReapDataGrid(ref dupSeeds);

        //    var dgs = GetDgPages(this.DupDgridRows[0].ActualHeight, 0);


        //    this.DupMode = modeHold;
        //    return dgs;// dgList.ToArray();
        //}

        //public DataGrid[] Duplicate(string[][] sourceArr)
        //{
        //    this.SourceList = sourceArr;
        //    var count = sourceArr.Length;// dupSeeds.l.Count;
        //    this.PreviewMod = PrintPreview.None;
        //    //this.DuplicateSeeds = dupSeeds;// (int)count;
        //    var modeHold = this.DupMode;
        //    this.DupMode = true;

        //    var dgs = GetDgPages(this.DataGridRows[0].ActualHeight, 0);

        //    this.DupMode = modeHold;
        //    return dgs;
        //}
        //static Style DgRowStyle0;
        //static Style DgRowStyle
        //{
        //    get
        //    {
        //        DgRowStyle0 = null;
        //        if (DgRowStyle0 == null)
        //        {
        //            DgRowStyle0 = PrintsDataGrid.GetDgRowStyle;
        //        }
        //        return DgRowStyle0;
        //    }
        //}
        static Style ColumnHdrStyle0;
        static Style ColumnHdrStyle
        {
            get
            {
                //ColumnHdrStyle0 = null;
                if (ColumnHdrStyle0 == null)
                {
                    /*//DnD Space to Enable either this->*/
                    ColumnHdrStyle0 = ViewsDataGrid.GetColumnHdrStyle;
                    /* DnD Or->* /
                    var style = new Style { TargetType = typeof(DataGridColumnHeader) };
                    style.Setters.Add(new Setter(DataGridColumnHeader.HeightProperty, 30.0));
                    //style.Setters.Add(new Setter(DataGridColumnHeader.WidthProperty, DataGridLength.Auto));
                    style.Setters.Add(new Setter(DataGridColumnHeader.PaddingProperty, new Thickness(1, 2, 1, 2)));
                    style.Setters.Add(new Setter(DataGridColumnHeader.BackgroundProperty, Brushes.Gray));
                    style.Setters.Add(new Setter(DataGridColumnHeader.ForegroundProperty, Brushes.White));
                    style.Setters.Add(new Setter(DataGridColumnHeader.FontSizeProperty, 14.0));///new FontSizeConverter().ConvertFrom(14)
                    style.Setters.Add(new Setter(DataGridColumnHeader.FontWeightProperty, FontWeights.Bold));
                    style.Setters.Add(new Setter(DataGridColumnHeader.BorderBrushProperty, Brushes.Black));
                    style.Setters.Add(new Setter(DataGridColumnHeader.BorderThicknessProperty, new Thickness(1, 2, 1, 2)));

                    //style.SetValue(style.FontSizeProperty, 10.0);
                    //style.Setters.Add(new Setter(DataGridColumnHeader.FontSizeProperty, 30.0));;

                    //< Setter Property = "DataGridColumnHeader.Height" Value = "30" />
                    //< !--< Setter Property = "DataGridColumnHeader.Width" Value = "Auto" /> -->
                    //< Setter Property = "DataGridColumnHeader.Padding" Value = "2,0" />
                    //< Setter Property = "DataGridColumnHeader.Background" Value = "Black" />
                    //< Setter Property = "DataGridColumnHeader.Foreground" Value = "White" />
                    //< Setter Property = "DataGridColumnHeader.FontSize" Value = "14" />
                    //< Setter Property = "DataGridColumnHeader.FontWeight"  Value = "Bold" />
                    //< Setter Property = "DataGridColumnHeader.BorderBrush" Value = "White" />
                    //< Setter Property = "DataGridColumnHeader.BorderThickness" Value = "1,2,1,2" />

                    ColumnHdrStyle0 = style;
                    //*/
                }
                return ColumnHdrStyle0;
            }
        }
        public DataGrid GetPageSizeList(Double printHeight)
        {
            Double printableHeight = printHeight;


            //string resxFile = "/CustomControls;component/Themes/resFrameStyleOfficeButton.xaml".Trim();


            //if (_customFrame != null)
            //{
            //    if (WindowState == WindowState.Normal)
            //    {
            //        //UpdateFrameAppearance(uri);


            //        ResourceDictionary currentResources = new ResourceDictionary();

            //        foreach (DictionaryEntry entry in Resources)
            //        {
            //            currentResources[entry.Key] = entry.Value;
            //        }

            //        Uri uri = new Uri(resxFile, UriKind.Relative);
            //        ResourceDictionary fromFile = Application.LoadComponent(uri) as ResourceDictionary;
            //        currentResources.MergedDictionaries.Add(fromFile);

            //        Resources = currentResources;

            //        // Make ASYNCHRONOUS call to method that can react to new style
            //        // (new settings are NOT detected when you call the method directly)
            //        new Thread(() => { UpdateFrameBehavior(); }).Start();
            //    }
            //DependencyProperty HeaderDP = ViewsDataGrid.ColumnHdrStyleProperty;
            ////HeaderDP.AddOwner(this.GetType());
            //Type typ = HeaderDP.OwnerType;
            //DataGridColumnHeader dgHeader = new DataGridColumnHeader();
            //dgHeader.Style = new Style(typeof(DataGridColumnHeader), PrintControl.ColumnHdrStyle2);

            List<DataGrid> dgPages = new List<DataGrid>();
            var fontSizes = new double[ColumnsDpList.Count];
            double val = 0;
            var maxWidths = new double[ColumnsDpList.Count];

            int position = 0, pageNumber = 0;
            //for (; ; )
            //{
            DataGrid newDgPage = new DataGrid();// GetClonedDg(gridCoy);

            //newDgPage.SetValue(DataGrid.ColumnHeaderStyleProperty, PrintControl.ColumnHdrStyleProperty);
            //DnD Enrich new DataGrid page with cloned static columns data
            foreach (LocalValueEntry[] dps in this.ColumnsDpList)
            {
                int idx = this.ColumnsDpList.IndexOf(dps);
                //DnD: Each new column is inititialize with ad DataGrid Text Column
                newDgPage.Columns.Add(new DataGridTextColumn());

                newDgPage.MaxColumnWidth = (double)int.MaxValue;

                //newDgPage.Columns[rowIndex].Header = dgHeader;
                //LocalValueEntry[] dps = (LocalValueEntry[])ColDpList[k][1];

                ///DnD The actual  DataGridColumn Type and data is now applied 
                ///from the cloned columns's dependency propts.
                foreach (LocalValueEntry dp in dps)
                    newDgPage.Columns[idx].SetValue(dp.Property, dp.Value);

                val = (Double)newDgPage.Columns[idx].GetValue(DataGridColumnHeader.FontSizeProperty);
                fontSizes[idx] = val;

                //val = (Double)newDgPage.Columns[idx].GetValue(DataGridColumnHeader.MaxWidthProperty);
                //maxWidths[idx] = val;

                //retTry:
                //try
                //{

                //}catch(Exception ex)
                //{
                //    goto retTry; 
                //}

                //newDgPage.SetValue(dps[0].Property, HeaderDP);
                //newDgPage.Columns[rowIndex].Header = PrintControl.ColumnHdrStyle2;
            }
            //newDgPage. = PrintControl.ColumnHdrStyle2;

            ///DnD ToDo: Source form original DataGrid view
            //fontSizes.Aggregate()

            ///DnD The HeaderCulumn fontsize is increased by 2.0
            if (true /*DnD To be implemented in GUI Settings*/ && ColumnHdrStyle0 == null)
            {
                newDgPage.ColumnHeaderStyle = ColumnHdrStyle;
                //newDgPage.ColumnHeaderStyle = ColumnHdrStyle.Setters.Remove(new Setter(DataGridColumnHeader.FontSizeProperty 14));

                double heightestValue = fontSizes.Aggregate(0.0, (longest, next) => next > longest ? next : longest);
                double lowestValue = fontSizes.Aggregate(heightestValue, (lowest, next) => next < lowest ? next : lowest);
                val = heightestValue == lowestValue ? heightestValue + 2.0 : 14;

                newDgPage.ColumnHeaderStyle.Setters.Add(new Setter(DataGridColumnHeader.FontSizeProperty, new FontSizeConverter().ConvertFrom(val)));



                //newDgPage.ColumnHeaderStyle.Setters.Add(new Setter(DataGridColumnHeader.MaxWidthProperty, 140.0));
            }
            else
                newDgPage.ColumnHeaderStyle = ColumnHdrStyle;

            int x = 0;
            //foreach (DataGridColumn cl in newDgPage.Columns)
            //{
            //    val = (Double)cl.GetValue(DataGridColumnHeader.MaxWidthProperty);
            //    maxWidths[x++] = val;
            //}

            var cellWidths = newDgPage.Columns.Select(w => w.Width.DesiredValue).ToArray();
            // Return the final result as an upper case string.
            //fruit => fruit.ToString().PadLeft(());



            //foreach(DataGridColumn dgCol in newDgPage.Columns)
            //    dgCo(DataGridColumnHeader.FontSizeProperty, new FontSizeConverter().ConvertFrom(14))
            //style.Setters.Add(new Setter(DataGridColumnHeader.FontSizeProperty, 14/*new FontSizeConverter().ConvertFrom(14)*/));

            //var cellWidths2 = newDgPage.Columns.Select(w => w.Width.DesiredValue).ToArray();
            //var cellWidths2a = newDgPage.Columns.Select(w => w.Width.DisplayValue).ToArray();
            //var cellWidths2b = newDgPage.Columns.Select(w => w.Width.Value).ToArray();
            double currentPgHeight = 0;

            ++pageNumber;

            DataGridRow row = null;
            //var rowHeaders = DataGridRows.Select(h => (DataGridRowHeader)h.Item);
            //var rowHeaders2 = DataGridRows.Select(h => (DataGridRowHeader)h.Header);
            //double largestRow = rowHeaders.Aggregate(0.0, (longest, next) => next > longest ? next : longest);
            //int lowestValue = rowHeaders.Aggregate(largestRow, (lowest, next) => next < lowest ? next : lowest);
            //val = largestRow == lowestValue ? largestRow  : 14;
            var pageList = new System.Collections.ObjectModel.ObservableCollection<PrintFormat>();
            int rowHder = 0;
            while (currentPgHeight < printableHeight && position < this.DataGridRows.Length)
            {
                row = this.DataGridRows[position++];
                if (row == null)
                    continue;
                row.UpdateLayout();///DnD Helps to resolve the irregular print margin,
                                   ///observed, especially at the starting page(s)

                row.Margin = new Thickness(-5, 0, 0, 0);

                if (true/*DnD To be implemented in GUI Settings*/ && rowHder != null)
                    row.Header = null;
                //var rowHeaders3 = DataGridRows.Select(h => h.HeaderTemplate);

                newDgPage.Items.Add(row);
                pageList.Add(row.Item as PrintFormat);
                if (row.ActualHeight < 1)
                    continue;
                currentPgHeight += row.ActualHeight;
            }

            newDgPage.Tag = new ListCollectionView(pageList);
            //newDgPage.Columns[2].Width.DesiredValue = 12.0;

            //var cellWidths = newDgPage.Columns.Select(w => w.Width).ToArray();
            //newDgPage.ColumnHeaderStyle = ColumnHdrStyle;

            //var cellWidths1a = newDgPage.Columns.Select(w => w.Width.DisplayValue).ToArray();
            //var cellWidths1b = newDgPage.Columns.Select(w => w.Width.Value).ToArray();
            //newDgPage.ColumnHeaderStyle = ColumnHdrStyle;

            //var colEnut = newDgPage.Columns.GetEnumerator();

            //for (int c = 0; c < newDgPage.Columns.Count; c++)
            //    newDgPage.Columns[c].Width = new DataGridLength(cellWidths[c], DataGridLengthUnitType.Pixel);

            ///DnD Contrain Colums' width to align with cell's  width
            //var cellWidths2 = newDgPage.Columns.Select(w => w.Width.DesiredValue).ToArray();
            foreach (DataGridColumn col in newDgPage.Columns)
            {
                //col.Width = cellWidths[newDgPage.Columns.IndexOf(col)];
                col.Width = new DataGridLength(cellWidths[newDgPage.Columns.IndexOf(col)], DataGridLengthUnitType.Pixel);
                //col.ActualWidth
            }
            //for (int c = 0; c < newDgPage.Columns.Count; c++)
            //    if (newDgPage.Columns[c].Width.DesiredValue < cellWidths[c])
            //        newDgPage.Columns[c].Width   =cellWidths[c];
            // new DataGridLength(.IndexOf(col)].ActualWidth, DataGridLengthUnitType.SizeToCells);


            //}

            /*///DnD Utilise the last row items's width to update each column header's width
            ///
            x=0;
            var enut = row.GetLocalValueEnumerator();
            var rowCells = new LocalValueEntry[enut.Count];
            while (enut.MoveNext())
                rowCells[x++] = enut.Current;
            //newDgPage.CellStyle.

            x = 0;
            foreach (var newRow in newDgPage.Columns)
            {
                if (rowCells[x] == null || rowCells[x].Property.ReadOnly)
                    continue;
                var val2 = row.GetValue(rowCells[x++].Property);
                //newRow.Width = new DataGridLength(row.[x].ActualWidth, DataGridLengthUnitType.SizeToCells);
            }
            */

            newDgPage.Name = "Page_" + pageNumber.ToString().PadLeft(3, '0');
            return newDgPage;
            //dgPages.Add(newDgPage);

            /////DnD ToDo Previewed pages suffers exception except and have to
            /////be regenerated without previewing. Workaround needs to be created 
            //if (this.PreviewMod == PrintPreview.EachPage)
            //    Preview.PrintVisual(newDgPage);

            //if (position < this.DataGridRows.Length)
            //{
            //    if (pageNumber == 1 && this.PreviewMod == PrintPreview.FirstPage)
            //        Preview.PrintVisual(newDgPage);

            //    ;
            //}
            //else
            //{
            //    if (this.PreviewMod == PrintPreview.LastPage)
            //        Preview.PrintVisual(newDgPage);
            //    return dgPages.ToArray();
            //}
            //}
        }

        //public PageMediaSize MediaSize { get; set; }
        public Size PageSize { get; set; }
        private double PageHeight { get; set; }
        public int RowsPerPage { get; set; }


        //private int RowsPerPage0;
        ////public int RowsPerPage { get => CalculatePageRows(this.DataGridRows[0]); }
        //////(double rowHeight)
        ////private int CalculatePageRows(DataGridRow row)
        //public int RowsPerPage
        //{
        //    //Cv.Hybrid = Cv.Items.Count() > 0 && !Cv.IsSizedToPage;
        //    //Cv.MediaSize = mediaSize;
        //    get
        //    {
        //        if (RowsPerPage0 == 0)
        //        {
        //            var rowHeight = this.DataGridRows[0].ActualHeight;
        //            var mediaSize = this.MediaSize;

        //            var paperSize = new Size(mediaSize.Width.Value, mediaSize.Height.Value);
        //            var printHeight = paperSize.Height - (40 + GuiStat.PrintMargin.Top + GuiStat.PrintMargin.Bottom);
        //            Double printableHeight = printHeight;// printSize.Height;
        //            double mod = printableHeight % rowHeight;

        //            int listSz = (int)((printableHeight - mod) / rowHeight);
        //            RowsPerPage0 = listSz;
        //        }
        //        return RowsPerPage0;
        //    }
        //}

        /// <summary>
        ///Utilizes two class propts,  ColumnsDpList & DataGridRows(for columns and rows, respectively),
        ///to reconstruct sub pages of the DataGrid that was used at the constructor to initialize this class.
        /// </summary>
        /// <param name="printHeight">The print height excluding margins, hearders and footers</param>
        /// <param name="previewEachPage">Yes to preview each page. ToDo Bug: previewding causes malfuction. Workaround needed</param>
        /// <returns></returns>
        public DataGrid[] GetDgPages(Double printHeight)
        {
            Double printableHeight = printHeight;


            //string resxFile = "/CustomControls;component/Themes/resFrameStyleOfficeButton.xaml".Trim();


            //if (_customFrame != null)
            //{
            //    if (WindowState == WindowState.Normal)
            //    {
            //        //UpdateFrameAppearance(uri);


            //        ResourceDictionary currentResources = new ResourceDictionary();

            //        foreach (DictionaryEntry entry in Resources)
            //        {
            //            currentResources[entry.Key] = entry.Value;
            //        }

            //        Uri uri = new Uri(resxFile, UriKind.Relative);
            //        ResourceDictionary fromFile = Application.LoadComponent(uri) as ResourceDictionary;
            //        currentResources.MergedDictionaries.Add(fromFile);

            //        Resources = currentResources;

            //        // Make ASYNCHRONOUS call to method that can react to new style
            //        // (new settings are NOT detected when you call the method directly)
            //        new Thread(() => { UpdateFrameBehavior(); }).Start();
            //    }
            //DependencyProperty HeaderDP = ViewsDataGrid.ColumnHdrStyleProperty;
            ////HeaderDP.AddOwner(this.GetType());
            //Type typ = HeaderDP.OwnerType;
            //DataGridColumnHeader dgHeader = new DataGridColumnHeader();
            //dgHeader.Style = new Style(typeof(DataGridColumnHeader), PrintControl.ColumnHdrStyle2);

            List<DataGrid> dgPages = new List<DataGrid>();
            var fontSizes = new double[ColumnsDpList.Count];
            double val = 0;
            var maxWidths = new double[ColumnsDpList.Count];

            int position = 0, pageNumber = 0;
            for (; ; )
            {
                DataGrid newDgPage = new DataGrid();// GetClonedDg(gridCoy);

                //newDgPage.SetValue(DataGrid.ColumnHeaderStyleProperty, PrintControl.ColumnHdrStyleProperty);
                //DnD Enrich new DataGrid page with cloned static columns data
                foreach (LocalValueEntry[] dps in this.ColumnsDpList)
                {
                    int idx = this.ColumnsDpList.IndexOf(dps);
                    //DnD: Each new column is inititialize with ad DataGrid Text Column
                    newDgPage.Columns.Add(new DataGridTextColumn());

                    newDgPage.MaxColumnWidth = (double)int.MaxValue;

                    //newDgPage.Columns[rowIndex].Header = dgHeader;
                    //LocalValueEntry[] dps = (LocalValueEntry[])ColDpList[k][1];

                    ///DnD The actual  DataGridColumn Type and data is now applied 
                    ///from the cloned columns's dependency propts.
                    foreach (LocalValueEntry dp in dps)
                        newDgPage.Columns[idx].SetValue(dp.Property, dp.Value);

                    val = (Double)newDgPage.Columns[idx].GetValue(DataGridColumnHeader.FontSizeProperty);
                    fontSizes[idx] = val;

                    //val = (Double)newDgPage.Columns[idx].GetValue(DataGridColumnHeader.MaxWidthProperty);
                    //maxWidths[idx] = val;

                    //retTry:
                    //try
                    //{

                    //}catch(Exception ex)
                    //{
                    //    goto retTry; 
                    //}

                    //newDgPage.SetValue(dps[0].Property, HeaderDP);
                    //newDgPage.Columns[rowIndex].Header = PrintControl.ColumnHdrStyle2;
                }
                //newDgPage. = PrintControl.ColumnHdrStyle2;

                ///DnD ToDo: Source form original DataGrid view
                //fontSizes.Aggregate()

                ///DnD The HeaderCulumn fontsize is increased by 2.0
                if (true /*DnD To be implemented in GUI Settings*/ && ColumnHdrStyle0 == null)
                {
                    newDgPage.ColumnHeaderStyle = ColumnHdrStyle;
                    //newDgPage.ColumnHeaderStyle = ColumnHdrStyle.Setters.Remove(new Setter(DataGridColumnHeader.FontSizeProperty 14));

                    double heightestValue = fontSizes.Aggregate(0.0, (longest, next) => next > longest ? next : longest);
                    double lowestValue = fontSizes.Aggregate(heightestValue, (lowest, next) => next < lowest ? next : lowest);
                    val = heightestValue == lowestValue ? heightestValue + 2.0 : 14;

                    newDgPage.ColumnHeaderStyle.Setters.Add(new Setter(DataGridColumnHeader.FontSizeProperty, new FontSizeConverter().ConvertFrom(val)));



                    //newDgPage.ColumnHeaderStyle.Setters.Add(new Setter(DataGridColumnHeader.MaxWidthProperty, 140.0));
                }
                else
                    newDgPage.ColumnHeaderStyle = ColumnHdrStyle;

                int x = 0;
                //foreach (DataGridColumn cl in newDgPage.Columns)
                //{
                //    val = (Double)cl.GetValue(DataGridColumnHeader.MaxWidthProperty);
                //    maxWidths[x++] = val;
                //}

                var cellWidths = newDgPage.Columns.Select(w => w.Width.DesiredValue).ToArray();
                // Return the final result as an upper case string.
                //fruit => fruit.ToString().PadLeft(());



                //foreach(DataGridColumn dgCol in newDgPage.Columns)
                //    dgCo(DataGridColumnHeader.FontSizeProperty, new FontSizeConverter().ConvertFrom(14))
                //style.Setters.Add(new Setter(DataGridColumnHeader.FontSizeProperty, 14/*new FontSizeConverter().ConvertFrom(14)*/));

                //var cellWidths2 = newDgPage.Columns.Select(w => w.Width.DesiredValue).ToArray();
                //var cellWidths2a = newDgPage.Columns.Select(w => w.Width.DisplayValue).ToArray();
                //var cellWidths2b = newDgPage.Columns.Select(w => w.Width.Value).ToArray();
                double currentPgHeight = 0;

                ++pageNumber;

                DataGridRow row = null;
                //var rowHeaders = DataGridRows.Select(h => (DataGridRowHeader)h.Item);
                //var rowHeaders2 = DataGridRows.Select(h => (DataGridRowHeader)h.Header);
                //double largestRow = rowHeaders.Aggregate(0.0, (longest, next) => next > longest ? next : longest);
                //int lowestValue = rowHeaders.Aggregate(largestRow, (lowest, next) => next < lowest ? next : lowest);
                //val = largestRow == lowestValue ? largestRow  : 14;
                var pageList = new System.Collections.ObjectModel.ObservableCollection<PrintFormat>();
                int rowHder = 0;
                while (currentPgHeight < printableHeight && position < this.DataGridRows.Length)
                {
                    row = this.DataGridRows[position++];
                    if (row == null)
                        continue;
                    row.UpdateLayout();///DnD Helps to resolve the irregular print margin,
                                       ///observed, especially at the starting page(s)

                    row.Margin = new Thickness(-5, 0, 0, 0);

                    if (true/*DnD To be implemented in GUI Settings*/ && rowHder != null)
                        row.Header = null;
                    //var rowHeaders3 = DataGridRows.Select(h => h.HeaderTemplate);

                    newDgPage.Items.Add(row);
                    pageList.Add(row.Item as PrintFormat);
                    if (row.ActualHeight < 1)
                        continue;
                    currentPgHeight += row.ActualHeight;
                }
                newDgPage.Tag = new ListCollectionView(pageList);
                //newDgPage.Columns[2].Width.DesiredValue = 12.0;

                //var cellWidths = newDgPage.Columns.Select(w => w.Width).ToArray();
                //newDgPage.ColumnHeaderStyle = ColumnHdrStyle;

                //var cellWidths1a = newDgPage.Columns.Select(w => w.Width.DisplayValue).ToArray();
                //var cellWidths1b = newDgPage.Columns.Select(w => w.Width.Value).ToArray();
                //newDgPage.ColumnHeaderStyle = ColumnHdrStyle;

                //var colEnut = newDgPage.Columns.GetEnumerator();

                //for (int c = 0; c < newDgPage.Columns.Count; c++)
                //    newDgPage.Columns[c].Width = new DataGridLength(cellWidths[c], DataGridLengthUnitType.Pixel);

                ///DnD Contrain Colums' width to align with cell's  width
                //var cellWidths2 = newDgPage.Columns.Select(w => w.Width.DesiredValue).ToArray();
                foreach (DataGridColumn col in newDgPage.Columns)
                {
                    //col.Width = cellWidths[newDgPage.Columns.IndexOf(col)];
                    col.Width = new DataGridLength(cellWidths[newDgPage.Columns.IndexOf(col)], DataGridLengthUnitType.Pixel);
                    //col.ActualWidth
                }
                //for (int c = 0; c < newDgPage.Columns.Count; c++)
                //    if (newDgPage.Columns[c].Width.DesiredValue < cellWidths[c])
                //        newDgPage.Columns[c].Width   =cellWidths[c];
                // new DataGridLength(.IndexOf(col)].ActualWidth, DataGridLengthUnitType.SizeToCells);


                //}

                /*///DnD Utilise the last row items's width to update each column header's width
                ///
                x=0;
                var enut = row.GetLocalValueEnumerator();
                var rowCells = new LocalValueEntry[enut.Count];
                while (enut.MoveNext())
                    rowCells[x++] = enut.Current;
                //newDgPage.CellStyle.

                x = 0;
                foreach (var newRow in newDgPage.Columns)
                {
                    if (rowCells[x] == null || rowCells[x].Property.ReadOnly)
                        continue;
                    var val2 = row.GetValue(rowCells[x++].Property);
                    //newRow.Width = new DataGridLength(row.[x].ActualWidth, DataGridLengthUnitType.SizeToCells);
                }
                */

                newDgPage.Name = "Page_" + pageNumber.ToString().PadLeft(3, '0');
                dgPages.Add(newDgPage);

                ///DnD ToDo Previewed pages suffers exception except and have to
                ///be regenerated without previewing. Workaround needs to be created 
                if (this.PreviewMod == PrintPreview.EachPage)
                    Preview.PrintVisual(newDgPage);

                if (position < this.DataGridRows.Length)
                {
                    if (pageNumber == 1 && this.PreviewMod == PrintPreview.FirstPage)
                        Preview.PrintVisual(newDgPage);

                    ;
                }
                else
                {
                    if (this.PreviewMod == PrintPreview.LastPage)
                        Preview.PrintVisual(newDgPage);
                    return dgPages.ToArray();
                }
            }
        }

        public DataGrid[] GetDgPages(Double printHeight, int count)
        {
            Double printableHeight = printHeight;
            //DependencyProperty HeaderDP = ViewsDataGrid.ColumnHdrStyleProperty;

            List<DataGrid> dgPages = new List<DataGrid>();
            var fontSizes = new double[ColumnsDpList.Count];
            double val = 0;
            var maxWidths = new double[ColumnsDpList.Count];

            var reapedDgRows =/* this.DupMode ? this.DupDgridRows : */this.DataGridRows;

            //if (reapedDgRows == null || reapedDgRows.Length < 1 && this.DataGridRows.Length > 1)
            //    reapedDgRows = this.DataGridRows;

            //== null || sourcedRows.Length == 0 ? this.DataGridRows : sourcedRows;
            int dupCount = 0;

            int position = 0, pageNumber = 0;
            for (; ; )
            {
                DataGrid newDgPage = new DataGrid();
                //newDgPage.ItemsSource = new ListCollectionView(new ObservableCollection<PrintFormat>());// ( SourceList[dupCount];
                //DnD Enrich new DataGrid page with cloned static columns data
                foreach (LocalValueEntry[] dps in this.ColumnsDpList)
                {
                    int idx = this.ColumnsDpList.IndexOf(dps);
                    //DnD: Each new column is inititialize with ad DataGrid Text Column
                    newDgPage.Columns.Add(new DataGridTextColumn());

                    newDgPage.MaxColumnWidth = (double)int.MaxValue;

                    foreach (LocalValueEntry dp in dps)
                        newDgPage.Columns[idx].SetValue(dp.Property, dp.Value);

                    val = (Double)newDgPage.Columns[idx].GetValue(DataGridColumnHeader.FontSizeProperty);
                    fontSizes[idx] = val;

                }

                if (true /*DnD To be implemented in GUI Settings*/ && ColumnHdrStyle0 == null)
                {
                    newDgPage.ColumnHeaderStyle = ColumnHdrStyle;

                    double heightestValue = fontSizes.Aggregate(0.0, (longest, next) => next > longest ? next : longest);
                    double lowestValue = fontSizes.Aggregate(heightestValue, (lowest, next) => next < lowest ? next : lowest);
                    val = heightestValue == lowestValue ? heightestValue + 2.0 : 14;

                    newDgPage.ColumnHeaderStyle.Setters.Add(new Setter(DataGridColumnHeader.FontSizeProperty, new FontSizeConverter().ConvertFrom(val)));

                }
                else
                    newDgPage.ColumnHeaderStyle = ColumnHdrStyle;

                //int x = 0;

                var cellWidths = newDgPage.Columns.Select(w => w.Width.DesiredValue).ToArray();

                double currentPgHeight = 0;

                ++pageNumber;

                DataGridRow row = null;

                var pageList = new System.Collections.ObjectModel.ObservableCollection<PrintFormat>();
                int rowHder = 0;

                //if (DupMode)
                //    newDgPage.ItemsSource = new ListCollectionView(pageList);// (ObservableCollection<PrintFormat>)
                //        //((ListCollectionView)newDgPage.ItemsSource).SourceCollection;
                //else
                //if (!DupMode)
                while (currentPgHeight < printableHeight && position < reapedDgRows.Length)
                {
                    row = reapedDgRows[position++];
                    if (row == null)
                        continue;

                    ///DnD calling row UpdateLayout() calling Helps to resolve the irregular print margin,
                    ///observed, especially at the starting page(s)
                    row.UpdateLayout();

                    row.Margin = new Thickness(-5, 0, 0, 0);

                    if (true/*DnD To be implemented in GUI Settings*/ && rowHder != null)
                        row.Header = null;

                    newDgPage.Items.Add(row);

                    pageList.Add(row.Item as PrintFormat);
                    if (row.ActualHeight < 1)
                        continue;
                    currentPgHeight += row.ActualHeight;

                    //if (DupMode)
                    //    break;
                }
                newDgPage.Tag = new ListCollectionView(pageList);

                foreach (DataGridColumn col in newDgPage.Columns)
                {
                    col.Width = new DataGridLength(cellWidths[newDgPage.Columns.IndexOf(col)], DataGridLengthUnitType.Pixel);
                }

                newDgPage.Name = "Page_" + pageNumber.ToString().PadLeft(3, '0');
                dgPages.Add(newDgPage);

                ///DnD ToDo Previewed pages suffers exception except when
                ///regenerated without previewing. Workaround needs to be created 
                if (this.PreviewMod == PrintPreview.EachPage)
                    Preview.PrintVisual(newDgPage);

                //if (DupMode && dupCount < this.SourceList.Length )
                //{
                //    //    var obs = (System.Collections.ObjectModel.ObservableCollection<PrintFormat>)row.Item;
                //    //    newDgPage.ItemsSource = new ListCollectionView(obs);

                //    //foreach (var sr in SourceList[dupCount++])
                //    ////pageList.Add((PrintFormat)sr);
                //    //{
                //        var pattnStrArr = PrintFormat.GetPatterns(SourceList[dupCount++], out PrintFormat[] pttnArr);
                //        newDgPage.ItemsSource = pattnStrArr;
                //    //}

                //    //newDgPage.ItemsSource = new ListCollectionView(pageList);

                //    newDgPage.UpdateLayout();

                //    if (SourceList.Length == dupCount)
                //        return dgPages.ToArray();

                //    continue;
                //    //DataGridRow dgr = ReapDataGrid(ref newDgPage)[0];
                //    //reapedDgRows.Add(dgr);

                //}
                //else
                if (position < reapedDgRows.Length)
                {
                    if (pageNumber == 1 && this.PreviewMod == PrintPreview.FirstPage)
                        Preview.PrintVisual(newDgPage);
                }
                else
                {
                    if (this.PreviewMod == PrintPreview.LastPage)
                        Preview.PrintVisual(newDgPage);

                    return dgPages.ToArray();
                }
            }
        }

        /// <summary>
        ///Utilizes two class propts,  ColumnsDpList & DataGridRows(for columns and rows, respectively),
        ///to reconstruct sub pages of the DataGrid that was used at the constructor to initialize this class.
        /// </summary>
        /// <param name="printHeight">The print height excluding margins, hearders and footers</param>
        /// <param name="previewEachPage">Yes to preview each page. ToDo Bug: previewding causes malfuction. Workaround needed</param>
        /// <returns></returns>
        public DataGrid[] GetDgPages2(Double printHeight, ref TabControlMgr tabControllMgr)
        {
            Double printableHeight = printHeight;


            //string resxFile = "/CustomControls;component/Themes/resFrameStyleOfficeButton.xaml".Trim();


            //if (_customFrame != null)
            //{
            //    if (WindowState == WindowState.Normal)
            //    {
            //        //UpdateFrameAppearance(uri);


            //        ResourceDictionary currentResources = new ResourceDictionary();

            //        foreach (DictionaryEntry entry in Resources)
            //        {
            //            currentResources[entry.Key] = entry.Value;
            //        }

            //        Uri uri = new Uri(resxFile, UriKind.Relative);
            //        ResourceDictionary fromFile = Application.LoadComponent(uri) as ResourceDictionary;
            //        currentResources.MergedDictionaries.Add(fromFile);

            //        Resources = currentResources;

            //        // Make ASYNCHRONOUS call to method that can react to new style
            //        // (new settings are NOT detected when you call the method directly)
            //        new Thread(() => { UpdateFrameBehavior(); }).Start();
            //    }
            //DependencyProperty HeaderDP = ViewsDataGrid.ColumnHdrStyleProperty;
            ////HeaderDP.AddOwner(this.GetType());
            //Type typ = HeaderDP.OwnerType;
            //DataGridColumnHeader dgHeader = new DataGridColumnHeader();
            //dgHeader.Style = new Style(typeof(DataGridColumnHeader), PrintControl.ColumnHdrStyle2);

            List<DataGrid> dgPages = new List<DataGrid>();
            var fontSizes = new double[ColumnsDpList.Count];
            double val = 0;
            var maxWidths = new double[ColumnsDpList.Count];

            int position = 0, pageNumber = 0;
            for (; ; )
            {
                DataGrid newDgPage = new DataGrid();
                //newDgPage.EnableColumnVirtualization = false;
                //newDgPage.EnableRowVirtualization = false;

                var tabItem = tabControllMgr.GeTab();
                ScrollViewer scrVw = (ScrollViewer)tabItem.Content;
                scrVw.SetValue(ScrollViewer.ContentProperty, newDgPage);

                //newDgPage.SetValue(DataGrid.ColumnHeaderStyleProperty, PrintControl.ColumnHdrStyleProperty);
                //DnD Enrich new DataGrid page with cloned static columns data
                foreach (LocalValueEntry[] dps in this.ColumnsDpList)
                {
                    int idx = this.ColumnsDpList.IndexOf(dps);
                    //DnD: Each new column is inititialize with ad DataGrid Text Column
                    newDgPage.Columns.Add(new DataGridTextColumn());

                    newDgPage.MaxColumnWidth = (double)int.MaxValue;

                    //newDgPage.Columns[rowIndex].Header = dgHeader;
                    //LocalValueEntry[] dps = (LocalValueEntry[])ColDpList[k][1];

                    ///DnD The actual  DataGridColumn Type and data is now applied 
                    ///from the cloned columns's dependency propts.
                    foreach (LocalValueEntry dp in dps)
                        newDgPage.Columns[idx].SetValue(dp.Property, dp.Value);

                    val = (Double)newDgPage.Columns[idx].GetValue(DataGridColumnHeader.FontSizeProperty);
                    fontSizes[idx] = val;

                    //val = (Double)newDgPage.Columns[idx].GetValue(DataGridColumnHeader.MaxWidthProperty);
                    //maxWidths[idx] = val;

                    //retTry:
                    //try
                    //{

                    //}catch(Exception ex)
                    //{
                    //    goto retTry; 
                    //}

                    //newDgPage.SetValue(dps[0].Property, HeaderDP);
                    //newDgPage.Columns[rowIndex].Header = PrintControl.ColumnHdrStyle2;
                }
                //newDgPage. = PrintControl.ColumnHdrStyle2;

                ///DnD ToDo: Source form original DataGrid view
                //fontSizes.Aggregate()

                ///DnD The HeaderCulumn fontsize is increased by 2.0
                if (true /*DnD To be implemented in GUI Settings*/ && ColumnHdrStyle0 == null)
                {
                    newDgPage.ColumnHeaderStyle = ColumnHdrStyle;
                    //newDgPage.ColumnHeaderStyle = ColumnHdrStyle.Setters.Remove(new Setter(DataGridColumnHeader.FontSizeProperty 14));

                    double heightestValue = fontSizes.Aggregate(0.0, (longest, next) => next > longest ? next : longest);
                    double lowestValue = fontSizes.Aggregate(heightestValue, (lowest, next) => next < lowest ? next : lowest);
                    val = heightestValue == lowestValue ? heightestValue + 2.0 : 14;

                    newDgPage.ColumnHeaderStyle.Setters.Add(new Setter(DataGridColumnHeader.FontSizeProperty, new FontSizeConverter().ConvertFrom(val)));



                    //newDgPage.ColumnHeaderStyle.Setters.Add(new Setter(DataGridColumnHeader.MaxWidthProperty, 140.0));
                }
                else
                    newDgPage.ColumnHeaderStyle = ColumnHdrStyle;

                int x = 0;
                //foreach (DataGridColumn cl in newDgPage.Columns)
                //{
                //    val = (Double)cl.GetValue(DataGridColumnHeader.MaxWidthProperty);
                //    maxWidths[x++] = val;
                //}

                var cellWidths = newDgPage.Columns.Select(w => w.Width.DesiredValue).ToArray();
                // Return the final result as an upper case string.
                //fruit => fruit.ToString().PadLeft(());



                //foreach(DataGridColumn dgCol in newDgPage.Columns)
                //    dgCo(DataGridColumnHeader.FontSizeProperty, new FontSizeConverter().ConvertFrom(14))
                //style.Setters.Add(new Setter(DataGridColumnHeader.FontSizeProperty, 14/*new FontSizeConverter().ConvertFrom(14)*/));

                //var cellWidths2 = newDgPage.Columns.Select(w => w.Width.DesiredValue).ToArray();
                //var cellWidths2a = newDgPage.Columns.Select(w => w.Width.DisplayValue).ToArray();
                //var cellWidths2b = newDgPage.Columns.Select(w => w.Width.Value).ToArray();
                double currentPgHeight = 0;

                ++pageNumber;

                DataGridRow row = null;
                //var rowHeaders = DataGridRows.Select(h => (DataGridRowHeader)h.Item);
                //var rowHeaders2 = DataGridRows.Select(h => (DataGridRowHeader)h.Header);
                //double largestRow = rowHeaders.Aggregate(0.0, (longest, next) => next > longest ? next : longest);
                //int lowestValue = rowHeaders.Aggregate(largestRow, (lowest, next) => next < lowest ? next : lowest);
                //val = largestRow == lowestValue ? largestRow  : 14;

                int rowHder = 0;
                while (currentPgHeight < printableHeight && position < this.DataGridRows.Length)
                {
                    row = this.DataGridRows[position++];
                    if (row == null)
                        continue;
                    row.UpdateLayout();///DnD Helps to resolve the irregular print margin,
                                       ///observed, especially at the starting page(s)

                    row.Margin = new Thickness(-5, 0, 0, 0);

                    if (true/*DnD To be implemented in GUI Settings*/ && rowHder != null)
                        row.Header = null;
                    //var rowHeaders3 = DataGridRows.Select(h => h.HeaderTemplate);

                    newDgPage.Items.Add(row);

                    if (row.ActualHeight < 1)
                        continue;
                    currentPgHeight += row.ActualHeight;
                }
                //newDgPage.Columns[2].Width.DesiredValue = 12.0;

                //var cellWidths = newDgPage.Columns.Select(w => w.Width).ToArray();
                //newDgPage.ColumnHeaderStyle = ColumnHdrStyle;

                //var cellWidths1a = newDgPage.Columns.Select(w => w.Width.DisplayValue).ToArray();
                //var cellWidths1b = newDgPage.Columns.Select(w => w.Width.Value).ToArray();
                //newDgPage.ColumnHeaderStyle = ColumnHdrStyle;

                //var colEnut = newDgPage.Columns.GetEnumerator();

                //for (int c = 0; c < newDgPage.Columns.Count; c++)
                //    newDgPage.Columns[c].Width = new DataGridLength(cellWidths[c], DataGridLengthUnitType.Pixel);

                ///DnD Contrain Colums' width to align with cell's  width
                //var cellWidths2 = newDgPage.Columns.Select(w => w.Width.DesiredValue).ToArray();
                foreach (DataGridColumn col in newDgPage.Columns)
                {
                    //col.Width = cellWidths[newDgPage.Columns.IndexOf(col)];
                    col.Width = new DataGridLength(cellWidths[newDgPage.Columns.IndexOf(col)], DataGridLengthUnitType.Pixel);
                    //col.ActualWidth
                }
                //for (int c = 0; c < newDgPage.Columns.Count; c++)
                //    if (newDgPage.Columns[c].Width.DesiredValue < cellWidths[c])
                //        newDgPage.Columns[c].Width   =cellWidths[c];
                // new DataGridLength(.IndexOf(col)].ActualWidth, DataGridLengthUnitType.SizeToCells);


                //}

                /*///DnD Utilise the last row items's width to update each column header's width
                ///
                x=0;
                var enut = row.GetLocalValueEnumerator();
                var rowCells = new LocalValueEntry[enut.Count];
                while (enut.MoveNext())
                    rowCells[x++] = enut.Current;
                //newDgPage.CellStyle.

                x = 0;
                foreach (var newRow in newDgPage.Columns)
                {
                    if (rowCells[x] == null || rowCells[x].Property.ReadOnly)
                        continue;
                    var val2 = row.GetValue(rowCells[x++].Property);
                    //newRow.Width = new DataGridLength(row.[x].ActualWidth, DataGridLengthUnitType.SizeToCells);
                }
                */

                newDgPage.Name = "Page_" + pageNumber.ToString().PadLeft(3, '0');
                dgPages.Add(newDgPage);

                ///DnD ToDo Previewed pages suffers exception except and have to
                ///be regenerated without previewing. Workaround needs to be created 
                if (this.PreviewMod == PrintPreview.EachPage)
                    Preview.PrintVisual(newDgPage);

                if (position < this.DataGridRows.Length)
                {
                    if (pageNumber == 1 && this.PreviewMod == PrintPreview.FirstPage)
                        Preview.PrintVisual(newDgPage);

                    ;
                }
                else
                {
                    if (this.PreviewMod == PrintPreview.LastPage)
                        Preview.PrintVisual(newDgPage);
                    return dgPages.ToArray();
                }
            }
        }

        public Canvas[] GetCanvasArr(ICollectionView[] sourceItems, Double printHeight)
        {
            Double printableHeight = printHeight;

            //List<ScrollViewer> dgPages = new List<ScrollViewer>();
            var canvs = new List<Canvas>(sourceItems.Length);
            var fontSizes = new double[ColumnsDpList.Count];
            //double val = 0;
            var maxWidths = new double[ColumnsDpList.Count];

            DataGridRow rowSample = this.DataGridRows[0];
            //ViewsDataGrid vdg = null;
            DataGrid newDgPage = null;
            int pageNumber = 0;
            for (; sourceItems.Length > pageNumber; pageNumber++)
            {

                var vdg = ProcessPrint._viewsDataGrid; //new ViewsDataGrid();//
                                                       //vdg.SetValue(HeiPro = printableHeight;
                newDgPage = vdg.DgViews;// new DataGrid();//
                //newDgPage.SetValue(DataGrid.HeightProperty, printHeight);
                //newDgPage.SetValue(DataGrid.BackgroundProperty, new BrushConverter().);
                //newDgPage.AutoGeneratingColumn += NewDgPage_AutoGeneratingColumn;
                //newDgPage.Height = printHeight;
                var cellWidths = newDgPage.Columns.Select(w => w.Width.DesiredValue).ToArray();
                //var viewer = new ScrollViewer();
                //dgPages.Add(viewer);
                //viewer.Content = newDgPage; 
                newDgPage.ColumnHeaderStyle = ViewsDataGrid.GetColumnHdrStyle;
                newDgPage.ItemsSource = sourceItems[pageNumber];
                newDgPage.UpdateLayout();
                newDgPage.ScrollIntoView(newDgPage.Items[newDgPage.Items.Count - 1]);
                //newDgPage.UpdateLayout();

                var parrent = (DependencyObject)newDgPage.Parent;
                ((ContentControl)parrent).Content = null;
                vdg = null;

                var cv = Preview.GetVisualCanvas(newDgPage, this.PageSize, GuiStat.PrintMargin);

                canvs.Add(cv);
            }

            var arr = canvs.ToArray();
            canvs = null;
            return arr;
        }

        public DataGrid[] GetDgPages2(ICollectionView[] sourceItems, Size sz)
        {
            //Double printableHeight = sz;

            //List<ScrollViewer> dgPages = new List<ScrollViewer>();
            var dgs = new List<DataGrid>(sourceItems.Length);
            var fontSizes = new double[ColumnsDpList.Count];
            //double val = 0;
            var maxWidths = new double[ColumnsDpList.Count];

            DataGridRow rowSample = this.DataGridRows[0];

            int pageNumber = 0;
            for (; sourceItems.Length > pageNumber; pageNumber++)
            {

                try
                {
                    var vdg = ProcessPrint._viewsDataGrid; //new ViewsDataGrid();//
                    //vdg.SetValue(HeiPro = printableHeight;
                    DataGrid newDgPage = vdg.DgViews;//new DataGrid();//ViewsDataGrid.DgViews2;// 
                                                     //newDgPage.SetValue(DataGrid.HeightProperty, printHeight);
                                                     //newDgPage.SetValue(DataGrid.BackgroundProperty, new BrushConverter().);
                                                     //newDgPage.AutoGeneratingColumn += NewDgPage_AutoGeneratingColumn;
                                                     //newDgPage.Height = printHeight;
                                                     //var cellWidths = newDgPage.Columns.Select(w => w.Width.DesiredValue).ToArray();
                                                     //var viewer = new ScrollViewer();
                                                     //dgPages.Add(viewer);
                                                     //viewer.Content = newDgPage; 
                                                     //newDgPage.ColumnHeaderStyle = ViewsDataGrid.GetColumnHdrStyle;
                    newDgPage.SetValue(DataGrid.ItemsSourceProperty, sourceItems[pageNumber]);
                    newDgPage.InvalidateVisual();
                    newDgPage.SetValue(DataGrid.HeightProperty, sz.Height);
                    newDgPage.SetValue(DataGrid.WidthProperty, sz.Width);
                    //newDgPage.UpdateLayout();
                    //newDgPage.ScrollIntoView(newDgPage.Items[newDgPage.Items.Count - 1]);
                    //newDgPage.UpdateLayout();
                    //vdg.ItemSource = sourceItems[pageNumber];

                    ////((Grid)vdg.Content).Children.Clear();
                    //var parrent = (DependencyObject)newDgPage.Parent;
                    //((ContentControl)parrent).Content = null;

                    dgs.Add(newDgPage);
                    //vdg = null;
                }
                catch (Exception ex)
                {

                    throw;
                }
            }
            var arr = dgs.ToArray();
            dgs.Clear();
            return arr;
        }


        public DataGrid[] GetDgPages(ICollectionView[] sourceItems, Double printHeight)
        {
            Double printableHeight = printHeight;

            //List<ScrollViewer> dgPages = new List<ScrollViewer>();
            var dgs = new List<DataGrid>(sourceItems.Length);
            var fontSizes = new double[ColumnsDpList.Count];
            //double val = 0;
            var maxWidths = new double[ColumnsDpList.Count];

            DataGridRow rowSample = this.DataGridRows[0];

            int pageNumber = 0;
            for (; sourceItems.Length > pageNumber; pageNumber++)
            {

                var vdg = ProcessPrint._viewsDataGrid; //new ViewsDataGrid();//
                //vdg.SetValue(HeiPro = printableHeight;
                DataGrid newDgPage = vdg.DgViews;// new DataGrid();//
                //newDgPage.SetValue(DataGrid.HeightProperty, printHeight);
                //newDgPage.SetValue(DataGrid.BackgroundProperty, new BrushConverter().);
                //newDgPage.AutoGeneratingColumn += NewDgPage_AutoGeneratingColumn;
                //newDgPage.Height = printHeight;
                var cellWidths = newDgPage.Columns.Select(w => w.Width.DesiredValue).ToArray();
                //var viewer = new ScrollViewer();
                //dgPages.Add(viewer);
                //viewer.Content = newDgPage; 
                newDgPage.ItemsSource = sourceItems[pageNumber];
                newDgPage.UpdateLayout();
                newDgPage.ScrollIntoView(newDgPage.Items[newDgPage.Items.Count - 1]);
                //newDgPage.UpdateLayout();
                //vdg.ItemSource = sourceItems[pageNumber];

                ////((Grid)vdg.Content).Children.Clear();
                //var parrent = (DependencyObject)newDgPage.Parent;
                //((ContentControl)parrent).Content = null;

                dgs.Add(newDgPage);
                vdg = null;
            }
            return dgs.ToArray();
        }

        private void NewDgPage_AutoGeneratingColumn(object sender, DataGridAutoGeneratingColumnEventArgs e)
        {
            //throw new NotImplementedException();
        }

        /// <summary>
        ///Utilizes two class propts,  ColumnsDpList & DataGridRows(for columns and rows, respectively),
        ///to reconstruct sub pages of the DataGrid that was used at the constructor to initialize this class.
        /// </summary>
        /// <param name="printHeight">The print height excluding margins, hearders and footers</param>
        /// <param name="previewEachPage">Yes to preview each page. ToDo Bug: previewding causes malfuction. Workaround needed</param>
        /// <returns></returns>
        public ScrollViewer[] GetDgPages3(Double printHeight)
        {
            Double printableHeight = printHeight;


            //string resxFile = "/CustomControls;component/Themes/resFrameStyleOfficeButton.xaml".Trim();


            //if (_customFrame != null)
            //{
            //    if (WindowState == WindowState.Normal)
            //    {
            //        //UpdateFrameAppearance(uri);


            //        ResourceDictionary currentResources = new ResourceDictionary();

            //        foreach (DictionaryEntry entry in Resources)
            //        {
            //            currentResources[entry.Key] = entry.Value;
            //        }

            //        Uri uri = new Uri(resxFile, UriKind.Relative);
            //        ResourceDictionary fromFile = Application.LoadComponent(uri) as ResourceDictionary;
            //        currentResources.MergedDictionaries.Add(fromFile);

            //        Resources = currentResources;

            //        // Make ASYNCHRONOUS call to method that can react to new style
            //        // (new settings are NOT detected when you call the method directly)
            //        new Thread(() => { UpdateFrameBehavior(); }).Start();
            //    }
            //DependencyProperty HeaderDP = ViewsDataGrid.ColumnHdrStyleProperty;
            ////HeaderDP.AddOwner(this.GetType());
            //Type typ = HeaderDP.OwnerType;
            //DataGridColumnHeader dgHeader = new DataGridColumnHeader();
            //dgHeader.Style = new Style(typeof(DataGridColumnHeader), PrintControl.ColumnHdrStyle2);

            List<ScrollViewer> dgPages = new List<ScrollViewer>();
            var fontSizes = new double[ColumnsDpList.Count];
            double val = 0;
            var maxWidths = new double[ColumnsDpList.Count];

            int position = 0, pageNumber = 0;
            for (; ; )
            {
                DataGrid newDgPage = new DataGrid();
                //newDgPage.EnableColumnVirtualization = false;
                //newDgPage.EnableRowVirtualization = false;

                //var tabItem = tabControllMgr.GeTab();
                var scrVw = new ScrollViewer();// (ScrollViewer)tabItem.Content;
                scrVw.SetValue(ScrollViewer.ContentProperty, newDgPage);

                //newDgPage.SetValue(DataGrid.ColumnHeaderStyleProperty, PrintControl.ColumnHdrStyleProperty);
                //DnD Enrich new DataGrid page with cloned static columns data
                foreach (LocalValueEntry[] dps in this.ColumnsDpList)
                {
                    int idx = this.ColumnsDpList.IndexOf(dps);
                    //DnD: Each new column is inititialize with ad DataGrid Text Column
                    newDgPage.Columns.Add(new DataGridTextColumn());

                    newDgPage.MaxColumnWidth = (double)int.MaxValue;

                    //newDgPage.Columns[rowIndex].Header = dgHeader;
                    //LocalValueEntry[] dps = (LocalValueEntry[])ColDpList[k][1];

                    ///DnD The actual  DataGridColumn Type and data is now applied 
                    ///from the cloned columns's dependency propts.
                    foreach (LocalValueEntry dp in dps)
                        newDgPage.Columns[idx].SetValue(dp.Property, dp.Value);

                    val = (Double)newDgPage.Columns[idx].GetValue(DataGridColumnHeader.FontSizeProperty);
                    fontSizes[idx] = val;

                    //val = (Double)newDgPage.Columns[idx].GetValue(DataGridColumnHeader.MaxWidthProperty);
                    //maxWidths[idx] = val;

                    //retTry:
                    //try
                    //{

                    //}catch(Exception ex)
                    //{
                    //    goto retTry; 
                    //}

                    //newDgPage.SetValue(dps[0].Property, HeaderDP);
                    //newDgPage.Columns[rowIndex].Header = PrintControl.ColumnHdrStyle2;
                }
                //newDgPage. = PrintControl.ColumnHdrStyle2;

                ///DnD ToDo: Source form original DataGrid view
                //fontSizes.Aggregate()

                ///DnD The HeaderCulumn fontsize is increased by 2.0
                if (true /*DnD To be implemented in GUI Settings*/ && ColumnHdrStyle0 == null)
                {
                    newDgPage.ColumnHeaderStyle = ColumnHdrStyle;
                    //newDgPage.ColumnHeaderStyle = ColumnHdrStyle.Setters.Remove(new Setter(DataGridColumnHeader.FontSizeProperty 14));

                    double heightestValue = fontSizes.Aggregate(0.0, (longest, next) => next > longest ? next : longest);
                    double lowestValue = fontSizes.Aggregate(heightestValue, (lowest, next) => next < lowest ? next : lowest);
                    val = heightestValue == lowestValue ? heightestValue + 2.0 : 14;

                    newDgPage.ColumnHeaderStyle.Setters.Add(new Setter(DataGridColumnHeader.FontSizeProperty, new FontSizeConverter().ConvertFrom(val)));



                    //newDgPage.ColumnHeaderStyle.Setters.Add(new Setter(DataGridColumnHeader.MaxWidthProperty, 140.0));
                }
                else
                    newDgPage.ColumnHeaderStyle = ColumnHdrStyle;

                int x = 0;
                //foreach (DataGridColumn cl in newDgPage.Columns)
                //{
                //    val = (Double)cl.GetValue(DataGridColumnHeader.MaxWidthProperty);
                //    maxWidths[x++] = val;
                //}

                var cellWidths = newDgPage.Columns.Select(w => w.Width.DesiredValue).ToArray();
                // Return the final result as an upper case string.
                //fruit => fruit.ToString().PadLeft(());



                //foreach(DataGridColumn dgCol in newDgPage.Columns)
                //    dgCo(DataGridColumnHeader.FontSizeProperty, new FontSizeConverter().ConvertFrom(14))
                //style.Setters.Add(new Setter(DataGridColumnHeader.FontSizeProperty, 14/*new FontSizeConverter().ConvertFrom(14)*/));

                //var cellWidths2 = newDgPage.Columns.Select(w => w.Width.DesiredValue).ToArray();
                //var cellWidths2a = newDgPage.Columns.Select(w => w.Width.DisplayValue).ToArray();
                //var cellWidths2b = newDgPage.Columns.Select(w => w.Width.Value).ToArray();
                double currentPgHeight = 0;

                ++pageNumber;

                DataGridRow row = null;
                //var rowHeaders = DataGridRows.Select(h => (DataGridRowHeader)h.Item);
                //var rowHeaders2 = DataGridRows.Select(h => (DataGridRowHeader)h.Header);
                //double largestRow = rowHeaders.Aggregate(0.0, (longest, next) => next > longest ? next : longest);
                //int lowestValue = rowHeaders.Aggregate(largestRow, (lowest, next) => next < lowest ? next : lowest);
                //val = largestRow == lowestValue ? largestRow  : 14;

                int rowHder = 0;
                while (currentPgHeight < printableHeight && position < this.DataGridRows.Length)
                {
                    row = this.DataGridRows[position++];
                    if (row == null)
                        continue;
                    row.UpdateLayout();///DnD Helps to resolve the irregular print margin,
                                       ///observed, especially at the starting page(s)

                    row.Margin = new Thickness(-5, 0, 0, 0);

                    if (true/*DnD To be implemented in GUI Settings*/ && rowHder != null)
                        row.Header = null;
                    //var rowHeaders3 = DataGridRows.Select(h => h.HeaderTemplate);

                    newDgPage.Items.Add(row);

                    if (row.ActualHeight < 1)
                        continue;
                    currentPgHeight += row.ActualHeight;
                }
                newDgPage.UpdateLayout();
                //scrVw.UpdateLayout();
                //newDgPage.Columns[2].Width.DesiredValue = 12.0;

                //var cellWidths = newDgPage.Columns.Select(w => w.Width).ToArray();
                //newDgPage.ColumnHeaderStyle = ColumnHdrStyle;

                //var cellWidths1a = newDgPage.Columns.Select(w => w.Width.DisplayValue).ToArray();
                //var cellWidths1b = newDgPage.Columns.Select(w => w.Width.Value).ToArray();
                //newDgPage.ColumnHeaderStyle = ColumnHdrStyle;

                //var colEnut = newDgPage.Columns.GetEnumerator();

                //for (int c = 0; c < newDgPage.Columns.Count; c++)
                //    newDgPage.Columns[c].Width = new DataGridLength(cellWidths[c], DataGridLengthUnitType.Pixel);

                ///DnD Contrain Colums' width to align with cell's  width
                //var cellWidths2 = newDgPage.Columns.Select(w => w.Width.DesiredValue).ToArray();
                foreach (DataGridColumn col in newDgPage.Columns)
                {
                    //col.Width = cellWidths[newDgPage.Columns.IndexOf(col)];
                    col.Width = new DataGridLength(cellWidths[newDgPage.Columns.IndexOf(col)], DataGridLengthUnitType.Pixel);
                    //col.ActualWidth
                }
                //for (int c = 0; c < newDgPage.Columns.Count; c++)
                //    if (newDgPage.Columns[c].Width.DesiredValue < cellWidths[c])
                //        newDgPage.Columns[c].Width   =cellWidths[c];
                // new DataGridLength(.IndexOf(col)].ActualWidth, DataGridLengthUnitType.SizeToCells);


                //}

                /*///DnD Utilise the last row items's width to update each column header's width
                ///
                x=0;
                var enut = row.GetLocalValueEnumerator();
                var rowCells = new LocalValueEntry[enut.Count];
                while (enut.MoveNext())
                    rowCells[x++] = enut.Current;
                //newDgPage.CellStyle.

                x = 0;
                foreach (var newRow in newDgPage.Columns)
                {
                    if (rowCells[x] == null || rowCells[x].Property.ReadOnly)
                        continue;
                    var val2 = row.GetValue(rowCells[x++].Property);
                    //newRow.Width = new DataGridLength(row.[x].ActualWidth, DataGridLengthUnitType.SizeToCells);
                }
                */

                newDgPage.Name = "Page_" + pageNumber.ToString().PadLeft(3, '0');
                dgPages.Add(scrVw);

                ///DnD ToDo Previewed pages suffers exception except and have to
                ///be regenerated without previewing. Workaround needs to be created 
                if (this.PreviewMod == PrintPreview.EachPage)
                    Preview.PrintVisual(newDgPage);

                if (position < this.DataGridRows.Length)
                {
                    if (pageNumber == 1 && this.PreviewMod == PrintPreview.FirstPage)
                        Preview.PrintVisual(newDgPage);

                    ;
                }
                else
                {
                    if (this.PreviewMod == PrintPreview.LastPage)
                        Preview.PrintVisual(newDgPage);
                    return dgPages.ToArray();
                }
            }
        }

        private Visual PerformTransform(Visual v, PrintQueue pq)
        {
            ContainerVisual root = new ContainerVisual();
            const double inch = 96;

            // Set the margins.
            double xMargin = 1.25 * inch;
            double yMargin = 1 * inch;

            PrintTicket pt = pq.UserPrintTicket;
            Double printableWidth = pt.PageMediaSize.Width.Value;
            Double printableHeight = pt.PageMediaSize.Height.Value;

            Double xScale = (printableWidth - xMargin * 2) / printableWidth;
            Double yScale = (printableHeight - yMargin * 2) / printableHeight;

            root.Children.Add(v);
            root.Transform = new MatrixTransform(xScale, 0, 0, yScale, xMargin, yMargin);

            return root;
        }


        /// <summary>
        /// Create and return a dictionary object suitable for cloning the columns
        /// of the DataGrid specified parameter (DataGrid) belongs.
        /// </summary>
        /// <param name="dataGrid"></param>
        /// <returns></returns>
        public static Dictionary<int, object[]> GetColumDict2(DataGrid dataGrid)
        {
            var colDict = new Dictionary<int, object[]>();
            for (int x = 0; x < dataGrid.Columns.Count; x++)
            {
                //colDict.Add(x, new object[2]); 
                DataGridColumn dgCol = dataGrid.Columns[x];
                DependencyObjectType colTyp = dgCol.DependencyObjectType;
                DataGridColumn dgCol2 = null;
                switch (colTyp.Name)
                {
                    case "DataGridTextColumn":
                        dgCol2 = new DataGridTextColumn();
                        break;

                    case "DataGridComboBoxColumn":
                        dgCol2 = new DataGridComboBoxColumn();
                        break;

                    case "DataGridCheckBoxColumn":
                        dgCol2 = new DataGridCheckBoxColumn();
                        break;

                    case "DataGridTemplateColumn":
                        dgCol2 = new DataGridTemplateColumn();
                        break;

                    default:
                        throw new NotImplementedException("Missing Switch Case");

                }

                LocalValueEntry[] dependPropts = GetDependecyPropts(dgCol);

                colDict.Add(x, new object[2] { dgCol2, dependPropts });
            }

            return colDict;
        }



        /// <summary>
        /// Creates and returns array of dependency propts (as LocalValueEntry[])
        /// which are suitable for safely creating columns in a new datagrid
        /// that is intended to be a replica of the parameter [dataGrid].
        /// </summary>
        /// <param name="dataGrid">The datagrid which columns are to b cloned</param>
        /// <returns></returns>
        private static List<LocalValueEntry[]> GetColumDepdPropts(DataGrid dataGrid)
        {
            var colDenpdProptsList = new List<LocalValueEntry[]>(dataGrid.Columns.Count);

            double fontSz;
            var fontSizes = new double[dataGrid.Columns.Count];

            for (int x = 0; x < dataGrid.Columns.Count; x++)
            {
                var colDbPropts = new List<LocalValueEntry>();

                DataGridColumn dgCol = dataGrid.Columns[x];

                fontSz = (Double)dgCol.GetValue(DataGridColumnHeader.FontSizeProperty);
                fontSizes[x] = fontSz;

                var enut = dgCol.GetLocalValueEnumerator();

                while (enut.MoveNext())
                {
                    LocalValueEntry colPropt = (LocalValueEntry)enut.Current;
                    if (colPropt == null || colPropt.Property.ReadOnly)
                        continue;
                    colDbPropts.Add(colPropt);

                }



                colDenpdProptsList.Add(colDbPropts.ToArray());
            }


            return colDenpdProptsList;
        }


        public async Task<List<LocalValueEntry[]>> GetColumDepdProptsAsync(DataGrid dataGrid)
        {
            var colDenpdProptsList = new List<LocalValueEntry[]>(dataGrid.Columns.Count);

            await Task.Run(() =>
            {
                for (int x = 0; x < dataGrid.Columns.Count; x++)
                {
                    var colDbPropts = new List<LocalValueEntry>();

                    DataGridColumn dgCol = dataGrid.Columns[x];
                    var enut = dgCol.GetLocalValueEnumerator();

                    while (enut.MoveNext())
                    {
                        LocalValueEntry colPropt = (LocalValueEntry)enut.Current;
                        if (colPropt == null || colPropt.Property.ReadOnly)
                            continue;

                        colDbPropts.Add(colPropt);
                    }

                    //LocalValueEntry[] dependPropts = GetDependecyPropts(dgCol);

                    colDenpdProptsList.Add(colDbPropts.ToArray());
                }
            });

            return colDenpdProptsList;
        }


        public object GetColumDepdPropts(object dgObj)
        {
            var dataGrid = dgObj as DataGrid;
            var colDenpdProptsList = new List<LocalValueEntry[]>(dataGrid.Columns.Count);

            //await Task.Run(() =>
            //{
            for (int x = 0; x < dataGrid.Columns.Count; x++)
            {
                var colDbPropts = new List<LocalValueEntry>();

                DataGridColumn dgCol = dataGrid.Columns[x];
                var enut = dgCol.GetLocalValueEnumerator();

                while (enut.MoveNext())
                {
                    LocalValueEntry colPropt = (LocalValueEntry)enut.Current;
                    if (colPropt == null || colPropt.Property.ReadOnly)
                        continue;

                    colDbPropts.Add(colPropt);
                }

                //LocalValueEntry[] dependPropts = GetDependecyPropts(dgCol);

                colDenpdProptsList.Add(colDbPropts.ToArray());
            }
            //});

            /////DnD ToDo: Sample Usage:
            //var newDgPage = new DataGrid();
            //foreach (LocalValueEntry[] dps in ColDpList)
            //{
            //    int rowIndex = ColDpList.IndexOf(dps);
            //    //DnD: Each new column is inititialize with  DataGridTextColumn
            //    ///befor assigning actual column type below.
            //    newDgPage.Columns.Add(new DataGridTextColumn());
            //    //LocalValueEntry[] dps = (LocalValueEntry[])ColDpList[k][1];
            //    ///DnD The actual  DataGridColumn Type and data is now applied 
            //    ///from the cloned columns's dependency propts.
            //    foreach (LocalValueEntry dp in dps)
            //        newDgPage.Columns[rowIndex].SetValue(dp.Property, dp.Value);
            //}

            return colDenpdProptsList;
        }

        private static LocalValueEntry[] GetDependecyPropts(DataGridColumn dgColumn)
        {
            var colDbPropts = new List<LocalValueEntry>();

            var enut = dgColumn.GetLocalValueEnumerator();

            while (enut.MoveNext())
            {
                LocalValueEntry colPropt = (LocalValueEntry)enut.Current;
                if (colPropt == null || colPropt.Property.ReadOnly)
                    continue;

                colDbPropts.Add(colPropt);
            }

            return colDbPropts.ToArray();
        }

        public DataGrid GetClonedDg(DataGrid grid)
        {
            var ColDpList = GetColumDepdProptsAsync(grid).Result;
            var newDgPage = new DataGrid();
            foreach (LocalValueEntry[] dps in ColDpList)
            {
                int rowIndex = ColDpList.IndexOf(dps);
                //DnD: Each new column is inititialize with  DataGridTextColumn
                ///befor assigning actual column type below.
                newDgPage.Columns.Add(new DataGridTextColumn());
                //LocalValueEntry[] dps = (LocalValueEntry[])ColDpList[k][1];
                ///DnD The actual  DataGridColumn Type and data is now applied 
                ///from the cloned columns's dependency propts.
                foreach (LocalValueEntry dp in dps)
                    newDgPage.Columns[rowIndex].SetValue(dp.Property, dp.Value);
            }
            return newDgPage;
        }




        private static List<DataGridColumn> GetDgColumnsList(DataGrid grid)
        {
            List<DataGridColumn> dgCols = new List<DataGridColumn>();
            for (int x = 0; x < grid.Columns.Count; x++)
            {

                DependencyObjectType colTyp = grid.Columns[x].DependencyObjectType;
                switch (colTyp.Name)
                {
                    case "DataGridTextColumn":
                        dgCols.Add(new DataGridTextColumn());
                        break;

                    case "DataGridComboBoxColumn":
                        dgCols.Add(new DataGridComboBoxColumn());
                        break;
                    case "DataGridCheckBoxColumn":
                        dgCols.Add(new DataGridCheckBoxColumn());
                        break;
                    case "DataGridTemplateColumn":
                        dgCols.Add(new DataGridTemplateColumn());
                        break;
                    default:
                        throw new NotImplementedException("Missing Switch Case");

                }

            }
            return dgCols;
        }


        private static DataGrid CloneFromDgColumns(IList<DataGridColumn> dgColumns)
        {
            DataGrid dgClone = new DataGrid();

            var headers = new Dictionary<int, LocalValueEntry[]>();
            var dgCols = dgColumns.ToArray();

            for (int x = 0; x < dgCols.Length; x++)// DataGridColumn col in dgCols)
            {
                var col = dgCols[x];
                int colIndex = x;// dgCols.IndexOf(col);

                col.Header = col.Header;
                var enut = dgCols[colIndex].GetLocalValueEnumerator();
                var colDetails = new List<LocalValueEntry>();//[enut.Count];
                                                             //int x = 0;
                                                             //enut.Reset();
                while (enut.MoveNext())
                {
                    LocalValueEntry colPropt = (LocalValueEntry)enut.Current;
                    if (colPropt == null || colPropt.Property.ReadOnly)
                        continue;

                    colDetails.Add(colPropt);
                }

                headers.Add(colIndex, colDetails.ToArray());
            }

            foreach (int k in headers.Keys)
            {
                LocalValueEntry[] dps = headers[k];
                foreach (LocalValueEntry dtl in dps)
                    dgClone.Columns[k].SetValue(dtl.Property, dtl.Value);
            }

            return dgClone;
        }


        public bool IsDisposed = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!IsDisposed)
            {
                if (disposing)
                {
                    this.ColumnsDpList = null;
                    this.DataGridRows = null;
                    this.PattnList = null;
                    this.SourceDataGrid = null;
                    ProcessPrint.ColumnHdrStyle0 = null;
                    //ProcessPrint.PageTemplate = null;
                }

            }
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        ~ProcessPrint()
        {
            Dispose(false);
        }
        //private FixedPage FixedPageFromCanvas(DataGrid gridToAdd, Size pageSize, int pageNumber, double leftOffSet, double topOffSet)
        //{
        //    var fixedPage = new FixedPage();
        //    fixedPage.Background = Brushes.White;
        //    fixedPage.Width = pageSize.Width;
        //    fixedPage.Height = pageSize.Height;

        //    // add date
        //    TextBlock dateText = new TextBlock();
        //    if (DateVisibility) dateText.Visibility = Visibility.Visible;
        //    else dateText.Visibility = Visibility.Hidden;

        //    string now = DateTime.Now.ToShortDateString();
        //    dateText.Text = now;

        //    // add page number
        //    TextBlock PageNumberText = new TextBlock();
        //    if (PageNumberVisibility) PageNumberText.Visibility = Visibility.Visible;
        //    else PageNumberText.Visibility = Visibility.Hidden;
        //    PageNumberText.Text = "Page : " + pageNumber;

        //    FixedPage.SetTop(dateText, topOffSet);
        //    FixedPage.SetLeft(dateText, Margin);

        //    FixedPage.SetTop(PageNumberText, topOffSet);
        //    FixedPage.SetLeft(PageNumberText, leftOffSet - PageNumberText.Text.Length * 10);

        //    var margins = new Thickness(Margin * 2);
        //    Canvas canv = Preview.GetVisualCanvas(gridToAdd, pageSize, margins);

        //    fixedPage.Children.Add(canv);
        //    fixedPage.Children.Add(dateText);
        //    fixedPage.Children.Add(PageNumberText);

        //    return fixedPage;
        //}


        //public void PrintFixedDocument(FixedDocument fixedDoc, PrintDialog printDialog)
        //{
        //    XpsDocumentWriter writer = PrintQueue.CreateXpsDocumentWriter(printDialog.PrintQueue);
        //    writer.Write(fixedDoc, printDialog.PrintTicket);
        //}

    }


    public class Preview : Window
    {
        public Preview(UIElement uIElement, Size size)
        {
            //var paginator = new FlexPaginator(dataGrid, ScaleMode.PageWidth, sz, new Thickness(96 / 4), 100);
            string tempFileName = System.IO.Path.GetTempFileName();
            File.Delete(tempFileName);

            //uIElement.Measure(new Size(900, 9900));
            if (uIElement.GetType() == typeof(DataGrid))
            {
                DataGrid dg = uIElement as DataGrid;
                //((DataGrid)uIElement).ScrollIntoView(dg.Items[dg.Items.Count-1]);
            }

            using (XpsDocument xpsDocument = new XpsDocument(tempFileName, FileAccess.ReadWrite))
            {
                System.Windows.Xps.XpsDocumentWriter writer = XpsDocument.CreateXpsDocumentWriter(xpsDocument);
                if (uIElement.RenderSize == null) return;
                writer.Write(uIElement);
                DocumentViewer previewWindow = new DocumentViewer
                {

                    Document = xpsDocument.GetFixedDocumentSequence()
                };

                //Window printpriview = new Window();
                //printpriview.Content = previewWindow;
                //printpriview.Title = "PayPattern: Print Preview";
                //printpriview.Show();

                //Window printpriview = new Window();
                this.Width = size.Width + 200;
                this.Height = size.Height + 50;

                this.Content = previewWindow;
                this.Title = "PayPattern: Print Preview";
                //this.Show();

            }
        }

        public Preview(DocumentPaginator paginator)
        {
            //var paginator = new FlexPaginator(dataGrid, ScaleMode.PageWidth, sz, new Thickness(96 / 4), 100);
            string tempFileName = System.IO.Path.GetTempFileName();

            File.Delete(tempFileName);

            using (XpsDocument xpsDocument = new XpsDocument(tempFileName, FileAccess.ReadWrite))
            {
                System.Windows.Xps.XpsDocumentWriter writer = XpsDocument.CreateXpsDocumentWriter(xpsDocument);
                paginator.ComputePageCount();
                if (paginator.PageCount < 1) return;
                writer.Write(paginator);
                DocumentViewer previewWindow = new DocumentViewer
                {

                    Document = xpsDocument.GetFixedDocumentSequence()
                };

                //Window printpriview = new Window();
                //printpriview.Content = previewWindow;
                //printpriview.Title = "PayPattern: Print Preview";
                //printpriview.Show();

                //Window printpriview = new Window();
                this.Content = previewWindow;
                this.Title = "PayPattern: Print Preview";
                //this.Show();
                //writer.Write(tempFileName);
                this.FixedDocTempFile = tempFileName;
                this.DocWriter = writer;
            }
        }

        private static void SaveXpsDocument(XpsDocument xpsDocument, string filePath)
        {
            XpsDocument xpsd = new XpsDocument(filePath, FileAccess.ReadWrite);
            System.Windows.Xps.XpsDocumentWriter xw = XpsDocument.CreateXpsDocumentWriter(xpsd);
            xw.Write(xpsDocument.GetFixedDocumentSequence());
            xpsd.Close();
        }

        public string FixedDocTempFile { get; set; }
        public System.Windows.Xps.XpsDocumentWriter DocWriter { get; set; }

        public Preview(DocumentPaginator paginator, string range)
        {
            string tempFileName = System.IO.Path.GetTempFileName();

            File.Delete(tempFileName);

            using (XpsDocument xpsDocument = new XpsDocument(tempFileName, FileAccess.ReadWrite))
            {
                System.Windows.Xps.XpsDocumentWriter writer = XpsDocument.CreateXpsDocumentWriter(xpsDocument);
                if (paginator.PageCount < 1) return;

                writer.Write(paginator);
                DocumentViewer previewWindow = new DocumentViewer
                {

                    Document = xpsDocument.GetFixedDocumentSequence()
                };

                this.Content = previewWindow;
                this.Title = "PayPattern: Print Preview";
                //this.Show();

            }
        }


        public static void PrintVisual(DataGrid dg, ScrollViewer panel)
        {
            PrintDialog dlg = new PrintDialog();

            //btnPrint.Visibility = Visibility.Hidden;
            //label1.Visibility = Visibility.Hidden;

            //this.Background = Brushes.White;
            //  cnv.Background = Brushes.White;
            //scroll.Visibility = Visibility.Visible;
            //panel.Visibility = Visibility.Hidden;
            dg.Background = Brushes.White;
            //this.Width = 350;
            string tempFileName = System.IO.Path.GetTempFileName();

            File.Delete(tempFileName);

            using (XpsDocument xpsDocument = new XpsDocument(tempFileName, FileAccess.ReadWrite))
            {
                System.Windows.Xps.XpsDocumentWriter writer = XpsDocument.CreateXpsDocumentWriter(xpsDocument);
                //if (paginator.PageCount < 1) return;
                Visual vis = panel.Content as Visual;
                writer.Write(vis);

                DocumentViewer previewWindow = new DocumentViewer
                {


                    Document = xpsDocument.GetFixedDocumentSequence()
                };

                Window wind = new Window
                {
                    Content = previewWindow
                };
                wind.ShowDialog();
            }
        }

        public static void PrintVisual(DataGrid dg, Size printSize)
        {
            PrintDialog dlg = new PrintDialog();

            //btnPrint.Visibility = Visibility.Hidden;
            //label1.Visibility = Visibility.Hidden;

            //this.Background = Brushes.White;
            //  cnv.Background = Brushes.White;
            //scroll.Visibility = Visibility.Visible;
            //panel.Visibility = Visibility.Hidden;
            dg.RenderSize = new Size(850, 900);
            dg.Arrange(new Rect(printSize));
            dg.UpdateLayout();
            dg.Background = Brushes.White;
            //this.Width = 350;
            string tempFileName = System.IO.Path.GetTempFileName();

            File.Delete(tempFileName);

            using (XpsDocument xpsDocument = new XpsDocument(tempFileName, FileAccess.ReadWrite))
            {
                System.Windows.Xps.XpsDocumentWriter writer = XpsDocument.CreateXpsDocumentWriter(xpsDocument);
                //if (paginator.PageCount < 1) return;
                Visual vis = dg as Visual;
                writer.Write(vis);

                DocumentViewer previewWindow = new DocumentViewer
                {


                    Document = xpsDocument.GetFixedDocumentSequence()
                };

                Window wind = new Window
                {
                    Content = previewWindow
                };
                wind.ShowDialog();
            }
        }


        public static void PrintVisual(DataGrid dg)
        {
            PrintDialog dlg = new PrintDialog();

            //btnPrint.Visibility = Visibility.Hidden;
            //label1.Visibility = Visibility.Hidden;

            //this.Background = Brushes.White;
            //  cnv.Background = Brushes.White;
            //scroll.Visibility = Visibility.Visible;
            //panel.Visibility = Visibility.Hidden;
            var sz = dg.RenderSize.Height < 100 ? new Size(850, 900) : dg.RenderSize;

            dg.Arrange(new Rect(sz));
            dg.UpdateLayout();
            dg.Background = Brushes.White;
            //this.Width = 350;
            string tempFileName = System.IO.Path.GetTempFileName();

            File.Delete(tempFileName);

            using (XpsDocument xpsDocument = new XpsDocument(tempFileName, FileAccess.ReadWrite))
            {
                System.Windows.Xps.XpsDocumentWriter writer = XpsDocument.CreateXpsDocumentWriter(xpsDocument);
                //if (paginator.PageCount < 1) return;
                Visual vis = dg as Visual;
                writer.Write(vis);

                DocumentViewer previewWindow = new DocumentViewer
                {


                    Document = xpsDocument.GetFixedDocumentSequence()
                };

                Window wind = new Window
                {
                    Content = previewWindow
                };
                wind.ShowDialog();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="printobject"></param>
        /// <param name="pageSize"></param>
        /// <param name="margin"></param>
        /// <returns></returns>
        public static Canvas GetVisualCanvas(FrameworkElement printobject, Size pageSize, Thickness margin)
        {
            printobject.Margin = new Thickness(0, 0, 0, 0);
            Visual vis = printobject as Visual;

            VisualBrush vb2 = new VisualBrush(vis);
            //vb2.Stretch = Stretch.None;
            vb2.AlignmentX = AlignmentX.Left;
            vb2.AlignmentY = AlignmentY.Top;
            vb2.ViewboxUnits = BrushMappingMode.Absolute;
            vb2.TileMode = TileMode.None;
            vb2.Stretch = Stretch.Uniform;
            vb2.Viewbox = new Rect(pageSize);

            vb2.AutoLayoutContent = true;
            margin.Right = 40;
            //Size visibleSize = new Size(pageSize.Width + margin.Left + margin.Right, pageSize.Height + margin.Top + margin.Bottom);
            Canvas.SetLeft(printobject, 0);
            Canvas canv = new Canvas
            {
                Width = pageSize.Width,// visibleSize.Width,
                Height = pageSize.Height,// visibleSize.Height,
                Background = vb2,
                Margin = margin,

                //Padding = new Thickness(0)

            };
            return canv;
        }
    }

    public enum ScaleMode
    {
        //
        // Summary:
        //     Render the grid in actual size, breaking pages as needed.
        ActualSize = 0,
        //
        // Summary:
        //     Scale the grid so it fits the page width.
        PageWidth = 1,
        //
        // Summary:
        //     Scale the grid so it fits on a single page.
        SinglePage = 2,
        //
        // Summary:
        //     Prints the current selection in actual size, breaking pages as needed.
        Selection = 3
    }
    /* ///*/
    public class PattnPaginator : DocumentPaginator
    {
        Thickness _margin { get => GuiStat.PrintMargin; }
        Size _pageSize;
        ScaleMode _scaleMode;

        const double cm = 37;
        static double LeftMargin = 0.75 * cm;
        //public double PageWidth = 21 * cm;
        static bool DateVisibility = true;
        static bool PageNumberVisibility = true;
        ICollectionView[] SourceItems;
        //List<FrameworkElement> _pages;
        //DataGrid[] Dgs; 
        UIElement[] _pages;
        //public PattnPaginator( ScaleMode scaleMode, Size pageSize, Thickness margin, int maxPages)
        //{
        //    // save parameters
        //    _margin = margin;
        //    _scaleMode = scaleMode;
        //    _pageSize = pageSize;

        //    // adjust page size for margins before building grid images
        //    pageSize.Width -= (margin.Left + margin.Right);
        //    pageSize.Height -= (margin.Top + margin.Bottom);
        //    // get grid images for each page
        //    _pages =  PrintFormat. flex.GetPageImages((C1.WPF.FlexGrid.ScaleMode)scaleMode, pageSize, maxPages);
        //}

        public PattnPaginator(DataGrid[] dgs, Size sz, ScaleMode scaleMode)
        {
            // save parameters
            //_margin = margin;
            this._scaleMode = scaleMode;
            this._pageSize = sz;
            this._pages = dgs;
            //this.Dgs = dgs;
            //_pageSize = pageSize;
            //adjust page size for margins before building grid images
            //pageSize.Width -= (margin.Left + margin.Right);
            //pageSize.Height -= (margin.Top + margin.Bottom);
            var paging = new ProcessPrint();
            var fxPages = paging.GetFixPages(dgs, sz, GuiStat.PrintMargin);
            _pages = fxPages;//  new List<FrameworkElement>(fxPages);//.AddRange(fxPages);// PrintFormat. flex.GetPageImages((C1.WPF.FlexGrid.ScaleMode)scaleMode, pageSize, maxPages);
        }

        public PattnPaginator(DataGrid[] dgs, Size sz)
        {
            this._scaleMode = ScaleMode.ActualSize;
            this._pageSize = sz;
            this._pages = dgs;
        }
        public PattnPaginator(FrameworkElement[] frames, Size sz, ScaleMode scaleMode)
        {
            this._scaleMode = scaleMode;
            this._pageSize = sz;
            this._pages = frames;
            //_pages = new List<FrameworkElement>(fxPages);
            //_pages = frames;
        }

        public PattnPaginator(UIElement[] sourceItems, Size sz, ScaleMode scaleMode)
        {
            this._scaleMode = scaleMode;
            this._pageSize = sz;
            this._pages = sourceItems;
            //_pages = new List<FrameworkElement>(sourceItems);
        }
        public PattnPaginator(ICollectionView[] sourceItems, Size sz, ScaleMode scaleMode)
        {
            this._scaleMode = scaleMode;
            this._pageSize = sz;


            this.SourceItems =sourceItems;
            //_pages = new List<FrameworkElement>(sourceItems);
        }
        public bool PreviewMode = true;
        public override DocumentPage GetPage(int pageNumber)
        {

            if (PreviewMode)
            {
                //    int currentRow = rowsPerPage * pageNumber;
                //    int rowsToPrint = Math.Min(rowsPerPage, rows - (rowsPerPage * pageNumber - 1));
                //var page = new DataGrid// (dgs[pageNumber]); // new PageElementRenderer(pageNumber + 1, PageCount, currentRow, rowsToPrint)
                //{
                //    ColumnHeaderStyle = ViewsDataGrid.GetColumnHdrStyle,
                //    ItemsSource = Dgs[pageNumber] SourceItems[],
                //    Width = PageSize.Width,
                //    Height = PageSize.Height,
                //};

                //var page = SourceItems[pageNumber];// GetFixedPage(SourceItems[pageNumber], pageNumber);// 
                //page.ColumnHeaderStyle = ViewsDataGrid.GetColumnHdrStyle;
                //if (pageNumber == 0)
                //    page.UpdateLayout();

                var page = _pages[pageNumber];

                //if (page.GetType() == typeof(DataGrid))
                //    ((DataGrid)page).ColumnHeaderStyle = ViewsDataGrid.GetColumnHdrStyle;

                page.Measure(PageSize);
                page.Arrange(new Rect(new Point(0, 0), PageSize));

                var doc = new DocumentPage(page);
                return doc;
            }
            //return base.GetPage(pageNumber);
            // create page element
            PagingTemplate pageTemplate = ProcessPrint.PageTemplate2;//.GetPageTemplate;

            //Application.Current.Dispatcher.Invoke(new Action(()=> { pageTemplate = new PagingTemplate(); 

            pageTemplate.SetPageMargin(_margin);


            // set content
            pageTemplate.PageContent.Child = _pages[pageNumber];

            //new Preview(_pages[pageNumber].visu )
            pageTemplate.PageContent.Stretch = _scaleMode == ScaleMode.Selection
                ? System.Windows.Media.Stretch.None
                : System.Windows.Media.Stretch.Uniform;

            // set footer text
            pageTemplate.FooterRight.Text = string.Format("Page {0} of {1}",
                pageNumber + 1, SourceItems.Length);

            // arrange the elements on the page
            pageTemplate.Arrange(new Rect(0, 0, _pageSize.Width, _pageSize.Height));

            //}));
            //var fxDoc = _pages[pageNumber] as FixedPage;
            //fxDoc.Arrange(new Rect(0, 0, _pageSize.Width, _pageSize.Height));

            //// set margins

            //// return new document page
            //var page = _pages[pageNumber];
            return new DocumentPage(pageTemplate);
        }



        public PageContent GetFixedPage(UIElement ui, int pageNumber)
        {
            if (ui == null) return null;

            Size printSize = this._pageSize;
            Double printableWidth = printSize.Width;
            Double printableHeight = printSize.Height;

            string now = DateTime.Now.ToString("dd/MMM/yyy");

            TextBlock dateText = ProcessPrint.NewTxtBlock;// new TextBlock();
            if (DateVisibility) dateText.Visibility = Visibility.Visible;
            else dateText.Visibility = Visibility.Hidden;

            dateText.Text = now;

            TextBlock PageNumberText = ProcessPrint.NewTxtBlock;// new TextBlock();
            if (PageNumberVisibility) PageNumberText.Visibility = Visibility.Visible;
            else PageNumberText.Visibility = Visibility.Hidden;

            PageNumberText.Text = "Page : " + pageNumber.ToString().PadLeft(PageCount, '0') + "/" + this.PageCount;// dgs.Length;
            PageNumberText.SetValue(TextElement.FontWeightProperty, FontWeights.Bold);


            FixedPage.SetTop(dateText, printableHeight - 25);
            FixedPage.SetLeft(dateText, LeftMargin + _margin.Left);

            FixedPage.SetTop(PageNumberText, printableHeight - 25);
            FixedPage.SetLeft(PageNumberText, LeftMargin + (printableWidth - PageNumberText.Text.Length * 10) / 2);

            var size = new Size(printableWidth, printableHeight);


            var fixedPage = new FixedPage
            {
                Background = Brushes.White,
                Width = printableWidth,
                Height = printableHeight,
                Margin = new Thickness(0),

            };

            FixedPage.SetLeft(ui, LeftMargin + _margin.Left);
            FixedPage.SetTop(ui, _margin.Top);
            try
            {

                fixedPage.Children.Add(ui);
                fixedPage.Children.Add(dateText);
                fixedPage.Children.Add(PageNumberText);
            }
            catch (Exception ex)
            {

                //throw;
            }


            PageContent pageContent = new PageContent();
            ((IAddChild)pageContent).AddChild(fixedPage);

            return pageContent;
        }


        //public override DocumentPage GetPage2(int pageNumber)
        //{
        //    int currentRow = rowsPerPage * pageNumber;
        //    int rowsToPrint = Math.Min(rowsPerPage, rows - (rowsPerPage * pageNumber - 1));
        //    var page = new PageElementRenderer(pageNumber + 1, PageCount, currentRow, rowsToPrint)
        //    {
        //        Width = PageSize.Width,
        //        Height = PageSize.Height
        //    };
        //    page.Measure(PageSize);
        //    page.Arrange(new Rect(new Point(0, 0), PageSize));
        //    return new DocumentPage(page);
        //}

        public override int PageCount
        {
            get { return _pages == null || _pages.Length < 1 ? SourceItems.Length : _pages.Length; }
        }
        public override IDocumentPaginatorSource Source
        {
            get { return null; }
        }
        public override Size PageSize
        {
            get { return _pageSize; }
            set { throw new NotImplementedException(); }
        }
        public override bool IsPageCountValid
        {
            get { return true; }
        }
    }
    /// */


    //public class PattnDocumentWrite :  FixedDocumentSequence
    //{

    //    public PrintTicket PrintTicket { set => throw new NotImplementedException(); }

    //    public Uri Uri => throw new NotImplementedException();

    //    public int DocumentNumber => throw new NotImplementedException();

    //    public XpsStructure AddDocumentStructure()
    //    {

    //        throw new NotImplementedException();
    //    }

    //    public IXpsFixedPageWriter AddFixedPage()
    //    {
    //        throw new NotImplementedException();
    //    }

    //    public XpsThumbnail AddThumbnail(XpsImageType imageType)
    //    {
    //        throw new NotImplementedException();
    //    }

    //    public void Commit()
    //    {
    //        throw new NotImplementedException();
    //    }
    //}

}
