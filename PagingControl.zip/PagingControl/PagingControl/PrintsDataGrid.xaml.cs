﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PagingControl
{
    /// <summary>
    /// Interaction logic for DGridPrintModel.xaml
    /// </summary>
    public partial class PrintsDataGrid : UserControl
    {
        public PrintsDataGrid()
        {
            InitializeComponent();
            DataContextChanged += OnDataContextChanged;
            DgViews = DgPrints = dataGridPrints;
        }

        public DataGrid DgPrints { get; set; }
        public DataGrid DgViews { get; set; }
        
        private void OnDataContextChanged(object sender, System.Windows.DependencyPropertyChangedEventArgs e)
        {
            var info = DataContext as ColorInfo;
            if (info == null) return;
            //IdText.Text = info.Key;
            DataContextChanged -= OnDataContextChanged; // load text only once
            //DgPrints = info.DataGridPage;
            //DgPrints.UpdateLayout();
        }

        //public static readonly DependencyProperty ColumnHdrStyleProperty =
        //    DependencyProperty.Register("ColumnHdrStyle", typeof(Style), typeof(Control)/*,
        //      new  PropertyMetadata(false, new PropertyChangedCallback(OnSetTextChanged))*/);


        //public Style ColumnHdrStyle
        //{
        //    get { return (Style)GetValue(ColumnHdrStyleProperty); }
        //    set { SetValue(ColumnHdrStyleProperty, value); }
        //}




        //private static PrintsDataGrid PrintControl0 => new PrintsDataGrid();
        //public static Style GetColumnHdrStyle
        //{
        //    get { return (Style)PrintControl0.FindResource("ColumnHeaderStyle1"); }
        //}


        //public static Style GetDgRowStyle
        //{
        //    get { return (Style)PrintControl0.FindResource("DgCellStyle"); }
        //}

    }
}