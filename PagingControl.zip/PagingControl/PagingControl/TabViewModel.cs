﻿using SharedResource;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Printing;
using System.Reflection;
using System.Runtime.Remoting.Messaging;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace PagingControl
{
    public class ContentViewModel : INotifyPropertyChanged
    {
        public ContentViewModel()
        {
            //_items.CollectionChanged += _items_CollectionChanged;

        }

        //private void _items_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        //{
        //    //throw new System.NotImplementedException();
        //}

        private ColorInfo _selectedColor;

        public ColorInfo SelectedColor
        {
            get { return _selectedColor; }
            set
            {

                int i = _items.IndexOf(value);
                bool initSelect = value.InitSelected, exists = _items.Contains(value);

                if (!exists)
                {
                    //var existing = i > -1 ? _items[i] : null;
                    //var eq = value.Equals(existing);

                    //var criteria = value.PrevCritr = value.Criteria; 
                    //var strArr = SharedResource.Stat.GetPattnArr(criteria);
                    //var pattns = PrintFormat.GetPatterns(strArr);
                    //value.PattnList = value.PattnList;

                    _items.Add(value);
                }
                else if (!initSelect)
                    ColorInfo.PrevIntance = _selectedColor = value;
                //else
                //    _selectedColor = ColorInfo.PrevIntance;

                if (initSelect || ColorInfo.PrevIntance == null)
                    ColorInfo.PrevIntance = _selectedColor = value;
                //else
                //    ;

                //_selectedColor.Viewed = _selectedColor == value; 

                var eventArgs = new PropertyChangedEventArgs("SelectedColor");
                PropertyChanged(this, eventArgs);
                //value.Curso = _selectedColor == value ? null: Cursors.Wait; 
            }
        }


        public event PropertyChangedEventHandler PropertyChanged = delegate { };

        public ColorInfo SelectedColorXXX
        {
            get { return _selectedColor; }
            set
            {

                int i = _items.IndexOf(value);
                bool initSelect = value.InitSelected, exists = _items.Contains(value);
                if (!initSelect)
                    _selectedColor = value;
                if (initSelect || !exists)
                {
                    //var existing = i > -1 ? _items[i] : null;
                    //var eq = value.Equals(existing);

                    //var criteria = value.PrevCritr = value.Criteria; 
                    //var strArr = SharedResource.Stat.GetPattnArr(criteria);
                    //var pattns = PrintFormat.GetPatterns(strArr);
                    //value.PattnList = value.PattnList;

                    _items.Add(value);
                }
                //else
                //    _selectedColor = ColorInfo.PrevIntance;

                if (initSelect || ColorInfo.PrevIntance == null)
                    ColorInfo.PrevIntance = _selectedColor = value;
                else
                    ;

                //_selectedColor.Viewed = true;

                var eventArgs = new PropertyChangedEventArgs("SelectedColor");
                PropertyChanged(this, eventArgs);
            }
        }

        private ObservableCollection<ColorInfo> _items = new ObservableCollection<ColorInfo>();
        public IEnumerable<ColorInfo> Items { get { return _items; } }

        public  /*Collection<Color>*/ColorsRepository _collection { get; internal set; }

        private PageMediaSize MediaSize0;
        public PageMediaSize MediaSize
        {
            ///DnD: NOT TO BE FURTHER SIMPLIFIED
            get => MediaSize0 ?? new PageMediaSize(816, 1056);
            internal set { MediaSize0 = value; }
        }

        //public bool IsSizedToPage { get =>  MediaSize0 != null && !Hybrid; }

        /// <summary>
        /// DnD IsSizedToPage is true only when no [_items] element has  null [SheetInfo.DataGridPaging] 
        /// </summary>
        /// 
        public bool IsSizedToPage { get => _items.Where(i => i.PagingData != null && i.PagingData.GetType() == typeof(ViewsDataGrid)).ToArray().Length == _items.Count; }


        public bool IsSizedToPage2
        {
            get
            {
                var x = _items.Where(i => i.PagingData == null).ToArray().Length;
                var x2 = _items.Where(i => i.PagingData!=null && i.PagingData.GetType() == typeof(ViewsDataGrid)).ToArray().Length;

                var r = x == 0 && x2 == _items.Count;

                return r;
            }
        }

        public CheckStatus PagingStatus { get; set; }

        /// <summary>
        /// Indicates not all pages of the tabControl are generated with preview capability
        /// and preview should not be attempted on any
        /// </summary>
        public bool Hybrid { get => _items.Count < 1 || !IsSizedToPage; }



        //public void ProptStatusUpdate(PropertyChangedEventArgs eventArgs)
        //{
        //    PropertyChanged(this, eventArgs);
        //}

        //public ColorsRepository()
        //{
        //    //var colors= new List<>
        //    foreach (PropertyInfo property in typeof(Colors).GetProperties())
        //        Add(new ColorInfo() { Key = property.Name, Value = (Color)property.GetValue(null, null) });
        //}


    }


    public class ColorsRepository : Collection<ColorInfo>, IColorsRepository
    {
        public ColorsRepository()
        {


            var SharpColors = new List<string>();

            if (!TabControlMgr.ColorEditMode)
            {
                string ColorsList = Stat.AppDir + "ColorInfos";
                var allText = File.ReadAllText(ColorsList);

                if (allText != null && allText.Trim() != "")
                {
                    string[] colList = allText.Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);

                    SharpColors.AddRange(colList);

                }
            }


            foreach (PropertyInfo property in typeof(Colors).GetProperties())
            {
                var pNm = property.GetValue(null, null).ToString();// property.Name;
                if (!SharpColors.Contains(pNm) && SharpColors.Count > 1 && !TabControlMgr.ColorEditMode)
                    continue;
                Add(new ColorInfo() { Key = property.Name, Val = (Color)property.GetValue(null, null) });
            }
        }
    }

    public interface IColorsRepository { }

    [Serializable()]
    public class ColorInfo
    {
        public ColorInfo()
        {/* this.Curso = Cursors.Wait; */}
        #region Properties

        public string Key { get; set; }

        public Color Val { get; set; }
        public ICollectionView PattnList { get; set; }
        public string Criteria { get; set; }
        //public Cursor Curso { get; set; }  
        public object PagingData { get; set; }

        public SolidColorBrush PageColor { get => new SolidColorBrush(Val); }
        
        private bool InitDeSelected0;
        /// <summary>
        /// When 'true' class will not initialized as current selection
        /// but reverts automatically to false after first query. This ensures
        /// that only the 1st TabItem is initially selectec when multiple tabs
        /// loaded
        /// </summary>
        public bool InitSelected
        {
            get
            {
                var temp = InitDeSelected0;
                InitDeSelected0 = false;
                return temp;
            }
            set { InitDeSelected0 = value; }
        }

        /// <summary>
        /// Previou Instance 
        /// </summary>
        public static ColorInfo PrevIntance { get; set; }


        //public F PattnList { get; set; }

        #endregion

        #region Methosd

        public override string ToString()
        {
            return Key;
        }

        #endregion
    }

    //public class Color: System.Windows.Media.Color;
    //{

    //}


}
