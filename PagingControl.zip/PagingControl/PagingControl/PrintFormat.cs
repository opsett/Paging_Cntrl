﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Navigation;

namespace PagingControl
{
    public class PrintFormat : INotifyPropertyChanged, IEditableObject//, IEnumerable
    {
        public PrintFormat()
        {
            //ListCollectionView

        }


        public IEnumerator GetEnumerator()
        {
            return Items.AsEnumerable().GetEnumerator();
        }

        public IEnumerable GetEnumerator(bool excludeNull)
        {
            return Items.AsEnumerable();
        }

        public object[] Items
        {
            get
            {
                var arr = new object[] {
                    (object)this.Archived,
                    (object)this.Color,
                    (object)this.Consistence,
                    (object)this.CoopDebit,
                    (object)this.GradeStep,
                    (object)this.Gross,
                    (object)this.Name,
                    (object)this.PPID,
                    (object)this.SNo
                };

                return arr.Where(s => s != null).ToArray();
            }
        }

        static string[] _lines = "Computers|Washers|Stoves".Split('|');
        static string[] _colors = "Red|Green|Blue|White".Split('|');

        // object model
        public string SNo { get { return (string)GetValue("S/No"); } set { SetValue("S/No", value); } }
        public string PPID { get { return (string)GetValue("PPID"); } set { SetValue("PPID", value); } }
        public string Line { get { return (string)GetValue("Line"); } set { SetValue("Line", value); } }
        public string Color { get { return (string)GetValue("Color"); } set { SetValue("Color", value); } }
        public string Name { get { return (string)GetValue("Name"); } set { SetValue("Name", value); } }
        public double Net { get { return (double)GetValue("Net"); } set { SetValue("Net", value); } }
        public double GradeStep { get { return (double)GetValue("GradeStep"); } set { SetValue("GradeStep", value); } }
        public double Gross { get { return (double)GetValue("Gross"); } set { SetValue("Gross", value); } }
        public double CoopDebit { get { return (double)GetValue("CoopDebit"); } set { SetValue("CoopDebit", value); } }
        public bool Archived { get { return (bool)GetValue("Archived"); } set { SetValue("Archived", value); } }
        public int Consistence { get { return (int)GetValue("Consistence"); } set { SetValue("Consistence", value); } }

        public FrameworkElement PrintData { get { return (FrameworkElement)GetValue("PrintData"); } set { SetValue("PrintData", value); } }

        Dictionary<string, object> _values = new Dictionary<string, object>();
        object GetValue(string p)
        {
            object value;
            _values.TryGetValue(p, out value);
            return value;
        }

        void SetValue(string p, object value)
        {
            if (!object.Equals(value, GetValue(p)))
            {
                _values[p] = value;
                OnPropertyChanged(p);
            }
        }
        protected virtual void OnPropertyChanged(string p)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(p));
        }


        //// factory
        public static ICollectionView GetPatterns(string[] pttnArr)
        {
            if (pttnArr == null) return null;

            var list = new ObservableCollection<PrintFormat>();
            var rnd = new Random();
            //for (int i = 0; i < count; i++)
            int i = 1; int dgt = pttnArr.Length.ToString().Length;
            foreach (string s in pttnArr)
            {
                var d = s.Split('\n');
                if (d.Length != 10) return null;

                var p = new PrintFormat();
                p.SNo = (i++).ToString().PadLeft(dgt, '0');
                p.PPID = d[0];
                //p.Line = _lines[rnd.Next() % _lines.Length];
                //p.Color = _colors[rnd.Next() % _colors.Length];
                p.Name = d[1];// string.Format("{0} {1}{2}", p.Line.Substring(0, p.Line.Length - 1), p.Line[0], i);
                p.Net = Convert.ToDouble(d[9]);// rnd.Next(1, 1000);
                p.GradeStep = Convert.ToDouble(d[6]);//rnd.Next(1, 100);
                p.Gross = Convert.ToDouble(d[8]);//rnd.Next(1, 600);
                p.CoopDebit = Convert.ToDouble(d[7]);//rnd.Next(500, 5000);
                p.Archived = rnd.NextDouble() < .1;
                p.Consistence = rnd.Next(0, 5);
                list.Add(p);
            }
            return new ListCollectionView(list);
        }

        /// <summary>
        /// Uses a pattern data to create a sample row data from which a row height
        /// can subsequently be computed.
        /// </summary>
        /// <param name="pttnArr"></param>
        /// <param name="pattnArr"></param>
        /// <returns></returns>
        public static ICollectionView GetSamplePattern(string[] pttnArr, out PrintFormat[] pattnArr)
        {
            return GetPatterns(pttnArr.Take(1).ToArray(), out pattnArr);
        }
        public static ICollectionView GetPatterns(string[] pttnArr, out PrintFormat[] pattnArr)
        {
            pattnArr = null;
            if (pttnArr == null) return null;

            var list = new ObservableCollection<PrintFormat>();
            var pattnArrList = new List<PrintFormat>();
            var rnd = new Random();
            //for (int i = 0; i < count; i++)
            int i = 1; int dgt = pttnArr.Length.ToString().Length;
            foreach (string s in pttnArr)
            {
                var d = s.Split('\n');
                if (d.Length != 10) return null;

                var p = new PrintFormat();
                p.SNo = (i++).ToString().PadLeft(dgt, '0');
                p.PPID = d[0];
                //p.Line = _lines[rnd.Next() % _lines.Length];
                //p.Color = _colors[rnd.Next() % _colors.Length];
                p.Name = d[1];// string.Format("{0} {1}{2}", p.Line.Substring(0, p.Line.Length - 1), p.Line[0], i);
                p.Net = Convert.ToDouble(d[9]);// rnd.Next(1, 1000);
                p.GradeStep = Convert.ToDouble(d[6]);//rnd.Next(1, 100);
                p.Gross = Convert.ToDouble(d[8]);//rnd.Next(1, 600);
                p.CoopDebit = Convert.ToDouble(d[7]);//rnd.Next(500, 5000);
                p.Archived = rnd.NextDouble() < .1;
                p.Consistence = rnd.Next(0, 5);
                list.Add(p);
                pattnArrList.Add(p);
            }
            pattnArr = pattnArrList.ToArray();
            return new ListCollectionView(list);
        }
        public static string[] GetLines()
        {
            return _lines;
        }
        public static string[] GetColors()
        {
            return _colors;
        }

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion

        #region IEditableObject Members

        static Dictionary<string, object> _clone;
        public void BeginEdit()
        {
            if (_clone == null)
            {
                _clone = new Dictionary<string, object>();
            }
            _clone.Clear();
            foreach (var key in _values.Keys)
            {
                _clone[key] = _values[key];
            }
        }
        public void CancelEdit()
        {
            _values.Clear();
            foreach (var key in _clone.Keys)
            {
                _values[key] = _clone[key];
            }
        }
        public void EndEdit()
        {
        }
        #endregion

    }
}
