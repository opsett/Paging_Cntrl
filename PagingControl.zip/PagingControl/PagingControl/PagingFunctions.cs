﻿using SharedResource;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.IO.Packaging;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Documents.Serialization;
using System.Windows.Xps;
using System.Windows.Xps.Packaging;
using System.Xml.Linq;

namespace PagingControl
{
    //public class PattnPaginator : DocumentPaginator 
    //{
    //}
    public static class PagingFunctions
    {
        public static Task<string> RunDownloadAsync(Progress<ProgressReportModel> progress, CancellationToken token)
        {
            //WebsiteDataModel results = await DownloadWebsiteAsync(site);
            //Docu
            return null;
        }


        private static async Task<string> DownloadWebsiteAsync(string websiteURL)
        {
            //WebsiteDataModel output = new WebsiteDataModel();
            //WebClient client = new WebClient();

            //output.WebsiteUrl = websiteURL;
            //output.WebsiteData = await client.DownloadStringTaskAsync(websiteURL);

            return null;
        }


        //public static ProcessPrint PagingInfo { get; set; }

        //private static object SourceItems
        //{
        //    get
        //    {
        //        string[][] multidStrArr = PagingInfo.SplitListToPages();
        //        var sourcItems = multidStrArr.Select(i => (ListCollectionView)PrintFormat.GetPatterns(i)).ToArray();
        //        return sourcItems;
        //    }
        //}

        //private static Size Sz { get => PagingInfo.PageSize; }

        //private static CheckStatus DocStatus { get; set; }


        private static object GetPagingPropt(string resxName)
        {
            resxName = resxName.ToLower();
            object val = null;
            switch (resxName)
            {
                case "sourceitems":
                case "sourceitem":
                    string[][] multidStrArr = PatternWkBook.PagingInfo.SplitListToPages();
                    var sourcItems = multidStrArr.Select(i => (ListCollectionView)PrintFormat.GetPatterns(i)).ToArray();
                    val = sourcItems;
                    break;
                case "size":
                case "sz":
                    val = PatternWkBook.PagingInfo.PageSize;
                    break;
                default:

                    break;
            }
            return val;
        }

        [STAThread()]
        public static async Task<string> PagingCallBack(/*PatternWkBook wkBook, */)//, Size sz)
        {
            ICollectionView[] sourceItems = GetPagingPropt("SourceItems") as ICollectionView[];
            //var sourceItems = wkBook.Cv.Items.ToArray().Select(v => v.PattnList).ToArray();
            //var sz = wkBook.PageSize;
            //var tabControlMgr = wkBook.TabCtrMgr;
            //var tabControl = tabControlMgr.TabControl;
            var colStyl = ViewsDataGrid.GetColumnHdrStyle;
            bool optimized = false;
            //DataGrid[] dgs = vdgs.Select(v => v.DgViews).ToArray();
            var vdgs = new ViewsDataGrid[sourceItems.Length];

            //var wkDispach = Application.Current.Dispatcher;// wkBook.Dispatcher;


            for (int x = 0; x < sourceItems.Length; x++)
            {
                //var vdg =  vdgs[x];
                var source = sourceItems[x];// tabControl.Items[x] as ColorInfo;// vdg.ItemSource;

                //wkDispach.Invoke(DispatcherPriority.Background, new Action(() =>
                //{
                var dg = (vdgs[x] = new ViewsDataGrid()).DgViews;// vdg.DgViews;
                dg.ItemsSource = source;
                dg.Dispatcher.Invoke(() => dg.ColumnHeaderStyle = colStyl);

                ///DnD Visual optimization must be done for the first page 
                if (!optimized)
                {
                    var scrV = new ScrollViewer();

                    var wind = new Window();
                    wind.Width = 20; wind.Height = 20;
                    //wind.RenderSize = sz;
                    wind.Content = scrV;
                    scrV.Content = dg;
                    wind.UpdateLayout();

                    wind.Show();
                    scrV.Content = null;
                    wind.Close();

                    //var tabMgr = wkBook.TabCtrMgr;// new TabControlMgr();
                    //var contHold = tabMgr.Content;
                    //tabMgr.Content = dg;
                    //tabMgr.UpdateLayout();
                    //tabMgr.Content = null;

                    //tabMgr.Content = contHold;
                    optimized = true;
                }
                //}));
            }

            //for (int t = 0; t < 3000; t++)
            //    Thread.Sleep(1);

            //FixedDocument fDoc = null;
            var paging = PatternWkBook.PagingInfo;
            var dgs = vdgs.Select(v => v.DgViews).ToArray();

            //DocStatus = CheckStatus.Started;

            //while (DocStatus == CheckStatus.Started)
            //    Thread.Sleep(1);

            //return dgs;



            //new Preview();



            //var dgs = caller.EndInvoke(ar) as DataGrid[];

            //var paging = new ProcessPrint();
            //var dgs = obj as DataGrid[][];
            //Application.Current.Dispatcher.BeginInvoke(
            //     DispatcherPriority.Background, new Action(() => { caller.EndInvoke(ar); }));
            var sz = (Size)GetPagingPropt("sz");

            //DocStatus = CheckStatus.NotStarted;
            XpsDocument xpsDoc = null;

            //task.
            //var xpsDoc = XpsDocument.CreateXpsDocumentWriter

            await Application.Current.Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Background,
                new Action(async () =>
               {
                   xpsDoc = await PreviewDoc2(dgs, sz, ScaleMode.ActualSize);
                   //return;

                   //while (DocStatus == 0)
                   //    Thread.Sleep(1);

               }));

            //while (DocStatus == 0)
            //    Thread.Sleep(1);
            return "";
            DocumentViewer docViewer = new DocumentViewer
            {
                Document = xpsDoc.GetFixedDocumentSequence()
            };
            //writer /*= _xpsdwActive*/ = null;
            //xpsDoc.Close();

            var wind2 = new Window();
            wind2.Content = docViewer;
            wind2.UpdateLayout();
            wind2.Closed += Wind_Closed;
            wind2.Show();
            //DocStatus = CheckStatus.Completed;
            return "";
            var pagtor = new PattnPaginator(dgs, sz, ScaleMode.ActualSize);// fDoc.DocumentPaginator;
            await PreviewDoc(pagtor);










            /*
            wkDispach.Invoke(DispatcherPriority.ContextIdle, new Action(() =>
            {

                DocStatus = CheckStatus.Started;
                fDoc = paging.GetFixDoc(dgs, sz, GuiStat.PrintMargin);
                //fDoc = wkBook.GetFixDoc(dgs, sz, GuiStat.PrintMargin);
                var pagtor = fDoc.DocumentPaginator;

                //pagtor.GetPageCompleted += Pagtor_GetPageCompleted;

                //var prev =
                this.PreviewDoc(fDoc);


                //var fle = prev.FixedDocTempFile;
                //var writer = prev.DocWriter;
                //prev.Show();
            }));
               */

            return "";
        }

        [STAThread()]
        public static async Task<DocumentPaginator> GetPreviewPagesAsync()
        {
            ICollectionView[] sourceItems = GetPagingPropt("SourceItems") as ICollectionView[];
            var colStyl = ViewsDataGrid.GetColumnHdrStyle;
            bool optimized = false;

            var vdgs = new ViewsDataGrid[sourceItems.Length];
            for (int x = 0; x < sourceItems.Length; x++)
            {
                var source = sourceItems[x];
                var dg = (vdgs[x] = new ViewsDataGrid()).DgViews;
                dg.ItemsSource = source;
                dg.Dispatcher.Invoke(() => dg.ColumnHeaderStyle = colStyl);

                ///DnD Visual optimization must be done for the first page 
                if (!optimized)
                {
                    var scrV = new ScrollViewer();

                    var wind = new Window();
                    wind.Width = 20; wind.Height = 20;
                    //wind.RenderSize = sz;
                    wind.Content = scrV;
                    scrV.Content = dg;
                    wind.UpdateLayout();

                    wind.Show();
                    scrV.Content = null;
                    wind.Close();
                    optimized = true;
                }
            }
            var paging = PatternWkBook.PagingInfo;
            var dgs = vdgs.Select(v => v.DgViews).ToArray();
            var sz = (Size)GetPagingPropt("Sz");

            //DocStatus = CheckStatus.NotStarted;
            XpsDocument xpsDocument = null;
            //PattnPaginator paginator = null;
            DocumentPaginator paginator = null;

            await Application.Current.Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Background,
                new Action(async () =>
              {
                  //await Task.Factory.StartNew(async () =>
                  //await Task.Run(async () =>
                  //{
                  //xpsDocument = await GetXpsDoc(dgs, sz, ScaleMode.ActualSize);


                  //paginator = await ProcessPrint.GetFixPagesAsync(dgs, sz, GuiStat.PrintMargin);// new PattnPaginator(dgs, sz, ScaleMode.ActualSize);// fDoc.DocumentPaginator;
                  var fxDoc = await ProcessPrint.GetFixedDocAsync(dgs, sz, GuiStat.PrintMargin);// new PattnPaginator(dgs, sz, ScaleMode.ActualSize);// fDoc.DocumentPaginator;
                  paginator = fxDoc.DocumentPaginator;

                  //Preview(paginator);
                  //return;
                  string tempFileName = System.IO.Path.GetTempFileName();

                  File.Delete(tempFileName);
                  //XpsDocument xpsDocument = null;
                  //using (_xpsDocument = new XpsDocument(tempFileName, FileAccess.ReadWrite))
                  //{
                  xpsDocument = new XpsDocument(tempFileName, FileAccess.ReadWrite);
                  XpsDocumentWriter writer = XpsDocument.CreateXpsDocumentWriter(xpsDocument);
                  //var fxSeq = xpsDocument.GetFixedDocumentSequence();
                  //writer.Write(paginator);

                  //return;
                  //var fxSeq = xpsDocument.GetFixedDocumentSequence();
                  if (paginator.PageCount < 1) return;

                  //await Task.Run(() =>
                  //{
                  writer.WritingCompleted += new WritingCompletedEventHandler(AsyncSaveCompleted);
                  writer.WriteAsync(paginator, xpsDocument);
              }));
            //}).ConfigureAwait(false);

            //ProcessPrint.GetFixPagesAsync(dgs, sz, GuiStat.PrintMargin)}));

            //return null;
            // ()=>ProcessPrint.GetFixPagesAsync(dgs, sz, GuiStat.PrintMargin) );
            return paginator;
        }


        public static Task<T> StartSTATask<T>(Func<T> func)
        {
            var tcs = new TaskCompletionSource<T>();
            try
            {
                Thread thread = new Thread(() =>
                {
                    tcs.SetResult(func());
                });
                thread.SetApartmentState(ApartmentState.STA);
                thread.Start();

            }
            catch (Exception e)
            {
                tcs.SetException(e);
            }
            return tcs.Task;
        }


        [STAThread()]
        public static async Task<PattnPaginator> GetPreviewPagesAsync3c()
        {
            ICollectionView[] sourceItems = GetPagingPropt("SourceItems") as ICollectionView[];
            var paging = PatternWkBook.PagingInfo;

            var sz = (Size)GetPagingPropt("Sz");

            XpsDocument xpsDocument = null;
            PattnPaginator paginator = null;

            //await Application.Current.Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Background,
            //    new Action( () =>
            //    {
            //await Task.Run(() =>
            //{
            var dgs = paging.GetDgPages2(sourceItems, sz);


            ///var canvs = paging.GetCanvasArr(sourceItems, paging.PageSize.Height);
            ///var fxPg = paging.GetFixPages(dgs, paging.PageSize, GuiStat.PrintMargin);

            paginator = new PattnPaginator(dgs, sz);
            //paginator.ComputePageCount();

            var doc = Review(paginator);

            //while(true)
            //Thread.Sleep(10);
            //return paginator;
            string tempFileName = System.IO.Path.GetTempFileName();
            File.Delete(tempFileName);

            xpsDocument = new XpsDocument(tempFileName, FileAccess.ReadWrite);
            XpsDocumentWriter writer = XpsDocument.CreateXpsDocumentWriter(xpsDocument);


            //writer.WritingCompleted += new WritingCompletedEventHandler(AsyncSaveCompleted);
            writer.Write(paginator);//, xpsDocument);
            //writer.Write(paginator);//, xpsDocument);

            //PrintViewer previewWindow = new PrintViewer();

            //previewWindow.Document = xpsDocument.GetFixedDocumentSequence();
            //previewWindow.ShowDialog();
            //var doc = xpsDocument.GetFixedDocumentSequence();

            PrintViewer previewWindow = new PrintViewer()
            {
                //Owner = this,
                Document = xpsDocument.GetFixedDocumentSequence(),
                Height = 1056

            };
            //previewWindow.Show();
            //previewWindow.Close();

            //previewWindow = new PrintViewer();
            //previewWindow.Document = doc;
            previewWindow.Activate();
            previewWindow.ShowDialog();

            return paginator;
        }


        [STAThread()]
        public static async Task<PattnPaginator> GetPreviewPagesAsync3b()
        {
            ICollectionView[] sourceItems = GetPagingPropt("SourceItems") as ICollectionView[];
            var paging = PatternWkBook.PagingInfo;

            var sz = (Size)GetPagingPropt("Sz");

            XpsDocument xpsDocument = null;
            PattnPaginator paginator = null;

            await Application.Current.Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Background,
                new Action(() =>
               {
                   //await Task.Run(() =>
                   //{
                   var dgs = paging.GetDgPages(sourceItems, paging.PageSize.Height);

                   ///var canvs = paging.GetCanvasArr(sourceItems, paging.PageSize.Height);
                   ///var fxPg = paging.GetFixPages(dgs, paging.PageSize, GuiStat.PrintMargin);

                   paginator = new PattnPaginator(dgs, sz);

                   string tempFileName = System.IO.Path.GetTempFileName();

                   File.Delete(tempFileName);

                   xpsDocument = new XpsDocument(tempFileName, FileAccess.ReadWrite);
                   XpsDocumentWriter writer = XpsDocument.CreateXpsDocumentWriter(xpsDocument);

                   writer.WritingCompleted += AsyncSaveCompleted;
                   writer.WriteAsync(paginator, xpsDocument);
               }));
            //}).ConfigureAwait(false);

            return paginator;
        }


        public static PattnPaginator XpsDocUpdate(PrintViewer prevwer)// XpsDocumentWriter writer, ICollectionView[] sourceItems, XpsDocument xpsDoc)
        {
            ICollectionView[] sourceItems = GetPagingPropt("SourceItems") as ICollectionView[];
            var paging = PatternWkBook.PagingInfo;

            var sz = (Size)GetPagingPropt("Sz");

            //XpsDocument xpsDocument = null;
            PattnPaginator paginator = null;

            //await Application.Current.Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Background,
            //    new Action(() =>
            //   {
            //await Task.Run(() =>
            //{
            var dgs = paging.GetDgPages(sourceItems, paging.PageSize.Height);
            paginator = new PattnPaginator(dgs, sz);


            string fileName = System.IO.Path.GetTempFileName();

            File.Delete(fileName);

            //CollatePrintVisual(fileName,paginator);

            CollatePrintVisual(prevwer, paginator);
            //var dgs2 = paging.GetDgPages(sourceItems, paging.PageSize.Height);
            //var paginator2 = new PattnPaginator(dgs2, sz);

            ////CollatePrintVisual(fileName,paginator2);
            //CollatePrintVisual(prevwer, paginator2);

            return null;
            //var visualCollt = writer.CreateVisualsCollator();
            var xpsDocument = new XpsDocument(fileName, FileAccess.ReadWrite);
            XpsDocumentWriter writer = XpsDocument.CreateXpsDocumentWriter(xpsDocument);
            var visualCollt = writer.CreateVisualsCollator();


            //XpsDocumentWriter writer = XpsDocument.CreateXpsDocumentWriter(xpsDocument);

            //writer.WritingCompleted += AsyncSaveCompleted;
            //writer.Write(paginator);

            for (int x = 0; x < paginator.PageCount; x++)
            {
                System.Windows.Media.Visual vis = paginator.GetPage(x).Visual;
                visualCollt.Write(vis);
            }


            for (int x = 0; x < paginator.PageCount; x++)
            {
                System.Windows.Media.Visual vis = paginator.GetPage(x).Visual;
                visualCollt.Write(vis);
            }



            PrintViewer previewWindow = new PrintViewer()
            {
                //Owner = this,
                Document = xpsDocument.GetFixedDocumentSequence(),
                Height = 1056

            };
            //previewWindow.Show();
            //previewWindow.Close();

            //previewWindow = new PrintViewer();
            //previewWindow.Document = doc;
            previewWindow.Activate();
            previewWindow.ShowDialog();

            //}));
            //}).ConfigureAwait(false);

            return paginator;
        }
        private static int Y;
        //private static void CollatePrintVisual( string fileName, PattnPaginator paginator)
        private static void CollatePrintVisual(PrintViewer prevwer, PattnPaginator paginator)
        {

            //Package pack = new Package();
            //new XpsDocument(new Package())
            //using (var doc = new XpsDocument(fileName, FileAccess.Write))

            var parts = prevwer.DucPackage.GetParts().ToArray();
            //using (var doc = new XpsDocument(prevwer.DucPackage))
            //{
            var doc = new XpsDocument(prevwer.DucPackage);
            var writer = XpsDocument.CreateXpsDocumentWriter(doc);
            var collator = writer.CreateVisualsCollator();

            //parts = prevwer.DucPackage.GetParts().ToArray();
            collator.BeginBatchWrite();

            parts = prevwer.DucPackage.GetParts().ToArray();
            int x = 0;
        rpt:
            for (Y += 2; x < Y; x++)
            {
                DocumentPage pg = paginator.GetPage(x);
                System.Windows.Media.Visual vis = pg.Visual;

                parts = prevwer.DucPackage.GetParts().ToArray();

                collator.Write(vis);

                //vis.DependencyObjectType.
                parts = prevwer.DucPackage.GetParts().ToArray();

            }
            parts = prevwer.DucPackage.GetParts().ToArray();
            //var urs = parts.Select(p => p.Uri.AbsoluteUri.Contains("1.fpage")).ToArray();//.Contains("Documents/1/Pages/_rels/1.fpage").ToArray() ;
            var fileID = x.ToString() + ".fpage";
            var uris = parts.Where(p => p.Uri.OriginalString.Contains(fileID)).Select(u => u.Uri).ToArray();//.Contains("Documents/1/Pages/_rels/1.fpage").ToArray() ;
            /*
                Documents / 1 / Pages / 1.fpage
                Documents/1/Pages/_rels/1.fpage.rels
                */
            //parts = prevwer.DucPackage.GetParts().ToArray();

            foreach (var z in uris)
                prevwer.DucPackage.DeletePart(z);


            parts = prevwer.DucPackage.GetParts().ToArray();
            //collator.BeginBatchWrite();
            for (Y += 2; x < Y; x++)
            {
                System.Windows.Media.Visual vis = paginator.GetPage(x).Visual;

                collator.Write(vis);
                parts = prevwer.DucPackage.GetParts().ToArray();
            }

            parts = prevwer.DucPackage.GetParts().ToArray();

            foreach (var z in uris)
                prevwer.DucPackage.DeletePart(z);

            parts = prevwer.DucPackage.GetParts().ToArray();
//prevwer.DucPackage.
            //goto rpt;
            //collator.Write(form1);
            //collator.Write(form2);
            //collator.Write(form3);
            collator.EndBatchWrite();

            //}

            string fileName = prevwer.Uri;// System.IO.Path.GetTempFileName();

            //    var parts = prevwer.DucPackage.GetParts().ToArray();
            //File.Delete(fileName);

            //if (Y < 9) goto rpt;

            var doc2 = new XpsDocument(prevwer.DucPackage, CompressionOption.Normal, fileName);

            var seq = doc2.GetFixedDocumentSequence();

            parts = prevwer.DucPackage.GetParts().ToArray();

            //var window = new Window();
            //window.Content = new DocumentViewer { Document = seq };
            //PrintViewer preViewer = new PrintViewer
            //{
            //    Document = seq
            //};
            prevwer.Document = seq;

            var pgCount = paginator.PageCount;
            //paginator.ComputePageCount();
            var paginator2 = prevwer.Document.DocumentPaginator;

            pgCount = paginator2.PageCount;

            prevwer.Document.DocumentPaginator.ComputePageCount();

            prevwer.ShowDialog();
            doc2.Close();


            //prevwer.DucPackage.DeletePart(new Uri(@"Documents/1/Pages/1.fpage"));
        }

        [STAThread()]
        public static async Task<PattnPaginator> GetPreviewPagesAsync3()
        {
            ICollectionView[] sourceItems = GetPagingPropt("SourceItems") as ICollectionView[];
            var colStyl = ViewsDataGrid.GetColumnHdrStyle;
            bool optimized = false;

            var vdgs = new ViewsDataGrid[sourceItems.Length];
            //var dgs = new List<DataGrid>(sourceItems.Length);
            for (int x = 0; x < sourceItems.Length; x++)
            {
                var source = sourceItems[x];
                var vdg = vdgs[x] = new ViewsDataGrid();
                var dg = vdg.DgViews;//new DataGrid();// (vdgs[x] =
                dg.ItemsSource = source;
                dg.Dispatcher.Invoke(() => dg.ColumnHeaderStyle = colStyl);

                ///DnD Visual optimization must be done for the first page 
                if (!optimized)
                {
                    //var scrV = new ScrollViewer();

                    //var wind = new Window();
                    //wind.Width = 20; wind.Height = 20;

                    //wind.Content = scrV;
                    //scrV.Content = dg;
                    //wind.UpdateLayout();

                    //wind.Show();
                    //scrV.Content = null;
                    //wind.Close();
                    optimized = true;
                }

                //dgs.Add(dg);
            }
            var paging = PatternWkBook.PagingInfo;
            var dgs = vdgs.Select(v => v.DgViews).ToArray();
            var sz = (Size)GetPagingPropt("Sz");

            //DocStatus = CheckStatus.NotStarted;
            XpsDocument xpsDocument = null;
            PattnPaginator paginator = null;

            await Application.Current.Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Background,
                new Action(() =>
             {
                 //await Task.Factory.StartNew(async () =>
                 //await Task.Run(async () =>
                 //{
                 //xpsDocument = await GetXpsDoc(dgs, sz, ScaleMode.ActualSize);


                 paginator = new PattnPaginator(dgs.ToArray(), sz);// new PattnPaginator(dgs, sz, ScaleMode.ActualSize);// fDoc.DocumentPaginator;

                 //Preview(paginator);
                 //return;
                 string tempFileName = System.IO.Path.GetTempFileName();

                 File.Delete(tempFileName);
                 //XpsDocument xpsDocument = null;
                 //using (_xpsDocument = new XpsDocument(tempFileName, FileAccess.ReadWrite))
                 //{
                 xpsDocument = new XpsDocument(tempFileName, FileAccess.ReadWrite);
                 XpsDocumentWriter writer = XpsDocument.CreateXpsDocumentWriter(xpsDocument);
                 //var fxSeq = xpsDocument.GetFixedDocumentSequence();
                 //writer.Write(paginator);

                 //return;
                 //var fxSeq = xpsDocument.GetFixedDocumentSequence();
                 //paginator.ComputePageCount();
                 //if (paginator.PageCount < 1) return;

                 //await Task.Run(() =>
                 //{
                 writer.WritingCompleted += new WritingCompletedEventHandler(AsyncSaveCompleted);
                 writer.WriteAsync(paginator, xpsDocument);
             }));
            //}).ConfigureAwait(false);

            //ProcessPrint.GetFixPagesAsync(dgs, sz, GuiStat.PrintMargin)}));

            //return null;
            // ()=>ProcessPrint.GetFixPagesAsync(dgs, sz, GuiStat.PrintMargin) );
            return paginator;
        }

        [STAThread()]
        public static async Task<PattnPaginator> GetPreviewPagesAsync4()
        {
            ICollectionView[] sourceItems = GetPagingPropt("SourceItems") as ICollectionView[];
            var colStyl = ViewsDataGrid.GetColumnHdrStyle;
            bool optimized = false;

            var vdgs = new ViewsDataGrid[sourceItems.Length];
            for (int x = 0; x < sourceItems.Length; x++)
            {
                var source = sourceItems[x];
                var dg = (vdgs[x] = new ViewsDataGrid()).DgViews;
                dg.ItemsSource = source;
                dg.Dispatcher.Invoke(() => dg.ColumnHeaderStyle = colStyl);

                ///DnD Visual optimization must be done for the first page 
                if (!optimized)
                {
                    var scrV = new ScrollViewer();

                    var wind = new Window();
                    wind.Width = 20; wind.Height = 20;
                    //wind.RenderSize = sz;
                    wind.Content = scrV;
                    scrV.Content = dg;
                    wind.UpdateLayout();

                    wind.Show();
                    scrV.Content = null;
                    wind.Close();
                    optimized = true;
                }
            }
            var paging = PatternWkBook.PagingInfo;
            var dgs = vdgs.Select(v => v.DgViews).ToArray();
            var sz = (Size)GetPagingPropt("Sz");

            //DocStatus = CheckStatus.NotStarted;
            XpsDocument xpsDocument = null;
            PattnPaginator paginator = null;

            await Application.Current.Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Background,
                new Action(async () =>
              {
                  //await Task.Factory.StartNew(async () =>
                  //await Task.Run(async () =>
                  //{
                  //xpsDocument = await GetXpsDoc(dgs, sz, ScaleMode.ActualSize);


                  paginator = await ProcessPrint.GetFixPagesAsync(dgs, sz, GuiStat.PrintMargin);// new PattnPaginator(dgs, sz, ScaleMode.ActualSize);// fDoc.DocumentPaginator;

                  //Preview(paginator);
                  //return;
                  string tempFileName = System.IO.Path.GetTempFileName();

                  File.Delete(tempFileName);
                  //XpsDocument xpsDocument = null;
                  //using (_xpsDocument = new XpsDocument(tempFileName, FileAccess.ReadWrite))
                  //{
                  xpsDocument = new XpsDocument(tempFileName, FileAccess.ReadWrite);
                  XpsDocumentWriter writer = XpsDocument.CreateXpsDocumentWriter(xpsDocument);
                  //var fxSeq = xpsDocument.GetFixedDocumentSequence();
                  //writer.Write(paginator);

                  //return;
                  //var fxSeq = xpsDocument.GetFixedDocumentSequence();
                  if (paginator.PageCount < 1) return;

                  //await Task.Run(() =>
                  //{
                  writer.WritingCompleted += new WritingCompletedEventHandler(AsyncSaveCompleted);
                  writer.WriteAsync(paginator, xpsDocument);
              }));
            //}).ConfigureAwait(false);

            //ProcessPrint.GetFixPagesAsync(dgs, sz, GuiStat.PrintMargin)}));

            //return null;
            // ()=>ProcessPrint.GetFixPagesAsync(dgs, sz, GuiStat.PrintMargin) );
            return paginator;
        }

        [STAThread()]
        public static async Task<PattnPaginator> GetPreviewPagesAsync2()
        {

            XpsDocument xpsDocument = null;
            PattnPaginator paginator = null;
            //await Task.Factory.StartNew(async () =>
            await Task.Run(async () =>
           {
               ICollectionView[] sourceItems = GetPagingPropt("SourceItems") as ICollectionView[];
               var colStyl = ViewsDataGrid.GetColumnHdrStyle;
               bool optimized = false;

               var vdgs = new ViewsDataGrid[sourceItems.Length];
               for (int x = 0; x < sourceItems.Length; x++)
               {
                   var source = sourceItems[x];
                   var dg = (vdgs[x] = new ViewsDataGrid()).DgViews;
                   dg.ItemsSource = source;
                   dg.Dispatcher.Invoke(() => dg.ColumnHeaderStyle = colStyl);

                   ///DnD Visual optimization must be done for the first page 
                   if (!optimized)
                   {
                       var scrV = new ScrollViewer();

                       var wind = ProcessPrint.NewWindow;// new Window();
                                                         //wind.RenderSize = sz;
                                                         //wind.Dispatcher.Invoke(() =>
                                                         //{
                       wind.Width = 20; wind.Height = 20;
                       wind.Content = scrV;
                       scrV.Content = dg;
                       wind.UpdateLayout();
                       wind.Show();
                       scrV.Content = null;
                       wind.Close();
                       optimized = true;
                       //});
                   }
               }
               var paging = PatternWkBook.PagingInfo;
               var dgs = vdgs.Select(v => v.DgViews).ToArray();
               var sz = (Size)GetPagingPropt("Sz");
               //xpsDocument = await GetXpsDoc(dgs, sz, ScaleMode.ActualSize);


               paginator = await ProcessPrint.GetFixPagesAsync(dgs, sz, GuiStat.PrintMargin);// new PattnPaginator(dgs, sz, ScaleMode.ActualSize);// fDoc.DocumentPaginator;

               //Preview(paginator);
               //return;
               string tempFileName = System.IO.Path.GetTempFileName();

               File.Delete(tempFileName);
               //XpsDocument xpsDocument = null;
               //using (_xpsDocument = new XpsDocument(tempFileName, FileAccess.ReadWrite))
               //{
               xpsDocument = new XpsDocument(tempFileName, FileAccess.ReadWrite);
               XpsDocumentWriter writer = XpsDocument.CreateXpsDocumentWriter(xpsDocument);
               //var fxSeq = xpsDocument.GetFixedDocumentSequence();
               //writer.Write(paginator);

               //return;
               //var fxSeq = xpsDocument.GetFixedDocumentSequence();
               if (paginator.PageCount < 1) return;

               //await Task.Run(() =>
               //{
               writer.WritingCompleted += new WritingCompletedEventHandler(AsyncSaveCompleted);
               writer.WriteAsync(paginator, xpsDocument);

           });

            //ProcessPrint.GetFixPagesAsync(dgs, sz, GuiStat.PrintMargin)}));

            //return null;
            // ()=>ProcessPrint.GetFixPagesAsync(dgs, sz, GuiStat.PrintMargin) );
            return paginator;
        }

        //private static PattnPaginator Method()
        //{
        //    throw new NotImplementedException();
        //}

        //private static Task<T> StartSTATask<T>(bool v)
        //{
        //    throw new NotImplementedException();
        //}


        public static FixedDocumentSequence Review(PattnPaginator paginator)
        {
            string tempFileName = System.IO.Path.GetTempFileName();

            //GetTempFileName creates a file, the XpsDocument throws an exception if the file already
            //exists, so delete it. Possible race condition if someone else calls GetTempFileName
            File.Delete(tempFileName);
            using (XpsDocument xpsDocument = new XpsDocument(tempFileName, FileAccess.ReadWrite))
            {
                XpsDocumentWriter writer = XpsDocument.CreateXpsDocumentWriter(xpsDocument);
                writer.Write(paginator);

                PrintViewer previewWindow = new PrintViewer()
                {
                    //Owner = this,
                    Document = xpsDocument.GetFixedDocumentSequence()
                };
                //previewWindow.ShowActivated = true;
                previewWindow.Show();
                previewWindow.Close();
                return (FixedDocumentSequence)previewWindow.Document;
            }

        }

        public static void Preview(PattnPaginator paginator)
        {
            string tempFileName = System.IO.Path.GetTempFileName();

            //GetTempFileName creates a file, the XpsDocument throws an exception if the file already
            //exists, so delete it. Possible race condition if someone else calls GetTempFileName
            File.Delete(tempFileName);
            using (XpsDocument xpsDocument = new XpsDocument(tempFileName, FileAccess.ReadWrite))
            {
                XpsDocumentWriter writer = XpsDocument.CreateXpsDocumentWriter(xpsDocument);
                writer.Write(paginator);

                PrintViewer previewWindow = new PrintViewer()
                {
                    //Owner = this,
                    Document = xpsDocument.GetFixedDocumentSequence()
                };
                //previewWindow.ShowActivated = true;
                previewWindow.Show();
                previewWindow.Close();
            }

        }

        [STAThread()]
        public static async Task<XpsDocument> GetXpsDoc(DataGrid[] dgs, Size sz, ScaleMode scaleMode)
        {
            PattnPaginator paginator = new PattnPaginator(dgs, sz, ScaleMode.ActualSize);// fDoc.DocumentPaginator;

            //Application.Current.Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.Normal,
            //    new Action(()=> paginator = new  PattnPaginator(dgs, sz, ScaleMode.ActualSize)));

            //var sz = Sz;// new Size(pd.PrintableAreaWidth, pd.PrintableAreaHeight);

            // create paginator
            //var paginator = new FlexPaginator(dataGrid, ScaleMode.PageWidth, sz, new Thickness(96 / 4), 100);
            //var paginator = new FlexPaginator(dataGrid, ScaleMode.PageWidth, sz, new Thickness(96 / 4), 100);
            //var paginator = new PrintPaginator(dataGrid, ScaleMode.PageWidth, sz, new Thickness(96 / 4), 100);
            string tempFileName = System.IO.Path.GetTempFileName();

            File.Delete(tempFileName);
            //XpsDocument xpsDocument = null;
            //using (_xpsDocument = new XpsDocument(tempFileName, FileAccess.ReadWrite))
            //{
            var xpsDocument = new XpsDocument(tempFileName, FileAccess.ReadWrite);
            return xpsDocument;
        }


        public static async Task PreviewDoc(DocumentPaginator paginator)
        {
            //var fxDoc = new FixedDocument();
            //var pd = new PrintDialog();

            // calculate page size
            var sz = (Size)GetPagingPropt("Sz");// ;// new Size(pd.PrintableAreaWidth, pd.PrintableAreaHeight);

            // create paginator
            //var paginator = new FlexPaginator(dataGrid, ScaleMode.PageWidth, sz, new Thickness(96 / 4), 100);
            //var paginator = new FlexPaginator(dataGrid, ScaleMode.PageWidth, sz, new Thickness(96 / 4), 100);
            //var paginator = new PrintPaginator(dataGrid, ScaleMode.PageWidth, sz, new Thickness(96 / 4), 100);
            string tempFileName = System.IO.Path.GetTempFileName();

            File.Delete(tempFileName);
            //XpsDocument xpsDocument = null;
            //using (_xpsDocument = new XpsDocument(tempFileName, FileAccess.ReadWrite))
            //{
            var xpsDocument = new XpsDocument(tempFileName, FileAccess.ReadWrite);
            XpsDocumentWriter writer = XpsDocument.CreateXpsDocumentWriter(xpsDocument);
            if (paginator.PageCount < 1) return;

            //writer.WritingCompleted += new WritingCompletedEventHandler(AsyncSaveCompleted);

            //writer.WriteAsync(paginator, xpsDocument);

            await PrevDocAsync(writer, paginator, xpsDocument);



        }



        [STAThread()]
        public static async Task<XpsDocument> PreviewDoc2(DataGrid[] dgs, Size sz, ScaleMode scaleMode)
        {
            PattnPaginator paginator = new PattnPaginator(dgs, sz, ScaleMode.ActualSize);// fDoc.DocumentPaginator;

            //Application.Current.Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.Normal,
            //    new Action(()=> paginator = new  PattnPaginator(dgs, sz, ScaleMode.ActualSize)));

            //var sz = Sz;// new Size(pd.PrintableAreaWidth, pd.PrintableAreaHeight);

            // create paginator
            //var paginator = new FlexPaginator(dataGrid, ScaleMode.PageWidth, sz, new Thickness(96 / 4), 100);
            //var paginator = new FlexPaginator(dataGrid, ScaleMode.PageWidth, sz, new Thickness(96 / 4), 100);
            //var paginator = new PrintPaginator(dataGrid, ScaleMode.PageWidth, sz, new Thickness(96 / 4), 100);
            string tempFileName = System.IO.Path.GetTempFileName();

            File.Delete(tempFileName);
            //XpsDocument xpsDocument = null;
            //using (_xpsDocument = new XpsDocument(tempFileName, FileAccess.ReadWrite))
            //{
            var xpsDocument = new XpsDocument(tempFileName, FileAccess.ReadWrite);
            XpsDocumentWriter writer = XpsDocument.CreateXpsDocumentWriter(xpsDocument);
            if (paginator.PageCount < 1) return null;

            //await Task.Run(() =>
            //{
            writer.WritingCompleted += new WritingCompletedEventHandler(AsyncSaveCompleted);
            writer.WriteAsync(paginator, xpsDocument);
            //});
            //var writers = new XpsDocumentWriter[] { writer };
            //await Task.Run(() =>
            //{
            //    Parallel.ForEach<XpsDocumentWriter>(writers, (wr) =>
            //    {
            //        wr.WritingCompleted +=new WritingCompletedEventHandler(AsyncSaveCompleted);
            //        wr.WriteAsync(paginator, xpsDocument);

            //        //WebsiteDataModel results = DownloadWebsite(site);
            //        //output.Add(results);

            //        //report.SitesDownloaded = output;
            //        //report.PercentageComplete = (output.Count * 100) / websites.Count;
            //        //progress.Report(report);
            //    });
            //});

            //writer.WritingCompleted += new WritingCompletedEventHandler(AsyncSaveCompleted);
            //writer.Write(paginator);
            return xpsDocument;//  await PrevDocAsync(writer, paginator, xpsDocument);

            //await PreviewDoc(pagtor);

            //var fxDoc = new FixedDocument();
            //var pd = new PrintDialog();

            //// calculate page size
            //var sz = Sz;// new Size(pd.PrintableAreaWidth, pd.PrintableAreaHeight);

            //// create paginator
            ////var paginator = new FlexPaginator(dataGrid, ScaleMode.PageWidth, sz, new Thickness(96 / 4), 100);
            ////var paginator = new FlexPaginator(dataGrid, ScaleMode.PageWidth, sz, new Thickness(96 / 4), 100);
            ////var paginator = new PrintPaginator(dataGrid, ScaleMode.PageWidth, sz, new Thickness(96 / 4), 100);
            //string tempFileName = System.IO.Path.GetTempFileName();

            //File.Delete(tempFileName);
            ////XpsDocument xpsDocument = null;
            ////using (_xpsDocument = new XpsDocument(tempFileName, FileAccess.ReadWrite))
            ////{
            //var xpsDocument = new XpsDocument(tempFileName, FileAccess.ReadWrite);
            //XpsDocumentWriter writer = XpsDocument.CreateXpsDocumentWriter(xpsDocument);
            //if (paginator.PageCount < 1) return;

            ////writer.WritingCompleted += new WritingCompletedEventHandler(AsyncSaveCompleted);

            ////writer.WriteAsync(paginator, xpsDocument);

            //await PrevDocAsync(writer, paginator, xpsDocument);



        }


        private static async Task PrevDocAsync(XpsDocumentWriter writer, DocumentPaginator paginator, XpsDocument xpsDocument)
        {
            //Application.Current.Dispatcher.BeginInvoke(DispatcherPriority.Background,
            //new Action(() =>
            //{
            //writer.WritingCompleted += new WritingCompletedEventHandler(AsyncSaveCompleted);
            //await Task.Run(() =>
            //{
            //    writer.WritingCompleted += new WritingCompletedEventHandler(AsyncSaveCompleted);
            await Task.Run(() => writer.WriteAsync(paginator, xpsDocument));

            var xpsDoc = xpsDocument;
            DocumentViewer docViewer = new DocumentViewer
            {
                Document = xpsDoc.GetFixedDocumentSequence()
            };
            writer /*= _xpsdwActive*/ = null;
            xpsDoc.Close();

            var wind = new Window();
            wind.Content = docViewer;
            wind.UpdateLayout();
            wind.Closed += Wind_Closed;
            wind.Show();
            //DocStatus = CheckStatus.Completed;
        }

        //private static async Task<DocumentPaginator> DownloadWebsiteAsync(string websiteURL)
        //{
        //    WebsiteDataModel output = new WebsiteDataModel();
        //    WebClient client = new WebClient();

        //    output.WebsiteUrl = websiteURL;
        //    output.WebsiteData = await client.DownloadStringTaskAsync(websiteURL);

        //    return output;
        //}

        private static void AsyncSaveCompleted(object sender, WritingCompletedEventArgs e)
        {
            //return;
            //while (true)
            //    Thread.Sleep(1);
            var writer = sender as XpsDocumentWriter;
            //writer.
            //new XpsDocument()
            var xpsDoc = e.UserState as XpsDocument;
            //PrintViewer previewWindow = new PrintViewer()
            //{
            //    //Owner = this,
            //    Document = xpsDoc.GetFixedDocumentSequence(),
            //    Height = 1056

            //};
            //previewWindow.ShowActivated = true;
            //previewWindow.Show();

            ICollectionView[] sourceItems = GetPagingPropt("SourceItems") as ICollectionView[];
            //XpsDocUpdate(writer, sourceItems, xpsDoc);

            PrintViewer previewWindow2 = new PrintViewer()
            {
                //Owner = this,
                Document = xpsDoc.GetFixedDocumentSequence(),
                Height = 1056

            };
            previewWindow2.ShowActivated = true;
            previewWindow2.Show();
            //new DocumentViewer().SetBinding();



            //DocumentViewer docViewer = new DocumentViewer
            //{
            //    Document = xpsDoc.GetFixedDocumentSequence()
            //};
            //var wind = new Window();
            //wind.Content = xpsDoc;// docViewer;
            //wind.UpdateLayout();
            //wind.Closed += Wind_Closed;
            //wind.Show();

            //PagingInfo.Dispose();
            writer /*= _xpsdwActive*/ = null;
            xpsDoc.Close();

            //DocStatus = CheckStatus.Completed;
        }


        private static void Wind_Closed(object sender, EventArgs e)
        {
            var docViewer = (DocumentViewer)((Window)sender).Content;
            docViewer = null;
            //PagingInfo = null;

        }

    }



    public class ProgressReportModel
    {
        //public int PercentageComplete { get; set; } = 0;
        //public List<WebsiteDataModel> SitesDownloaded { get; set; } = new List<WebsiteDataModel>();
    }
}
