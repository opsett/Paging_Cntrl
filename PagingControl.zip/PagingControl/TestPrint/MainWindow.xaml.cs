﻿using PagingControl;
using SharedResource;
//using SharedResource;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Printing;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;



namespace TestPrint
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
      


        //ICollectionView _data;
        public MainWindow()
        {
            InitializeComponent();
        }
          string[]  PattArr = Stat.GetPattnArr("1-5");

        public ICollectionView GridData { get; set; }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            //if (mainGrid.Children.Contains(dataGridMgr))
            //    mainGrid.Children.Remove(dataGridMgr);

            ////SpreadSheet pagGen = new SpreadSheet(DataNavig.UpdatedPattnList, dataGridMgr);

            //SpreadSheet pagGen = new SpreadSheet(PattArr, dataGridMgr);

            //if (mainGrid.Children.Contains(patternWkBook))
            //    mainGrid.Children.Remove(patternWkBook);

            //var wkBook =patternWkBook;
            //wkBook.Visibility = Visibility;
            //wkBook.VerticalAlignment = VerticalAlignment.Stretch;
            //wkBook.HorizontalAlignment = HorizontalAlignment.Stretch;
            //pagGen.Content = wkBook;
            //pagGen.UpdateLayout();
            //pagGen.Show();


            return;

            //DataGridMgr paging = pagGen.DgridMgr;
            //DataGrid dgrid = paging.DftDataGrid;
            //var viewer = paging.DgScrollView;

            //if (viewer.Parent is Panel container && container.Children.Contains(viewer))
            //    container.Children.Remove(viewer);

            //pagGen.Content = paging.DgScrollView;

            //pagGen.UpdateLayout();


            ///*//ToDo create custom dialog box for user's paper size and orientation options
            //PrintDialog pDlg = new PrintDialog();
            //if (!pDlg.ShowDialog().Value)
            //    return;
            //*/
            //pagGen.SizeToContent = SizeToContent.Width;
            //pagGen.Show();

            /////DnD Trim of all unused columns and rows
            //double wt = 0;
            //foreach (DataGridColumn col in dgrid.Columns)
            //{
            //    wt += col.Width.DesiredValue;
            //}
            //dgrid.SetValue(WidthProperty, wt);

            //PageMediaSize mediaSize = new PageMediaSize(816, 1056);// pDlg.PrintTicket.PageMediaSize;
            //var wkSheet = paging.GetWorkSheets(dgrid, mediaSize);
        }
    }

    public partial class SpreadSheet : PattnWindow
    {

        public SpreadSheet(String[] pattArr, DataGridMgr pageCtr)
        {

            GridData = PrintFormat.GetPatterns(pattArr);
            this.DataContext = DgridMgr = pageCtr;
            DgridMgr.DataSource = GridData;
            this.Content = pageCtr;

        }
        public ICollectionView GridData { get; set; }
        public PagingControl.DataGridMgr DgridMgr { get; }

    }



}
